package com.kyy.launcher

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Состояние переноса иконки в меню приложений: что тащим, где палец и над какой иконкой он сейчас. */
class DrawerDrag {
    /** Прямоугольники иконок на экране (координаты окна), их сообщает каждая иконка. */
    val rects = HashMap<String, Rect>()
    var pkg by mutableStateOf<String?>(null)
    var pos by mutableStateOf(Offset.Zero)
    var target by mutableStateOf<String?>(null)
    var origin by mutableStateOf(Offset.Zero)

    /** Менять местами можно только иконки одного раздела (одной буквы), иначе приложение оказалось бы под чужой буквой. */
    var same: (String, String) -> Boolean = { _, _ -> true }

    fun hit(p: Offset, self: String): String? =
        rects.entries.firstOrNull { it.key != self && it.value.contains(p) && same(self, it.key) }?.key
}

private fun letterOf(label: String): String {
    val c = label.trim().firstOrNull()?.uppercaseChar() ?: return "#"
    return if (c.isLetter()) c.toString() else "#"
}

/** Порядок разделов: сначала кириллица, потом латиница, потом всё остальное и «#». */
private fun rank(l: String): String {
    if (l == "#") return "3"
    val c = l[0]
    return when {
        c in '\u0410'..'\u042F' || c == '\u0401' -> "0$l"
        c in 'A'..'Z' -> "1$l"
        else -> "2$l"
    }
}

@Composable
fun Drawer(
    a: MainActivity, apps: List<AppInfo>, onClose: () -> Unit,
    menuFor: (AppInfo) -> List<MenuAction>
) {
    val s = MaterialTheme.colorScheme
    val open = LocalOpen.current
    var q by remember { mutableStateOf("") }
    // Места (и буквы-разделы) всегда задаёт алфавит; свой порядок только решает, какое приложение стоит на каком месте.
    // Так при перестановке вид меню не меняется. Новые приложения, которых нет в сохранённом порядке, встают в конец.
    val orderStr = prefs.drawerOrder
    val ordered = remember(apps, orderStr) {
        if (orderStr.isEmpty()) apps
        else {
            val byPkg = apps.associateBy { it.pkg }
            val saved = orderStr.pkgs().mapNotNull { byPkg[it] }.distinctBy { it.pkg }
            val have = saved.map { it.pkg }.toSet()
            saved + apps.filter { it.pkg !in have }
        }
    }
    val filtered = remember(ordered, q) { if (q.isBlank()) ordered else ordered.filter { it.label.contains(q.trim(), true) } }
    val headers = q.isBlank()
    val drag = remember { DrawerDrag() }
    val doSwap = { x: String, y: String ->
        val list = ordered.map { it.pkg }.toMutableList()
        val i = list.indexOf(x)
        val j = list.indexOf(y)
        if (i >= 0 && j >= 0) {
            java.util.Collections.swap(list, i, j)
            prefs.drawerOrder = list.joinToString("|")
        }
    }
    val groups: List<Pair<String, List<AppInfo>>> = remember(filtered, headers, ordered) {
        // раздел определяет настоящее название приложения; внутри раздела сохраняется свой порядок иконок
        if (headers) ordered.groupBy { letterOf(it.label) }.toList().sortedBy { rank(it.first) }
        else listOf("" to filtered)
    }
    val letterByPkg = remember(apps) { apps.associate { it.pkg to letterOf(it.label) } }
    drag.same = { x, y -> letterByPkg[x] == letterByPkg[y] }
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val cols = prefs.drawerCols
    var bubble by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    val firstVisible by remember { derivedStateOf { state.firstVisibleItemIndex } }
    val activeLetter = groups.getOrNull(firstVisible)?.first ?: ""

    Surface(Modifier.fillMaxSize(), color = s.surface.copy(alpha = .97f)) {
        Box(Modifier.fillMaxSize().systemBarsPadding().imePadding().onGloballyPositioned { drag.origin = it.positionInWindow() }) {
            Column(Modifier.fillMaxSize()) {
                var closeDrag by remember { mutableFloatStateOf(0f) }
                Column(
                    Modifier.pointerInput(Unit) {
                        detectVerticalDragGestures(onDragEnd = { closeDrag = 0f }, onDragCancel = { closeDrag = 0f }) { _, dy ->
                            closeDrag += dy
                            if (closeDrag > 150f) { closeDrag = 0f; onClose() }
                        }
                    }
                ) {
                    Box(
                        Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp)
                            .size(width = 36.dp, height = 4.dp).clip(CircleShape).background(s.outlineVariant)
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = 12.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Приложения", fontSize = 34.sp, fontWeight = FontWeight.Black,
                            color = s.onSurface, modifier = Modifier.weight(1f)
                        )
                        Box(
                            Modifier.size(52.dp).clip(shapeOf("cookie")).background(s.primary),
                            contentAlignment = Alignment.Center
                        ) { Text("${apps.size}", fontWeight = FontWeight.Bold, color = s.onPrimary, fontSize = 16.sp) }
                    }
                }
                LazyColumn(
                    state = state, modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 12.dp, end = 40.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    groups.forEachIndexed { gi, (letter, list) ->
                        item(key = "g$gi$letter") {
                            Column {
                                if (headers) {
                                    Box(
                                        Modifier.padding(start = 6.dp, bottom = 8.dp).size(48.dp)
                                            .clip(shapeOf("cookie")).background(s.primary),
                                        contentAlignment = Alignment.Center
                                    ) { Text(letter, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = s.onPrimary) }
                                }
                                Column(
                                    Modifier.fillMaxWidth().clip(rc(32)).background(s.surfaceContainer)
                                        .padding(horizontal = 6.dp, vertical = 10.dp)
                                ) {
                                    list.chunked(cols).forEach { row ->
                                        Row(Modifier.fillMaxWidth()) {
                                            row.forEach { app ->
                                                val canDrag = q.isBlank()
                                                AppItem(
                                                    app, prefs.showLabels, s.onSurface, menuFor(app),
                                                    Modifier.weight(1f).then(
                                                        if (canDrag && drag.target == app.pkg) Modifier.clip(rc(20)).background(s.primaryContainer.copy(alpha = .7f))
                                                        else Modifier
                                                    ),
                                                    prefs.drawerIconSize,
                                                    hidden = drag.pkg == app.pkg,
                                                    drag = if (canDrag) drag else null,
                                                    onSwap = doSwap
                                                )
                                            }
                                            repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (filtered.isEmpty()) item {
                        Text(
                            "Ничего не найдено", color = s.onSurfaceVariant,
                            modifier = Modifier.fillMaxWidth().padding(32.dp)
                        )
                    }
                }
                // нижняя панель: поиск + меню
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(30.dp))
                            .background(s.surfaceContainerHigh).padding(start = 6.dp, end = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(48.dp).clip(shapeOf("cookie")).background(s.primary),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Rounded.Search, null, tint = s.onPrimary) }
                        Spacer(Modifier.width(12.dp))
                        BasicTextField(
                            value = q, onValueChange = { q = it }, singleLine = true,
                            textStyle = TextStyle(color = s.onSurface, fontSize = 17.sp),
                            cursorBrush = SolidColor(s.primary),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                filtered.firstOrNull()?.let { open(it, null) }
                            }),
                            modifier = Modifier.weight(1f),
                            decorationBox = { inner ->
                                Box(contentAlignment = Alignment.CenterStart) {
                                    if (q.isEmpty()) Text("Поиск приложений", color = s.onSurfaceVariant, fontSize = 17.sp)
                                    inner()
                                }
                            }
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Box {
                        Box(
                            Modifier.size(60.dp).clip(CircleShape).background(s.primaryContainer)
                                .clickable { menu = true },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Rounded.MoreVert, null, tint = s.onPrimaryContainer) }
                        DropdownMenu(
                            expanded = menu, onDismissRequest = { menu = false },
                            shape = rc(20), containerColor = s.surfaceContainerHigh,
                            tonalElevation = 0.dp, shadowElevation = 8.dp
                        ) {
                            DropdownMenuItem(
                                text = { Text("Настройки лаунчера") },
                                leadingIcon = { Icon(Icons.Rounded.Settings, null) },
                                onClick = { menu = false; a.openSettings() }
                            )
                            if (prefs.drawerOrder.isNotEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("Сбросить порядок иконок") },
                                    leadingIcon = { Icon(Icons.Rounded.Refresh, null) },
                                    onClick = { menu = false; prefs.drawerOrder = "" }
                                )
                            }
                        }
                    }
                }
            }
            // переносимая иконка идёт за пальцем
            drag.pkg?.let { dragPkg ->
                ordered.firstOrNull { it.pkg == dragPkg }?.let { dapp ->
                    val half = with(LocalDensity.current) { (prefs.drawerIconSize.dp / 2).toPx() }
                    Box(
                        Modifier
                            .offset { IntOffset((drag.pos.x - drag.origin.x - half).roundToInt(), (drag.pos.y - drag.origin.y - half).roundToInt()) }
                            .graphicsLayer { scaleX = 1.2f; scaleY = 1.2f; alpha = .92f }
                    ) { AppIcon(dapp, prefs.drawerIconSize.dp) }
                }
            }
            if (headers && groups.size > 1) {
                val letters = groups.map { it.first }
                AlphabetIndex(
                    letters, activeLetter,
                    Modifier.align(Alignment.CenterEnd).padding(end = 4.dp, bottom = 40.dp).fillMaxHeight(.84f),
                    onJump = { i -> scope.launch { state.scrollToItem(i) } },
                    onDrag = { bubble = it }
                )
            }
            bubble?.let {
                Box(
                    Modifier.align(Alignment.CenterEnd).padding(end = 52.dp, bottom = 40.dp).size(76.dp)
                        .clip(shapeOf("cookie")).background(s.primary),
                    contentAlignment = Alignment.Center
                ) { Text(it, fontSize = 34.sp, fontWeight = FontWeight.Black, color = s.onPrimary) }
            }
        }
    }
}

@Composable
private fun AlphabetIndex(
    letters: List<String>, active: String, modifier: Modifier,
    onJump: (Int) -> Unit, onDrag: (String?) -> Unit
) {
    val s = MaterialTheme.colorScheme
    val fs = if (letters.size > 34) 9.sp else 11.sp
    Column(
        modifier.width(28.dp).pointerInput(letters) {
            awaitEachGesture {
                val down = awaitFirstDown()
                val hit = { y: Float ->
                    val i = (y / size.height * letters.size).toInt().coerceIn(0, letters.size - 1)
                    onJump(i)
                    onDrag(letters[i])
                }
                hit(down.position.y)
                down.consume()
                do {
                    val e = awaitPointerEvent()
                    e.changes.firstOrNull()?.let { hit(it.position.y); it.consume() }
                } while (e.changes.any { it.pressed })
                onDrag(null)
            }
        },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        letters.forEach { l ->
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    l, fontSize = fs, fontWeight = FontWeight.Bold,
                    color = if (l == active) s.onPrimary else s.onSurfaceVariant,
                    modifier = if (l == active) Modifier.clip(CircleShape).background(s.primary).padding(horizontal = 4.dp)
                    else Modifier
                )
            }
        }
    }
}

@Composable
fun WidgetPicker(a: MainActivity, onClose: () -> Unit) {
    val s = MaterialTheme.colorScheme
    val pm = a.packageManager
    // Список виджетов системы большой: собираем и сортируем в фоне, чтобы окно открывалось без задержки.
    // Виджеты сразу группируются по приложениям (пакет, название, виджеты).
    val groups by produceState(emptyList<Triple<String, String, List<android.appwidget.AppWidgetProviderInfo>>>()) {
        value = withContext(kotlinx.coroutines.Dispatchers.Default) {
            val labels = HashMap<android.appwidget.AppWidgetProviderInfo, String>()
            val byPkg = a.wm.installedProviders.groupBy { it.provider.packageName }
            byPkg.map { (pkg, ws) ->
                val name = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
                ws.forEach { labels[it] = runCatching { it.loadLabel(pm) }.getOrDefault("") }
                Triple(pkg, name, ws.sortedBy { labels[it]?.lowercase() ?: "" })
            }.sortedWith(compareBy({ scriptRank(it.second) }, { it.second.lowercase() }))
        }
    }
    var expanded by remember { mutableStateOf<String?>(null) }
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(.5f)).clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null
        ) { onClose() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            shape = rc(32), color = s.surface,
            modifier = Modifier.fillMaxWidth().fillMaxHeight(.78f).clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null
            ) {}
        ) {
            Column {
                Text("Виджеты", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(24.dp, 22.dp, 24.dp, 8.dp))
                LazyColumn(
                    contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item(key = "h_classic") { WidgetSectionLabel("Классические") }
                    // встроенные виджеты лаунчера (рисует сам лаунчер, а не какое-то приложение)
                    item(key = "clock") {
                        Row(
                            Modifier.fillMaxWidth().clip(rc(24)).background(s.surfaceContainer)
                                .clickable { a.addClockWidget(); onClose() }.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ClockFace("circle", "analog", Modifier.size(96.dp))
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text("Часы Material You", fontWeight = FontWeight.SemiBold, color = s.onSurface)
                                Text("Лаунчер · 3×3 · вид и форму можно менять", fontSize = 12.sp, color = s.onSurfaceVariant)
                            }
                        }
                    }
                    item(key = "h_apps") { WidgetSectionLabel("Виджеты приложений") }
                    groups.forEach { (pkg, name, ws) ->
                        item(key = "g:$pkg") {
                            val icon by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, pkg) {
                                value = withContext(kotlinx.coroutines.Dispatchers.IO) {
                                    runCatching { pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
                                }
                            }
                            val open = expanded == pkg
                            Row(
                                Modifier.fillMaxWidth().clip(rc(24)).background(if (open) s.primaryContainer else s.surfaceContainer)
                                    .clickable { expanded = if (open) null else pkg }.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val ic = icon
                                if (ic != null) Image(ic, null, Modifier.size(40.dp).clip(CircleShape))
                                else Spacer(Modifier.size(40.dp))
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(name, fontWeight = FontWeight.SemiBold, color = if (open) s.onPrimaryContainer else s.onSurface)
                                    Text(
                                        "${ws.size} ${widgetWord(ws.size)}", fontSize = 12.sp,
                                        color = if (open) s.onPrimaryContainer else s.onSurfaceVariant
                                    )
                                }
                                Text(if (open) "▴" else "▾", fontSize = 18.sp, color = if (open) s.onPrimaryContainer else s.onSurfaceVariant)
                            }
                        }
                        if (expanded == pkg) items(ws, key = { "w:" + it.provider.flattenToString() }) { p ->
                            WidgetCard(a, p, name) { a.addWidget(p); onClose() }
                        }
                    }
                }
            }
        }
    }
}

private fun widgetWord(n: Int): String = when {
    n % 100 in 11..14 -> "виджетов"
    n % 10 == 1 -> "виджет"
    n % 10 in 2..4 -> "виджета"
    else -> "виджетов"
}

@Composable
private fun WidgetSectionLabel(text: String) {
    Text(
        text, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 2.dp)
    )
}

@Composable
private fun WidgetCard(a: MainActivity, p: android.appwidget.AppWidgetProviderInfo, appLabel: String, onPick: () -> Unit) {
    val s = MaterialTheme.colorScheme
    val pm = a.packageManager
    val preview by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, p) {
        value = withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                val d = p.loadPreviewImage(a, 0) ?: p.loadIcon(a, 0)
                val w = d.intrinsicWidth.coerceIn(96, 600)
                val h = d.intrinsicHeight.coerceIn(96, 400)
                d.toBitmap(w, h).asImageBitmap()
            }.getOrNull()
        }
    }
    val cells = if (Build.VERSION.SDK_INT >= 31 && p.targetCellWidth > 0)
        "${p.targetCellWidth}×${p.targetCellHeight}"
    else "${((p.minWidth + 30) / 70).coerceAtLeast(1)}×${((p.minHeight + 30) / 70).coerceAtLeast(1)}"
    Column(
        Modifier.fillMaxWidth().padding(start = 12.dp).clip(rc(24)).background(s.surfaceContainerHigh)
            .clickable(onClick = onPick).padding(14.dp)
    ) {
        val pv = preview
        if (pv != null) {
            Box(
                Modifier.fillMaxWidth().clip(rc(16)).background(s.surfaceContainerHighest).padding(10.dp),
                contentAlignment = Alignment.Center
            ) { Image(pv, null, Modifier.heightIn(max = 110.dp), contentScale = ContentScale.Fit) }
            Spacer(Modifier.height(10.dp))
        }
        Text(p.loadLabel(pm), fontWeight = FontWeight.SemiBold, color = s.onSurface)
        Text("$appLabel · $cells", fontSize = 12.sp, color = s.onSurfaceVariant)
    }
}
