package com.kyy.launcher

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun letterOf(label: String): String {
    val c = label.trim().firstOrNull()?.uppercaseChar() ?: return "#"
    return if (c.isLetter()) c.toString() else "#"
}

/** Порядок разделов: # , латиница, кириллица, остальное. */
private fun rank(l: String): String {
    if (l == "#") return "0"
    val c = l[0]
    return when {
        c in 'A'..'Z' -> "1$l"
        c in '\u0410'..'\u042F' || c == '\u0401' -> "2$l"
        else -> "3$l"
    }
}

@Composable
fun Drawer(
    a: MainActivity, apps: List<AppInfo>, onClose: () -> Unit,
    menuFor: (AppInfo) -> List<MenuAction>
) {
    val s = MaterialTheme.colorScheme
    val open = LocalOpen.current
    var q by remember { mutableStateOf("") }
    val filtered = remember(apps, q) { if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), true) } }
    val headers = q.isBlank()
    val groups: List<Pair<String, List<AppInfo>>> = remember(filtered, headers) {
        if (headers) filtered.groupBy { letterOf(it.label) }.toList().sortedBy { rank(it.first) }
        else listOf("" to filtered)
    }
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val cols = prefs.drawerCols
    var bubble by remember { mutableStateOf<String?>(null) }
    var menu by remember { mutableStateOf(false) }
    val firstVisible by remember { derivedStateOf { state.firstVisibleItemIndex } }
    val activeLetter = groups.getOrNull(firstVisible)?.first ?: ""

    Surface(Modifier.fillMaxSize(), color = s.surface.copy(alpha = .97f)) {
        Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            Column(Modifier.fillMaxSize()) {
                var drag by remember { mutableFloatStateOf(0f) }
                Column(
                    Modifier.pointerInput(Unit) {
                        detectVerticalDragGestures(onDragEnd = { drag = 0f }, onDragCancel = { drag = 0f }) { _, dy ->
                            drag += dy
                            if (drag > 150f) { drag = 0f; onClose() }
                        }
                    }
                ) {
                    Box(
                        Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp)
                            .size(width = 36.dp, height = 4.dp).clip(CircleShape).background(s.outlineVariant)
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = 12.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Приложения", fontSize = 34.sp, fontWeight = FontWeight.Black,
                            color = s.onSurface, modifier = Modifier.weight(1f)
                        )
                        Box(
                            Modifier.size(52.dp).clip(shapeOf("cookie")).background(s.primary),
                            contentAlignment = Alignment.Center
                        ) { Text("${apps.size}", fontWeight = FontWeight.Bold, color = s.onPrimary, fontSize = 16.sp) }
                    }
                }
                LazyColumn(
                    state = state, modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 12.dp, end = 40.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    groups.forEachIndexed { gi, (letter, list) ->
                        item(key = "g$gi$letter") {
                            Column {
                                if (headers) {
                                    Box(
                                        Modifier.padding(start = 6.dp, bottom = 8.dp).size(48.dp)
                                            .clip(shapeOf("cookie")).background(s.primary),
                                        contentAlignment = Alignment.Center
                                    ) { Text(letter, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = s.onPrimary) }
                                }
                                Column(
                                    Modifier.fillMaxWidth().clip(rc(32)).background(s.surfaceContainer)
                                        .padding(horizontal = 6.dp, vertical = 10.dp)
                                ) {
                                    list.chunked(cols).forEach { row ->
                                        Row(Modifier.fillMaxWidth()) {
                                            row.forEach { app ->
                                                AppItem(app, prefs.showLabels, s.onSurface, menuFor(app), Modifier.weight(1f), prefs.drawerIconSize)
                                            }
                                            repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (filtered.isEmpty()) item {
                        Text(
                            "Ничего не найдено", color = s.onSurfaceVariant,
                            modifier = Modifier.fillMaxWidth().padding(32.dp)
                        )
                    }
                }
                // нижняя панель: поиск + меню
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(30.dp))
                            .background(s.surfaceContainerHigh).padding(start = 6.dp, end = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(48.dp).clip(shapeOf("cookie")).background(s.primary),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.Search, null, tint = s.onPrimary) }
                        Spacer(Modifier.width(12.dp))
                        BasicTextField(
                            value = q, onValueChange = { q = it }, singleLine = true,
                            textStyle = TextStyle(color = s.onSurface, fontSize = 17.sp),
                            cursorBrush = SolidColor(s.primary),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                filtered.firstOrNull()?.let { open(it, null) }
                            }),
                            modifier = Modifier.weight(1f),
                            decorationBox = { inner ->
                                Box(contentAlignment = Alignment.CenterStart) {
                                    if (q.isEmpty()) Text("Поиск приложений", color = s.onSurfaceVariant, fontSize = 17.sp)
                                    inner()
                                }
                            }
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Box {
                        Box(
                            Modifier.size(60.dp).clip(CircleShape).background(s.primaryContainer)
                                .clickable { menu = true },
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.MoreVert, null, tint = s.onPrimaryContainer) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { Text("Настройки лаунчера") },
                                onClick = { menu = false; a.openSettings() }
                            )
                        }
                    }
                }
            }
            if (headers && groups.size > 1) {
                val letters = groups.map { it.first }
                AlphabetIndex(
                    letters, activeLetter,
                    Modifier.align(Alignment.CenterEnd).padding(end = 4.dp, bottom = 40.dp).fillMaxHeight(.84f),
                    onJump = { i -> scope.launch { state.scrollToItem(i) } },
                    onDrag = { bubble = it }
                )
            }
            bubble?.let {
                Box(
                    Modifier.align(Alignment.CenterEnd).padding(end = 52.dp, bottom = 40.dp).size(76.dp)
                        .clip(shapeOf("cookie")).background(s.primary),
                    contentAlignment = Alignment.Center
                ) { Text(it, fontSize = 34.sp, fontWeight = FontWeight.Black, color = s.onPrimary) }
            }
        }
    }
}

@Composable
private fun AlphabetIndex(
    letters: List<String>, active: String, modifier: Modifier,
    onJump: (Int) -> Unit, onDrag: (String?) -> Unit
) {
    val s = MaterialTheme.colorScheme
    val fs = if (letters.size > 34) 9.sp else 11.sp
    Column(
        modifier.width(28.dp).pointerInput(letters) {
            awaitEachGesture {
                val down = awaitFirstDown()
                val hit = { y: Float ->
                    val i = (y / size.height * letters.size).toInt().coerceIn(0, letters.size - 1)
                    onJump(i)
                    onDrag(letters[i])
                }
                hit(down.position.y)
                down.consume()
                do {
                    val e = awaitPointerEvent()
                    e.changes.firstOrNull()?.let { hit(it.position.y); it.consume() }
                } while (e.changes.any { it.pressed })
                onDrag(null)
            }
        },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        letters.forEach { l ->
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    l, fontSize = fs, fontWeight = FontWeight.Bold,
                    color = if (l == active) s.onPrimary else s.onSurfaceVariant,
                    modifier = if (l == active) Modifier.clip(CircleShape).background(s.primary).padding(horizontal = 4.dp)
                    else Modifier
                )
            }
        }
    }
}

@Composable
fun WidgetPicker(a: MainActivity, onClose: () -> Unit) {
    val s = MaterialTheme.colorScheme
    val pm = a.packageManager
    // Список виджетов системы большой: собираем и сортируем в фоне, чтобы окно открывалось без задержки
    val list by produceState(emptyList<android.appwidget.AppWidgetProviderInfo>()) {
        value = withContext(kotlinx.coroutines.Dispatchers.Default) {
            val appNames = HashMap<String, String>()
            val labels = HashMap<android.appwidget.AppWidgetProviderInfo, String>()
            val raw = a.wm.installedProviders
            for (w in raw) {
                val pkg = w.provider.packageName
                if (pkg !in appNames) {
                    appNames[pkg] = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString().lowercase() }.getOrDefault("")
                }
                labels[w] = runCatching { w.loadLabel(pm).lowercase() }.getOrDefault("")
            }
            raw.sortedWith(
                compareBy({ it.provider.packageName != a.packageName }, { appNames[it.provider.packageName] ?: "" }, { labels[it] ?: "" })
            )
        }
    }
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(.5f)).clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null
        ) { onClose() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            shape = rc(32), color = s.surface,
            modifier = Modifier.fillMaxWidth().fillMaxHeight(.78f).clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null
            ) {}
        ) {
            Column {
                Text("Виджеты", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(24.dp, 22.dp, 24.dp, 8.dp))
                LazyColumn(
                    contentPadding = PaddingValues(12.dp, 4.dp, 12.dp, 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(list) { p ->
                        val appLabel = remember(p) {
                            runCatching { pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString() }.getOrDefault("")
                        }
                        val preview by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, p) {
                            value = withContext(kotlinx.coroutines.Dispatchers.IO) {
                                runCatching {
                                    val d = p.loadPreviewImage(a, 0) ?: p.loadIcon(a, 0)
                                    val w = d.intrinsicWidth.coerceIn(96, 600)
                                    val h = d.intrinsicHeight.coerceIn(96, 400)
                                    d.toBitmap(w, h).asImageBitmap()
                                }.getOrNull()
                            }
                        }
                        val cells = if (Build.VERSION.SDK_INT >= 31 && p.targetCellWidth > 0)
                            "${p.targetCellWidth}×${p.targetCellHeight}"
                        else "${((p.minWidth + 30) / 70).coerceAtLeast(1)}×${((p.minHeight + 30) / 70).coerceAtLeast(1)}"
                        Column(
                            Modifier.fillMaxWidth().clip(rc(24)).background(s.surfaceContainer)
                                .clickable { a.addWidget(p); onClose() }.padding(14.dp)
                        ) {
                            val pv = preview
                            if (pv != null) {
                                Box(
                                    Modifier.fillMaxWidth().clip(rc(16)).background(s.surfaceContainerHighest).padding(10.dp),
                                    contentAlignment = Alignment.Center
                                ) { Image(pv, null, Modifier.heightIn(max = 110.dp), contentScale = ContentScale.Fit) }
                                Spacer(Modifier.height(10.dp))
                            }
                            Text(p.loadLabel(pm), fontWeight = FontWeight.SemiBold, color = s.onSurface)
                            Text("$appLabel · $cells", fontSize = 12.sp, color = s.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
