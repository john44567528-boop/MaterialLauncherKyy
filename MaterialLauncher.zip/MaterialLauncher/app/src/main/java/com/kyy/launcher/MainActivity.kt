package com.kyy.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.view.RoundedCorner
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp as lerpColor
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.PI
import kotlin.math.abs
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.util.addPointerInputChange
import kotlin.math.sin
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.Density
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

const val GOOGLE_APP = "com.google.android.googlequicksearchbox"

class MainActivity : ComponentActivity() {
    lateinit var host: AppWidgetHost
    lateinit var wm: AppWidgetManager
    val resume = mutableIntStateOf(0)
    val goHome = mutableIntStateOf(0)
    val stops = mutableIntStateOf(0)
    val unlockTick = mutableIntStateOf(0)
    /** Текущая страница рабочего стола, идёт ли листание и где на экране лежит область страниц (для привязки анимации запуска к странице). */
    val homePage = mutableIntStateOf(0)
    val pageScrolling = mutableStateOf(false)
    var pagerBounds: Rect? = null
    /** Экран выключен, пока лаунчер был на виду: рабочий стол заранее спрятан в стартовое состояние анимации. */
    val unlockArmed = mutableStateOf(false)
    /** Свой экран блокировки виден (показывается после обычной разблокировки; рабочий стол под ним спрятан). */
    val lockShown = mutableStateOf(false)
    val appsVersion = mutableIntStateOf(0)
    private var offWhileHome = false
    val widgets = mutableStateListOf<Int>()
    val rects = mutableStateMapOf<Int, WRect>()
    /** На какой странице рабочего стола стоит виджет (id -> страница). */
    val widgetPage = mutableStateMapOf<Int, Int>()
    val editWidget = mutableIntStateOf(-1)
    val qsb = mutableIntStateOf(-1)
    private var pendingId = -1
    private var pendingQsb = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        edgeToEdgeTransparent()
        // Переходы лаунчера рисует он сам; системный переход поверх даёт двойную анимацию закрытия
        if (Build.VERSION.SDK_INT >= 34) {
            overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, 0, 0)
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
        }
        host = AppWidgetHost(this, 1024)
        wm = AppWidgetManager.getInstance(this)
        widgets.addAll(prefs.widgets.split(",").mapNotNull { it.toIntOrNull() })
        loadWidgetPages()
        loadRects()
        val saved = prefs.qsbId
        qsb.intValue = if (saved != -1 && wm.getAppWidgetInfo(saved) != null) saved else -1
        setContent { LauncherTheme { Home(this) } }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        val pf = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, pf, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private var lastUnlockAt = 0L
    private var startedAt = 0L
    /** true, если на рабочий стол вернулись из «окон» (недавних): лаунчер был виден, но не активен — анимацию закрытия не рисуем. */
    var viaRecents = false
    private var userPresentAt = 0L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF ->
                    if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
                        offWhileHome = true
                        lockShown.value = false   // после следующей разблокировки экран блокировки покажется заново
                        armUnlock()
                    }
                Intent.ACTION_SCREEN_ON ->
                    // без экрана блокировки USER_PRESENT может не прийти — проверяем сами
                    if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) tryUnlock()
                Intent.ACTION_USER_PRESENT ->
                    // разблокировали: лаунчер уже на виду — играем сразу, иначе дождёмся onResume / фокуса окна
                    if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) playUnlock()
                    else userPresentAt = SystemClock.elapsedRealtime()
            }
        }
    }

    /** Список приложений обновляем только при установке/удалении, а не при каждом возврате домой. */
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            // при обновлении приложения система шлёт REMOVED (с EXTRA_REPLACING), а затем ADDED: пока оно «удалено», в списке
            // его нет, и обновлять список в этот момент нельзя. Дождёмся ADDED / REPLACED.
            if (i.action == Intent.ACTION_PACKAGE_REMOVED && i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
            i.data?.schemeSpecificPart?.let { IconCache.evict(it) }
            appsVersion.intValue++
        }
    }

    private fun lockOn() = prefs.lockEnabled && prefs.welcomeDone

    private fun armUnlock() { if ((prefs.animsEnabled && prefs.unlockAnim) || lockOn()) unlockArmed.value = true }

    /** Отпечаток «отсканирован»: прячем экран блокировки и играем разблокировку рабочего стола. */
    fun dismissLock() {
        unlockArmed.value = true   // рабочий стол остаётся спрятанным, пока не стартует анимация (без вспышки)
        lockShown.value = false
        unlockTick.intValue++
    }

    private fun playUnlock() {
        val now = SystemClock.elapsedRealtime()
        userPresentAt = 0L
        offWhileHome = false
        if (now - lastUnlockAt < 1200) { unlockArmed.value = false; return }
        lastUnlockAt = now
        if (lockOn()) {
            // сначала обычная разблокировка, затем наш экран блокировки; рабочий стол откроется по отпечатку
            lockShown.value = true
            unlockArmed.value = false
            return
        }
        unlockTick.intValue++
    }

    /** Все возможные пути к анимации разблокировки: USER_PRESENT, onResume, фокус окна. */
    fun tryUnlock() {
        val now = SystemClock.elapsedRealtime()
        if (userPresentAt != 0L && now - userPresentAt < 3000) { playUnlock(); return }
        if (!offWhileHome) return
        val km = getSystemService(KeyguardManager::class.java)
        val pw = getSystemService(PowerManager::class.java)
        if (km?.isKeyguardLocked == true || pw?.isInteractive == false) return
        playUnlock()
    }

    private var visibleSince = 0L

    /**
     * Страховка: рабочий стол спрятан (ждём разблокировку), но на деле уже на виду и в фокусе
     * дольше ~1,5 с — значит сигнал разблокировки не пришёл. Играем анимацию, чтобы не остаться с пустым экраном.
     */
    fun unlockWatchdog() {
        val pw = getSystemService(PowerManager::class.java)
        val seen = hasWindowFocus() && pw?.isInteractive == true && lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
        if (!seen) { visibleSince = 0L; return }
        val now = SystemClock.elapsedRealtime()
        if (visibleSince == 0L) visibleSince = now
        else if (now - visibleSince > 1500L) { visibleSince = 0L; playUnlock() }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) tryUnlock()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
    }

    override fun onStart() {
        super.onStart()
        startedAt = SystemClock.elapsedRealtime()
        try { host.startListening() } catch (_: Exception) {}
    }

    override fun onStop() {
        super.onStop()
        stops.intValue++
        val km = getSystemService(KeyguardManager::class.java)
        val pw = getSystemService(PowerManager::class.java)
        if (pw?.isInteractive == false || km?.isKeyguardLocked == true) { offWhileHome = true; armUnlock() }
        try { host.stopListening() } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        val now = SystemClock.elapsedRealtime()
        // при прямом возврате из приложения onStart и onResume идут подряд; из «окон» между ними проходит заметное время
        viaRecents = startedAt != 0L && now - startedAt > 350L
        startedAt = now
        resume.intValue++
        tryUnlock()
        if (prefs.previewUnlock) { prefs.previewUnlock = false; armUnlock(); unlockTick.intValue++ }
        if (qsb.intValue != prefs.qsbId) qsb.intValue = prefs.qsbId
        if (qsb.intValue != -1 && wm.getAppWidgetInfo(qsb.intValue) == null) {
            qsb.intValue = -1
            prefs.qsbId = -1
        }
        if (prefs.showSearch) ensureQsb()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) goHome.intValue++
    }

    /** Запуск приложения (анимацию открытия рисует Home до вызова). */
    fun startApp(app: AppInfo): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val o = ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out)
        return try { startActivity(i, o.toBundle()); true } catch (_: Exception) { false }
    }

    fun openSettings() { startActivity(Intent(this, SettingsActivity::class.java)) }

    /** Вернуться на рабочий стол (отменяет запускаемое приложение, если оно ещё не показалось). */
    fun goHomeNow() {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }

    fun openSearch() {
        val i = packageManager.getLaunchIntentForPackage(GOOGLE_APP) ?: Intent(Intent.ACTION_WEB_SEARCH)
        try { startActivity(i) } catch (_: Exception) {}
    }

    fun openWallpapers() {
        try {
            startActivity(Intent().setComponent(ComponentName(
                "com.google.android.apps.wallpaper",
                "com.google.android.apps.wallpaper.picker.CategoryPickerActivity")))
        } catch (e: Exception) {
            try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои")) } catch (_: Exception) {}
        }
    }

    // ---- виджет Google «Поиск» (searchbox) ----
    /**
     * Виджет-поисковик Google имеет категорию searchbox и НЕ попадает в installedProviders
     * (там только home_screen) — поэтому ищем его через getInstalledProvidersForPackage.
     */
    fun findQsb(): AppWidgetProviderInfo? {
        val box = try {
            wm.getInstalledProvidersForPackage(GOOGLE_APP, null)
                .filter { (it.widgetCategory and AppWidgetProviderInfo.WIDGET_CATEGORY_SEARCHBOX) != 0 }
        } catch (_: Exception) { emptyList() }
        box.firstOrNull()?.let { return it }
        return try {
            wm.installedProviders.firstOrNull {
                it.provider.packageName == GOOGLE_APP &&
                    (it.provider.className.contains("Search", true) || it.provider.className.contains("Qsb", true))
            }
        } catch (_: Exception) { null }
    }

    private fun qsbOptions() = Bundle().apply {
        putInt(AppWidgetManager.OPTION_APPWIDGET_HOST_CATEGORY, AppWidgetProviderInfo.WIDGET_CATEGORY_SEARCHBOX)
    }

    fun ensureQsb(force: Boolean = false) {
        if (qsb.intValue != -1 || pendingQsb != -1) return
        if (!force && prefs.qsbAsked) return
        val p = findQsb() ?: return
        val id = host.allocateAppWidgetId()
        val o = qsbOptions()
        val ok = try { wm.bindAppWidgetIdIfAllowed(id, p.provider, o) } catch (_: Exception) { false }
        if (ok) {
            setQsb(id)
        } else {
            pendingQsb = id
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(
                    Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_OPTIONS, o), 13
                )
            } catch (_: Exception) {
                host.deleteAppWidgetId(id)
                pendingQsb = -1
            }
        }
    }

    private fun setQsb(id: Int) {
        qsb.intValue = id
        prefs.qsbId = id
        prefs.qsbAsked = false
        pendingQsb = -1
    }

    // ---- виджеты ----
    fun addWidget(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        if (wm.bindAppWidgetIdIfAllowed(id, p.provider)) {
            configureOrCommit(id)
        } else {
            @Suppress("DEPRECATION")
            startActivityForResult(
                Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider), 11
            )
        }
    }

    private fun configureOrCommit(id: Int) {
        val info = wm.getAppWidgetInfo(id)
        if (info?.configure != null) {
            try { host.startAppWidgetConfigureActivityForResult(this, id, 0, 12, null) }
            catch (e: Exception) { commit(id) }
        } else commit(id)
    }

    private fun commit(id: Int) {
        widgets.add(id)
        widgetPage[id] = homePage.intValue   // новый виджет появляется на той странице, где человек сейчас
        rects[id] = defaultRect(id)
        prefs.widgets = widgets.joinToString(",")
        saveWidgetPages()
        saveRects()
        pendingId = -1
    }

    // ---- положение и размер виджетов (dp, от левого верхнего угла главного экрана) ----
    private fun defaultRect(id: Int): WRect {
        val d = resources.displayMetrics.density
        val sw = resources.displayMetrics.widthPixels / d
        val info = wm.getAppWidgetInfo(id)
        val iw = (info?.minWidth ?: 0) / d
        val w = if (iw >= 200f) sw - 32f else maxOf(iw, 110f)
        val h = maxOf((info?.minHeight ?: 0) / d, (info?.minResizeHeight ?: 0) / d, 64f)
        val pg = widgetPage[id] ?: 0
        val baseY = 12f
        val bottom = rects.entries.filter { it.key in widgets && it.key != id && (widgetPage[it.key] ?: 0) == pg }
            .maxOfOrNull { it.value.y + it.value.h + 8f } ?: baseY
        return WRect(16f, maxOf(baseY, bottom), w, h)
    }

    private fun loadRects() {
        prefs.widgetRects.split(";").forEach { item ->
            val p = item.split(":")
            if (p.size == 5) {
                val id = p[0].toIntOrNull()
                val v = p.drop(1).mapNotNull { it.toFloatOrNull() }
                if (id != null && v.size == 4) rects[id] = WRect(v[0], v[1], v[2], v[3])
            }
        }
        widgets.toList().forEach { if (rects[it] == null) rects[it] = defaultRect(it) }
    }

    private fun loadWidgetPages() {
        prefs.widgetPages.split(";").forEach { item ->
            val p = item.split(":")
            val id = p.getOrNull(0)?.toIntOrNull()
            val pg = p.getOrNull(1)?.toIntOrNull()
            if (id != null && pg != null && id in widgets) widgetPage[id] = pg.coerceAtLeast(0)
        }
        HomeMetrics.widgetPages = widgetPage
        HomeMetrics.onWidgetPagesChanged = { saveWidgetPages() }
    }

    fun saveWidgetPages() {
        prefs.widgetPages = widgetPage.entries.filter { it.key in widgets }.joinToString(";") { "${it.key}:${it.value}" }
    }

    /** Перенести виджет на соседнюю страницу (delta = -1 влево, +1 вправо; справа от последней создаётся новая). */
    fun moveWidgetPage(id: Int, delta: Int) {
        val cur = widgetPage[id] ?: 0
        val list = parseHome(prefs.homeItems)
        val max = maxOf(list.maxOfOrNull { it.page } ?: 0, widgetPage.values.maxOrNull() ?: 0)
        val to = (cur + delta).coerceIn(0, max + 1)
        if (to == cur) return
        widgetPage[id] = to
        // убираем опустевшие страницы и сдвигаем номера (у виджетов тоже)
        val enc = list.compacted().encode()
        if (enc != prefs.homeItems) prefs.homeItems = enc
        saveWidgetPages()
    }

    fun saveRects() {
        prefs.widgetRects = rects.entries.filter { it.key in widgets }
            .joinToString(";") { (id, r) -> "$id:${r.x.roundToInt()}:${r.y.roundToInt()}:${r.w.roundToInt()}:${r.h.roundToInt()}" }
    }

    private fun cancelPending() {
        if (pendingId != -1) host.deleteAppWidgetId(pendingId)
        pendingId = -1
    }

    fun removeWidget(id: Int) {
        host.deleteAppWidgetId(id)
        widgets.remove(id)
        rects.remove(id)
        widgetPage.remove(id)
        saveWidgetPages()
        if (editWidget.intValue == id) editWidget.intValue = -1
        prefs.widgets = widgets.joinToString(",")
        saveRects()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            11 -> if (resultCode == RESULT_OK) configureOrCommit(pendingId) else cancelPending()
            12 -> if (resultCode == RESULT_OK) commit(pendingId) else cancelPending()
            13 -> if (resultCode == RESULT_OK) setQsb(pendingQsb)
                  else { host.deleteAppWidgetId(pendingQsb); pendingQsb = -1; prefs.qsbAsked = true }
        }
    }
}

fun defaultDock(ctx: Context, apps: List<AppInfo>): String {
    val pm = ctx.packageManager
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE)
    )
    val known = apps.map { it.pkg }.toSet()
    return intents.mapNotNull {
        try { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName } catch (e: Exception) { null }
    }.filter { it in known }.distinct().joinToString("|")
}

fun Modifier.homeGestures(onLong: (Offset) -> Unit, onUp: () -> Unit, onPinch: () -> Unit): Modifier =
    this.pointerInput(Unit) { detectTapGestures(onLongPress = { onLong(it) }) }
        .pointerInput(Unit) {
            // Свайп вверх: смотрим на касания в финальном проходе (после детей), чтобы не мешать переносу иконок,
            // порог небольшой, а быстрый «бросок» срабатывает по скорости, не дожидаясь длинного пути.
            val dist = 40f * density
            val flingDist = 16f * density
            val flingV = 600f * density
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Final)
                val tracker = VelocityTracker()
                var dx = 0f
                var dy = 0f
                var start = 0f
                var done = false
                do {
                    val ev = awaitPointerEvent(PointerEventPass.Final)
                    val pr = ev.changes.filter { it.pressed }
                    if (!done) {
                        if (pr.size >= 2) {
                            val d = (pr[0].position - pr[1].position).getDistance()
                            if (start == 0f) start = d
                            else if (d < start * 0.8f) { done = true; onPinch() }
                        } else if (pr.size == 1) {
                            val c = pr[0]
                            if (!c.isConsumed) {
                                tracker.addPointerInputChange(c)
                                val pc = c.positionChange()
                                dx += pc.x
                                dy += pc.y
                                if (dy < -dist && abs(dy) > abs(dx) * 1.2f) { done = true; onUp() }
                            }
                        }
                    }
                } while (ev.changes.any { it.pressed })
                if (!done && dy < -flingDist && abs(dy) > abs(dx) * 1.2f && -tracker.calculateVelocity().y > flingV) onUp()
            }
        }

/** Появление / уход нижних окон (виджеты, обои): лёгкий подъём снизу и затухание. */
fun sheetEnter(on: Boolean, speed: Float): EnterTransition =
    if (!on) EnterTransition.None
    else slideInVertically(tween((320 / speed).toInt().coerceAtLeast(90), easing = CubicBezierEasing(0.2f, 0f, 0f, 1f))) { it / 4 } +
        fadeIn(tween((200 / speed).toInt().coerceAtLeast(60)))

fun sheetExit(on: Boolean, speed: Float): ExitTransition =
    if (!on) ExitTransition.None
    else slideOutVertically(tween((240 / speed).toInt().coerceAtLeast(80), easing = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f))) { it / 4 } +
        fadeOut(tween((180 / speed).toInt().coerceAtLeast(60)))

/** page — страница рабочего стола, на которой лежала иконка (-1: док, меню приложений — не привязано к странице). */
class Launch(val app: AppInfo, val rect: Rect, val stopsAt: Int, val seq: Int, val fromDrawer: Boolean = false, val page: Int = -1, val tile: Boolean = false) {
    var t0 = SystemClock.uptimeMillis()
    val p = Animatable(0f)
    var started by mutableStateOf(false)
    var reverse by mutableStateOf(false)
    var aborted = false
}

val LocalOpen = staticCompositionLocalOf<(AppInfo, Rect?) -> Unit> { { _, _ -> } }
/** Запуск с растянутой иконки (плитки): анимация стартует от самой плитки, а не от обычной иконки. */
val LocalOpenTile = staticCompositionLocalOf<(AppInfo, Rect?) -> Unit> { { _, _ -> } }
val LocalUnlock = staticCompositionLocalOf<() -> Float> { { 1f } }
/** Прячет иконку на время анимации запуска: только ту, на которую нажали (то же приложение в доке / на экране остаётся на месте). */
val LocalLaunchPkg = staticCompositionLocalOf<(String, Rect?) -> Boolean> { { _, _ -> false } }

fun screenCornerPx(a: Activity): Float {
    val min = 24f * a.resources.displayMetrics.density
    if (Build.VERSION.SDK_INT >= 31) {
        val c = a.window.decorView.rootWindowInsets?.getRoundedCorner(RoundedCorner.POSITION_TOP_LEFT)
        if (c != null && c.radius > 0) return maxOf(c.radius.toFloat(), min)
    }
    return 32f * a.resources.displayMetrics.density
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Home(a: MainActivity) {
    val s = MaterialTheme.colorScheme
    val apps by produceState(emptyList<AppInfo>(), a.appsVersion.intValue) {
        value = withContext(Dispatchers.Default) { loadApps(a) }
    }
    // копия раскладки: после любого изменения, не чаще раза в пару секунд
    LaunchedEffect(prefs.homeItems, prefs.folders, prefs.dock) {
        delay(1500)
        withContext(Dispatchers.IO) { LayoutBackup.save() }
    }
    val blurOn = prefs.animsEnabled && prefs.animBlur && Build.VERSION.SDK_INT >= 31
    val animSp = (prefs.animSpeed / 100f).coerceIn(0.25f, 3f)
    var drawer by remember { mutableStateOf(false) }
    var popup by remember { mutableStateOf<Offset?>(null) }
    var picker by remember { mutableStateOf(false) }
    var wallpapers by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<AppInfo?>(null) }   // окно «Своя иконка и название»
    var diy by remember { mutableStateOf(false) }   // DIY: иконки можно ставить куда угодно, не по сетке
    var openFolder by remember { mutableStateOf<String?>(null) }   // id открытой папки
    val launches = remember { mutableStateListOf<Launch>() }
    val seqCounter = remember { intArrayOf(0) }
    val unlock = remember { Animatable(1f) }
    val unlockFn = remember { { if (a.unlockArmed.value || a.lockShown.value) 0f else unlock.value } }
    // Прервать запуск: рисуем закрытие от текущего кадра, приложение не запускаем (или, если уже
    // запущено, просим систему вернуть домой).
    val abort: (Boolean) -> Unit = { sendHome ->
        launches.toList().forEach { l ->
            if (!l.reverse) {
                l.aborted = true
                l.reverse = true
                if (sendHome && l.started && a.stops.intValue == l.stopsAt) a.goHomeNow()
            }
        }
    }
    // Маски иконок считаем заранее в фоне, чтобы шторка и перекраска открывались без задержки
    LaunchedEffect(apps, prefs.iconMode) {
        if (prefs.iconMode == "themed") withContext(Dispatchers.Default) { apps.forEach { maskFor(a, it) } }
    }

    LaunchedEffect(a.goHome.intValue) {
        // вернулись из приложения, открытого из меню приложений, — остаёмся в меню; обычный жест «домой» меню закрывает
        drawer = drawer && launches.any { it.fromDrawer }
        popup = null; picker = false; wallpapers = false; diy = false; openFolder = null
        if (a.editWidget.intValue != -1) { a.editWidget.intValue = -1; a.saveRects() }
        // жест «домой» в любой момент запуска: дорисовали открытие и резко закрываем
        abort(false)
    }
    // Анимация запуска/закрытия принадлежит странице, на которой лежала иконка: стоит начать листать
    // или перейти на другую страницу — убираем её сразу, иначе она «всплывает» и закрывается над чужой страницей.
    LaunchedEffect(a.homePage.intValue, a.pageScrolling.value) {
        launches.toList().forEach { l ->
            if (l.page >= 0 && (l.page != a.homePage.intValue || a.pageScrolling.value)) launches.remove(l)
        }
    }
    // вернулись из приложения — рисуем анимацию закрытия
    LaunchedEffect(a.resume.intValue) {
        launches.toList().forEach {
            if (it.started && a.stops.intValue > it.stopsAt) {
                // из «окон» на рабочий стол — без анимации (иначе рывок), из приложения — с анимацией закрытия
                if (a.viaRecents) { it.p.snapTo(0f); launches.remove(it) } else it.reverse = true
            }
        }
    }
    LaunchedEffect(a.unlockTick.intValue) {
        if (a.unlockTick.intValue > 0 && prefs.animsEnabled && prefs.unlockAnim) {
            unlock.snapTo(0f)
            a.unlockArmed.value = false   // с того же кадра: рабочий стол уже в стартовом состоянии, играем без рывка
            if (prefs.unlockStyle == "normal") unlock.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 170f))
            else unlock.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        } else {
            a.unlockArmed.value = false
        }
    }
    // страховка: если разблокировка прошла без сигнала (нет экрана блокировки) — не оставляем рабочий стол спрятанным
    LaunchedEffect(a.unlockArmed.value) {
        while (a.unlockArmed.value) { delay(40); a.tryUnlock(); if (a.unlockArmed.value) a.unlockWatchdog() }
    }
    BackHandler(drawer || popup != null || picker || wallpapers || diy || openFolder != null || launches.isNotEmpty() || a.editWidget.intValue != -1) {
        if (launches.isNotEmpty()) abort(true)
        else if (openFolder != null) openFolder = null
        else if (a.editWidget.intValue != -1) { a.editWidget.intValue = -1; a.saveRects() }
        else if (diy && !drawer && popup == null && !picker && !wallpapers) diy = false
        else { drawer = false; popup = null; picker = false; wallpapers = false }
    }
    // пока идёт приветствие, «назад» его не закрывает
    BackHandler(!prefs.welcomeDone) {}
    LaunchedEffect(apps) {
        if (!prefs.dockInit && apps.isNotEmpty()) {
            prefs.dock = defaultDock(a, apps)
            prefs.dockInit = true
        }
    }

    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val dockList = prefs.dock.pkgs()
    val homeList = parseHome(prefs.homeItems).map { it.appPkg } + parseFolders(prefs.folders).flatMap { it.pkgs }
    val dock = dockList.mapNotNull { byPkg[it] }

    val menuFor = { app: AppInfo ->
        buildList<MenuAction> {
            add(MenuAction(Icons.Filled.Info, "О приложении") {
                a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
            })
            if (app.pkg in dockList) add(MenuAction(Icons.Filled.Close, "Убрать из дока") { prefs.dock = prefs.dock.delPkg(app.pkg) })
            else if (dockList.size < 5) add(MenuAction(Icons.Filled.Add, "В док") { prefs.dock = prefs.dock.addPkg(app.pkg) })
            if (app.pkg in homeList) {
                add(MenuAction(Icons.Filled.Add, "Ещё копию на главный экран") { homeAdd(app.pkg) })
                add(MenuAction(Icons.Filled.Close, REMOVE_HOME, danger = true) { homeRemove(app.pkg) })
            } else add(MenuAction(Icons.Filled.Add, "На главный экран") { homeAdd(app.pkg) })
            add(MenuAction(Icons.Filled.Create, "Своя иконка и название") { editing = app })
            add(MenuAction(Icons.Filled.Delete, "Удалить", danger = true) {
                val uri = Uri.parse("package:${app.pkg}")
                try {
                    a.startActivity(Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri))
                } catch (e: Exception) {
                    try { a.startActivity(Intent(Intent.ACTION_DELETE, uri)) }
                    catch (e2: Exception) {
                        // системное приложение или оболочка не даёт удалить — открываем страницу приложения
                        a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    }
                }
            })
        }
    }

    editing?.let { AppEditDialog(a, it) { editing = null } }

    val openImpl: (AppInfo, Rect?, Boolean) -> Unit = { app, r, tile ->
        // То же приложение в доке и на главном экране — это разные иконки: «туда-сюда» только для той же самой иконки (по месту),
        // иначе после быстрого закрытия анимация продолжала бы открываться из прошлого места.
        val ex = launches.lastOrNull {
            it.app.pkg == app.pkg && (r == null || (
                abs(it.rect.center.x - r.center.x) < minOf(it.rect.width, it.rect.height) * 0.4f &&
                abs(it.rect.center.y - r.center.y) < minOf(it.rect.width, it.rect.height) * 0.4f))
        }
        if (ex != null && !ex.started) {
            // повторное нажатие на ту же иконку, пока приложение ещё не запущено: «туда-сюда»
            if (ex.reverse) { ex.aborted = false; ex.t0 = SystemClock.uptimeMillis(); ex.reverse = false }
            else { ex.aborted = true; ex.reverse = true }
        } else if (prefs.animsEnabled && prefs.openAnim && r != null) {
            // новое нажатие: ещё не запущенные приложения отменяем (их анимация играет назад параллельно), откроется только последнее
            launches.forEach { if (!it.started && !it.reverse) { it.aborted = true; it.reverse = true } }
            val pb = a.pagerBounds
            val onPage = !drawer && pb != null && pb.contains(r.center)
            launches.add(Launch(app, r, a.stops.intValue, seqCounter[0]++, drawer, if (onPage) a.homePage.intValue else -1, tile))
        } else {
            a.startApp(app)
        }
    }
    val open: (AppInfo, Rect?) -> Unit = { app, r -> openImpl(app, r, false) }
    val openTile: (AppInfo, Rect?) -> Unit = { app, r -> openImpl(app, r, true) }

    CompositionLocalProvider(
        LocalOpen provides open, LocalOpenTile provides openTile, LocalUnlock provides unlockFn,
        LocalLaunchPkg provides { pkg, r ->
            r != null && launches.any {
                val tol = minOf(it.rect.width, it.rect.height) * 0.4f
                it.app.pkg == pkg && abs(it.rect.center.x - r.center.x) < tol && abs(it.rect.center.y - r.center.y) < tol
            }
        }
    ) {
        Box(Modifier.fillMaxSize()) {
          // всё, кроме самой анимации запуска, лежит в одном слое: при включённой опции оно размывается
          Box(
            Modifier.fillMaxSize().graphicsLayer {
                if (blurOn) {
                    var m = 0f
                    for (ln in launches) m = maxOf(m, ln.p.value)
                    val r = 26f * density * m.coerceIn(0f, 1f)
                    if (r > 0.5f) renderEffect = BlurEffect(r, r, TileMode.Clamp)
                }
            }
          ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val u = unlockFn()
                        if (u < 1f) {
                            if (prefs.unlockStyle == "normal") {
                                alpha = (u * 2f).coerceIn(0f, 1f)
                            } else {
                                val k = u.coerceIn(0f, 1f)
                                // до сигнала разблокировки рабочий стол полностью прозрачен: иначе он мелькает тусклым
                                alpha = k * k
                                val sc = 1.06f - 0.06f * k
                                scaleX = sc
                                scaleY = sc
                            }
                        }
                    }
                    .homeGestures(
                        onLong = { if (a.editWidget.intValue == -1) popup = it },
                        onUp = { if (a.editWidget.intValue == -1 && !diy) drawer = true },
                        onPinch = { if (a.editWidget.intValue == -1) popup = Offset(-1f, -1f) }
                    )
                    .systemBarsPadding()
            ) {
                Box(Modifier.weight(1f).fillMaxWidth()) { HomePage(a, apps, menuFor, diy, { openFolder = it }) { diy = false } }
                if (dock.isNotEmpty()) DockRow(dock, menuFor)
                if (prefs.showSearch) QsbWidget(a)
                Spacer(Modifier.height(6.dp))
            }

            // Pixel-разблокировка: белая волна пробегает снизу вверх
            Canvas(Modifier.fillMaxSize()) {
                val u = unlock.value
                if (u > 0f && u < 0.999f && prefs.animsEnabled && prefs.unlockAnim && prefs.unlockStyle != "normal") {
                    val bandH = size.height * 0.55f
                    val cy = size.height * 1.25f - u * size.height * 1.5f
                    val alphaW = (sin(PI * u).toFloat() * 0.5f).coerceIn(0f, 1f)
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = alphaW), Color.Transparent),
                            startY = cy - bandH / 2f, endY = cy + bandH / 2f
                        ),
                        topLeft = Offset(0f, cy - bandH / 2f),
                        size = Size(size.width, bandH)
                    )
                }
            }

            AnimatedVisibility(
                drawer,
                enter = if (prefs.animsEnabled)
                    slideInVertically(tween((340 / animSp).toInt().coerceAtLeast(90), easing = CubicBezierEasing(0.2f, 0f, 0f, 1f))) { it } +
                        fadeIn(tween((200 / animSp).toInt().coerceAtLeast(60)))
                else EnterTransition.None,
                exit = if (prefs.animsEnabled)
                    slideOutVertically(tween((260 / animSp).toInt().coerceAtLeast(80), easing = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f))) { it } +
                        fadeOut(tween((200 / animSp).toInt().coerceAtLeast(60)))
                else ExitTransition.None
            ) {
                Drawer(a, apps, { drawer = false }, menuFor)
            }

            openFolder?.let { id ->
                FolderOverlay(
                    id, byPkg, menuFor,
                    onRemove = { pkg ->
                        prefs.homeItems = parseHome(prefs.homeItems).withoutMember(pkg)
                            .withAdded(pkg, prefs.homeCols).compacted().encode()
                    },
                    onClose = { openFolder = null }
                )
            }

            popup?.let { p ->
                val screenW = a.resources.displayMetrics.widthPixels
                val screenH = a.resources.displayMetrics.heightPixels
                val cx = if (p.x < 0) screenW / 2 else p.x.roundToInt()
                val cy = if (p.y < 0) screenH / 2 else p.y.roundToInt()
                FloatingMenu(cx, cy, cy, { popup = null }) {
                    MenuRow(Icons.Filled.Create, "Обои и стиль") { popup = null; wallpapers = true }
                    MenuRow(Icons.Filled.Edit, if (diy) "Выйти из DIY-режима" else "DIY-режим") { popup = null; diy = !diy }
                    MenuRow(Icons.Filled.Add, "Виджеты") { popup = null; picker = true }
                    MenuRow(Icons.Filled.SettingsIcon, "Настройки лаунчера") { popup = null; a.openSettings() }
                }
            }

            AnimatedVisibility(
                picker,
                enter = sheetEnter(prefs.animsEnabled, animSp), exit = sheetExit(prefs.animsEnabled, animSp)
            ) { WidgetPicker(a) { picker = false } }
            AnimatedVisibility(
                wallpapers,
                enter = sheetEnter(prefs.animsEnabled, animSp), exit = sheetExit(prefs.animsEnabled, animSp)
            ) { WallpaperMenu(a) { wallpapers = false } }

          }
            launches.toList().forEach { l -> key(l) { LaunchOverlay(l, launches, a) { launches.remove(l) } } }

            // свой экран блокировки: поверх рабочего стола, пока не «отсканируют» отпечаток
            AnimatedVisibility(
                a.lockShown.value,
                enter = fadeIn(tween(220)),
                exit = fadeOut(tween(380)) + scaleOut(tween(380), targetScale = 1.06f)
            ) { LockScreen { a.dismissLock() } }

            // первый запуск: приветствие
            AnimatedVisibility(
                !prefs.welcomeDone,
                enter = fadeIn(),
                exit = fadeOut(tween(600))
            ) { WelcomeScreen { prefs.welcomeDone = true } }
        }
    }
}

/**
 * Анимация открытия/закрытия в стиле Google Pixel: иконка раскрывается в скруглённое окно на весь экран.
 * Физика одна (пружина), настраивается только скорость. Анимацию можно прервать (назад, жест «домой», касание) —
 * тогда она рисуется на выход, а приложение не открывается. Когда возвращаешься из приложения — играет закрытие.
 */
@Composable
fun LaunchOverlay(l: Launch, all: List<Launch>, a: MainActivity, onDone: () -> Unit) {
    val s = MaterialTheme.colorScheme
    val d = LocalDensity.current
    val dm = a.resources.displayMetrics
    val screenCorner = remember { screenCornerPx(a) }
    // углы окна в конце анимации: как у экрана телефона или свои из настроек
    val cornerPx = if (prefs.animCornerAuto) screenCorner else with(d) { prefs.animCorner.dp.toPx() }
    // Скорость масштабирует жёсткость пружины: время анимации меняется в 1/speed раз, а «упругость» остаётся прежней
    val speed = (prefs.animSpeed / 100f).coerceIn(0.25f, 3f)
    val k = speed * speed
    val startColor = if (prefs.iconMode == "themed") themedColors(s).second else s.primaryContainer
    val endColor = s.surface

    val openSpec: AnimationSpec<Float> = spring(dampingRatio = 1f, stiffness = 420f * k, visibilityThreshold = 0.002f)

    LaunchedEffect(l.reverse) {
        if (!l.reverse) {
            val job = launch { l.p.animateTo(1f, openSpec) }
            // Приложение стартует, когда открытие почти закончилось: до этого момента его ещё можно отменить
            snapshotFlow { l.p.value }.first { it >= 0.85f }
            // пауза перед запуском приложения (считается от нажатия) — пока она идёт, анимацию можно отменить
            val wait = l.t0 + prefs.openDelay - SystemClock.uptimeMillis()
            if (wait > 0) delay(wait)
            // Несколько запусков подряд: приложения открываются по очереди, анимации рисуются параллельно
            snapshotFlow { all.any { it.seq < l.seq && !it.started && !it.reverse } }.first { !it }
            if (l.reverse) return@LaunchedEffect
            if (!a.startApp(l.app)) { l.reverse = true; return@LaunchedEffect }
            l.started = true
            job.join()
            val left = withTimeoutOrNull(4000) { snapshotFlow { a.stops.intValue }.first { it > l.stopsAt } }
            if (left == null) l.reverse = true
        } else {
            // прерванное открытие закрывается резко, обычное закрытие — плавнее
            val closeSpec: AnimationSpec<Float> = spring(
                dampingRatio = 1f, stiffness = (if (l.aborted) 520f else 150f) * k, visibilityThreshold = 0.002f
            )
            l.p.animateTo(0f, closeSpec)
            onDone()
        }
    }

    val iconPx = minOf(l.rect.width, l.rect.height)
    // Касания перехватываем, только пока окно почти закрывает экран; иначе иконки под ним живые
    val waiting by remember(l) { derivedStateOf { l.p.value > 0.9f && !l.started && !l.reverse } }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val t = l.p.value.coerceIn(0f, 1f)
            val r = l.rect
            // окно вырастает из самой иконки, углы плавно меняются
            val x = r.left * (1f - t)
            val y = r.top * (1f - t)
            val w = r.width + (size.width - r.width) * t
            val h = r.height + (size.height - r.height) * t
            val side = minOf(r.width, r.height)
            // в начале окно повторяет углы самой иконки (квадрат с настроенным скруглением, сквиркл и т. д.)
            val startR = if (l.tile) side * 0.3f else when (prefs.iconShape) {
                "square" -> side * prefs.squareCorner.coerceIn(0, 50) / 100f
                "squircle" -> side * 0.35f
                "rounded" -> side * 0.22f
                else -> side / 2f
            }
            val rad = (startR + (cornerPx - startR) * t).coerceAtLeast(0f)
            drawRoundRect(
                color = lerpColor(startColor, endColor, t).copy(alpha = (t * 6f).coerceIn(0f, 1f)),
                topLeft = Offset(x, y), size = Size(w, h), cornerRadius = CornerRadius(rad)
            )
        }
        Box(
            Modifier
                .offset { IntOffset(l.rect.left.roundToInt(), l.rect.top.roundToInt()) }
                .size(
                    with(d) { (if (l.tile) l.rect.width else iconPx).toDp() },
                    with(d) { (if (l.tile) l.rect.height else iconPx).toDp() }
                )
                .graphicsLayer {
                    val t = l.p.value.coerceIn(0f, 1f)
                    val sc = 1f + t * 2.2f
                    scaleX = sc
                    scaleY = sc
                    translationX = (dm.widthPixels / 2f - l.rect.center.x) * t
                    translationY = (dm.heightPixels / 2f - l.rect.center.y) * t
                    alpha = (1f - t * 2f).coerceIn(0f, 1f)
                }
        ) {
            if (l.tile) AppTile(l.app, prefs.showLabels, prefs.iconSize, Modifier.fillMaxSize())
            else AppIcon(l.app, with(d) { iconPx.toDp() })
        }
        if (waiting) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(96.dp).pointerInput(l) {
                        detectTapGestures { if (!l.started && !l.reverse) { l.aborted = true; l.reverse = true } }
                    },
                    contentAlignment = Alignment.Center
                ) {}
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppItem(
    app: AppInfo, labels: Boolean, labelColor: Color,
    menu: List<MenuAction>, modifier: Modifier = Modifier, size: Int = prefs.iconSize,
    /** managed: долгое нажатие и перенос обрабатывает главный экран (HomeGrid), здесь только тап. */
    managed: Boolean = false, hidden: Boolean = false,
    /** не null (меню приложений): долгое нажатие и перенос на другую иконку меняют их местами; без переноса по-прежнему открывается меню */
    drag: DrawerDrag? = null, onSwap: ((String, String) -> Unit)? = null
) {
    val open = LocalOpen.current
    val unlock = LocalUnlock.current
    val launchPkg = LocalLaunchPkg.current
    val src = remember { MutableInteractionSource() }
    val ictx = LocalContext.current
    val pressed by src.collectIsPressedAsState()
    var touching by remember { mutableStateOf(false) }
    val pressScale = animateFloatAsState(
        if (pressed || touching) 0.84f else 1f, spring(dampingRatio = 0.5f, stiffness = 520f), label = "press"
    )
    val haptic = LocalHapticFeedback.current
    var show by remember { mutableStateOf(false) }
    var rect by remember { mutableStateOf<Rect?>(null) }
    // на случай, если иконка уйдёт с экрана (листание), убираем её прямоугольник из списка целей переноса
    DisposableEffect(app.pkg, drag) { onDispose { drag?.rects?.remove(app.pkg) } }
    val dens = LocalDensity.current
    val sw = LocalContext.current.resources.displayMetrics.widthPixels.toFloat()
    Box(modifier) {
        Column(
            Modifier.fillMaxWidth()
                .onGloballyPositioned { val b = it.boundsInWindow(); rect = b; drag?.rects?.set(app.pkg, b) }
                .graphicsLayer {
                    // Обычная разблокировка: иконки слетаются с боков к центру
                    val u = unlock()
                    if (u != 1f && prefs.unlockStyle == "normal") {
                        val cx = rect?.center?.x ?: (sw / 2f)
                        translationX = (cx - sw / 2f) * 1.15f * (1f - u)
                        val sc = (0.5f + 0.5f * u).coerceAtLeast(0f)
                        scaleX = sc
                        scaleY = sc
                        alpha = (u * 1.6f).coerceIn(0f, 1f)
                    }
                    if (hidden) alpha = 0f
                }
                .then(
                    if (managed) Modifier.clickable(interactionSource = src, indication = null) {
                        open(app, iconRect(rect, size, dens))
                    } else if (drag != null) Modifier.pointerInput(app.pkg) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                            touching = true
                            val slop = viewConfiguration.touchSlop
                            // 1 — отпустили (обычный тап), 2 — палец ушёл раньше времени (листание), null — время вышло: долгое нажатие
                            val first = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                var res = 2
                                var go = true
                                while (go) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    if (c == null) go = false
                                    else if (!c.pressed) { res = 1; go = false }
                                    else if ((c.position - down.position).getDistance() > slop) go = false
                                }
                                res
                            }
                            if (first == 1) { touching = false; open(app, iconRect(rect, size, dens)); return@awaitEachGesture }
                            if (first == 2) { touching = false; return@awaitEachGesture }
                            // долгое нажатие: дальше палец только тащит иконку (листание шторки не должно срабатывать)
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            prefetchShortcuts(ictx, app.pkg)
                            var dragging = false
                            var cancelled = false
                            var go = true
                            while (go) {
                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                val c = ev.changes.firstOrNull { it.id == down.id }
                                ev.changes.forEach { it.consume() }
                                if (c == null) { cancelled = true; go = false }
                                else if (!c.pressed) go = false
                                else {
                                    if (!dragging && (c.position - down.position).getDistance() > slop) {
                                        dragging = true
                                        drag.pkg = app.pkg
                                    }
                                    if (dragging) {
                                        val g = (rect?.topLeft ?: Offset.Zero) + c.position
                                        drag.pos = g
                                        drag.target = drag.hit(g, app.pkg)
                                    }
                                }
                            }
                            touching = false
                            if (dragging) {
                                val t = drag.target
                                drag.pkg = null
                                drag.target = null
                                if (!cancelled && t != null) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onSwap?.invoke(app.pkg, t)
                                }
                            } else if (!cancelled) show = true
                        }
                    } else Modifier.combinedClickable(
                        interactionSource = src, indication = null,
                        onClick = { open(app, iconRect(rect, size, dens)) },
                        onLongClick = { prefetchShortcuts(ictx, app.pkg); show = true }
                    )
                )
                .padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.graphicsLayer {
                alpha = if (launchPkg(app.pkg, iconRect(rect, size, dens))) 0f else 1f
                scaleX = pressScale.value
                scaleY = pressScale.value
            }) {
                AppIcon(app, size.dp)
            }
            if (labels) {
                Text(
                    app.label, color = labelColor, fontSize = 12.sp, maxLines = 1,
                    fontWeight = FontWeight.Bold,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(shadow = Shadow(Color.Black.copy(.35f), blurRadius = 6f)),
                    modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp)
                )
            }
        }
        if (show) {
            val r = rect
            FloatingMenu(
                r?.center?.x?.roundToInt() ?: 0, r?.top?.roundToInt() ?: 0, r?.bottom?.roundToInt() ?: 0,
                { show = false }
            ) { AppMenuContent(app, menu) { show = false } }
        }
    }
}

/** Прямоугольник самой иконки (по центру ячейки, сверху). */
private fun iconRect(cell: Rect?, sizeDp: Int, d: Density): Rect? {
    if (cell == null) return null
    val px = with(d) { sizeDp.dp.toPx() }
    val left = cell.center.x - px / 2f
    val top = cell.top + with(d) { 6.dp.toPx() }
    return Rect(left, top, left + px, top + px)
}
