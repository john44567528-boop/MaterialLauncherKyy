package com.kyy.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sqrt

data class AppInfo(val label: String, val pkg: String, val cn: ComponentName)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            AppInfo(
                it.loadLabel(pm).toString(),
                it.activityInfo.packageName,
                ComponentName(it.activityInfo.packageName, it.activityInfo.name)
            )
        }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

object IconCache {
    val bitmaps = LruCache<String, Pair<ImageBitmap, Boolean>>(160)   // (картинка, взята из набора иконок)
    val masks = LruCache<String, ByteArray>(240)

    fun clear() { bitmaps.evictAll(); masks.evictAll() }

    fun evict(pkg: String) {
        masks.remove(pkg)
        for (k in bitmaps.snapshot().keys) if (k.startsWith("$pkg|")) bitmaps.remove(k)
    }
}

/** Цвета тематических иконок: (глиф, фон). Как на референсе: тёмный глиф на яркой плашке. */
fun themedColors(s: ColorScheme): Pair<Color, Color> {
    val dark = s.background.luminance() < 0.5f
    // Монохромный перекрас: чёрный, серый или белый (плашка + контрастный глиф)
    when (prefs.iconColor) {
        "mono_black" -> return Color(0xFFF2F2F2) to Color(0xFF121212)
        "mono_gray" -> return Color(0xFF1B1B1B) to Color(0xFF9E9E9E)
        "mono_white" -> return Color(0xFF151515) to Color(0xFFF7F7F7)
    }
    val custom = Palette[prefs.iconColor]?.let { Color(it) }
    return when {
        custom == null -> if (dark) s.onPrimary to s.primary else s.onPrimaryContainer to s.primaryContainer
        dark -> lerp(custom, Color.Black, 0.78f) to lerp(custom, Color.White, 0.30f)
        else -> lerp(custom, Color.Black, 0.55f) to lerp(custom, Color.White, 0.80f)
    }
}

private const val ICON_PX = 224

private fun smooth(e0: Float, e1: Float, x: Float): Float {
    val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

private fun capture(s: Int, draw: (Canvas) -> Unit): IntArray {
    val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
    try { draw(Canvas(b)) } catch (_: Throwable) {}
    val px = IntArray(s * s)
    b.getPixels(px, 0, s, 0, 0, s, s)
    b.recycle()
    return px
}

private fun drawLayer(d: Drawable?, c: Canvas, s: Int, o: Int) {
    if (d == null) return
    d.setBounds(-o, -o, s + o, s + o)
    d.draw(c)
}

private fun lum(p: Int): Float =
    (0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)) / 255f

private fun coverage(px: IntArray, thr: Int): Float {
    var k = 0
    for (p in px) if ((p ushr 24) >= thr) k++
    return k.toFloat() / px.size
}

private fun alphaMask(px: IntArray) = FloatArray(px.size) { (px[it] ushr 24) / 255f }

/** Глиф одного цвета (чистый силуэт)? Тогда можно брать просто альфу переднего слоя. */
private fun isFlat(px: IntArray): Boolean {
    var n = 0
    var sum = 0.0
    var sq = 0.0
    for (p in px) {
        if ((p ushr 24) >= 200) {
            val l = lum(p).toDouble()
            sum += l; sq += l * l; n++
        }
    }
    if (n == 0) return false
    val mean = sum / n
    return sqrt((sq / n - mean * mean).coerceAtLeast(0.0)) < 0.12
}

/** Запасная маска по яркости: тёмный глиф на светлом фоне или наоборот. */
private fun lumMask(px: IntArray): FloatArray {
    val n = px.size
    val l = FloatArray(n)
    var sum = 0.0
    var cnt = 0
    for (i in 0 until n) {
        val p = px[i]
        if ((p ushr 24) < 16) { l[i] = -1f; continue }
        l[i] = lum(p)
        sum += l[i]
        cnt++
    }
    if (cnt == 0) return FloatArray(n)
    val invert = sum / cnt < 0.5
    val m = FloatArray(n)
    var lo = 1f
    var hi = 0f
    for (i in 0 until n) {
        if (l[i] < 0f) continue
        val v = if (invert) l[i] else 1f - l[i]
        m[i] = v
        if (v < lo) lo = v
        if (v > hi) hi = v
    }
    val span = (hi - lo).coerceAtLeast(0.05f)
    for (i in 0 until n) m[i] = if (l[i] < 0f) 0f else ((m[i] - lo) / span).coerceIn(0f, 1f)
    return m
}

/** Средний цвет непрозрачных пикселей по рамке кадра — это и есть фон адаптивной иконки. */
private fun edgeColor(px: IntArray, s: Int): IntArray? {
    val band = (s * 0.06f).toInt().coerceAtLeast(2)
    var sr = 0L
    var sg = 0L
    var sb = 0L
    var k = 0
    for (y in 0 until s) {
        val inner = y in band until (s - band)
        var x = 0
        while (x < s) {
            if (inner && x == band) { x = s - band; continue }
            val p = px[y * s + x]
            if ((p ushr 24) >= 230) {
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
                k++
            }
            x++
        }
    }
    if (k < (s * s * 0.12f).toInt()) return null
    return intArrayOf((sr / k).toInt(), (sg / k).toInt(), (sb / k).toInt())
}

/**
 * Маска «насколько пиксель отличается от фона иконки».
 * В отличие от жёсткого силуэта сохраняет внутренние детали глифа (тональность), поэтому
 * иконки не превращаются в сплошные чёрные пятна, а светлый глиф на тёмном фоне не инвертируется.
 */
private fun detailMask(px: IntArray, s: Int): FloatArray? {
    val bgc = edgeColor(px, s) ?: return null
    val n = px.size
    val dist = FloatArray(n)
    val hist = IntArray(64)
    var opaque = 0
    for (i in 0 until n) {
        val p = px[i]
        val a = p ushr 24
        if (a < 16) continue
        val dr = ((p shr 16) and 255) - bgc[0]
        val dg = ((p shr 8) and 255) - bgc[1]
        val db = (p and 255) - bgc[2]
        val d = sqrt((dr * dr + dg * dg + db * db).toFloat()) / 441.7f
        dist[i] = d * (a / 255f)
        hist[(d * 63f).toInt().coerceIn(0, 63)]++
        opaque++
    }
    if (opaque < n / 50) return null
    val target = (opaque * 0.97f).toInt()
    var acc = 0
    var hi = 1f
    for (b in 0 until 64) {
        acc += hist[b]
        if (acc >= target) { hi = (b + 1) / 64f; break }
    }
    hi = hi.coerceAtLeast(0.22f)
    val dead = 0.06f
    val m = FloatArray(n)
    var strong = 0
    for (i in 0 until n) {
        val v = ((dist[i] - dead) / (hi - dead)).coerceIn(0f, 1f)
        m[i] = v
        if (v > 0.5f) strong++
    }
    val frac = strong.toFloat() / n
    return if (frac in 0.01f..0.85f) m else null
}

/** Обычная (не адаптивная) иконка. */
private fun legacyMask(px: IntArray, s: Int): FloatArray {
    detailMask(px, s)?.let { return it }
    // прозрачные края: силуэт + лёгкий рельеф по цвету
    var sr = 0L
    var sg = 0L
    var sb = 0L
    var k = 0
    for (p in px) {
        if ((p ushr 24) >= 200) {
            sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255; k++
        }
    }
    val m = FloatArray(px.size)
    if (k == 0) return m
    val mr = (sr / k).toInt()
    val mg = (sg / k).toInt()
    val mb = (sb / k).toInt()
    for (i in px.indices) {
        val p = px[i]
        val a = (p ushr 24) / 255f
        if (a < 0.02f) continue
        val dr = ((p shr 16) and 255) - mr
        val dg = ((p shr 8) and 255) - mg
        val db = (p and 255) - mb
        val d = sqrt((dr * dr + dg * dg + db * db).toFloat()) / 441.7f
        m[i] = a * (1f - 0.5f * smooth(0f, 0.45f, d))
    }
    return m
}

private fun buildMask(d: Drawable, adaptive: AdaptiveIconDrawable?, s: Int, o: Int): FloatArray {
    if (adaptive != null) {
        // 1) нативная монохромная иконка (Android 13+)
        if (Build.VERSION.SDK_INT >= 33) {
            val mono = adaptive.monochrome
            if (mono != null) {
                val px = capture(s) { drawLayer(mono.mutate(), it, s, o) }
                if (coverage(px, 40) > 0.008f) return alphaMask(px)
            }
        }
        val fgPx = capture(s) { drawLayer(adaptive.foreground?.mutate(), it, s, o) }
        // 2) одноцветный глиф с прозрачностью — чистая альфа переднего слоя
        val cov = coverage(fgPx, 200)
        if (cov in 0.012f..0.40f && isFlat(fgPx)) return alphaMask(fgPx)
        // 3) всё остальное — отличие от фона с сохранением деталей
        val full = capture(s) {
            drawLayer(adaptive.background?.mutate(), it, s, o)
            drawLayer(adaptive.foreground?.mutate(), it, s, o)
        }
        return detailMask(full, s) ?: lumMask(full)
    }
    val plate = plateColor(d, s) != null
    val px = capture(s) { drawLegacy(d, it, s, plate, 0.08f) }
    return legacyMask(px, s)
}

/** Цвет плашки квадратной иконки (по кольцу внутри кадра). */
private fun ringColor(px: IntArray, s: Int): Int {
    val a0 = (s * 0.10f).toInt()
    val a1 = (s * 0.15f).toInt()
    var sr = 0L
    var sg = 0L
    var sb = 0L
    var k = 0
    for (y in 0 until s) for (x in 0 until s) {
        val dm = minOf(minOf(x, y), minOf(s - 1 - x, s - 1 - y))
        if (dm in a0 until a1) {
            val p = px[y * s + x]
            if ((p ushr 24) >= 200) {
                sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255; k++
            }
        }
    }
    if (k == 0) return 0xFF808080.toInt()
    return (255 shl 24) or ((sr / k).toInt() shl 16) or ((sg / k).toInt() shl 8) or (sb / k).toInt()
}

/** Обычная иконка-«квадрат» (сплошная плашка)? Возвращает цвет плашки, иначе null. */
private fun plateColor(d: Drawable, s: Int): Int? {
    val probe = capture(s) {
        val dd = d.mutate()
        dd.setBounds(0, 0, s, s)
        dd.draw(it)
    }
    if (coverage(probe, 200) < 0.7f) return null
    return ringColor(probe, s)
}

/**
 * Плашку растягиваем с запасом, чтобы углы и границы квадрата уходили за форму иконки;
 * глиф на прозрачном фоне рисуем с полями, как раньше.
 */
private fun drawLegacy(d: Drawable, c: Canvas, s: Int, plate: Boolean, padF: Float) {
    val dd = d.mutate()
    if (plate) {
        val o = (s * 0.14f).toInt()
        dd.setBounds(-o, -o, s + o, s + o)
    } else {
        val pad = (s * padF).toInt()
        dd.setBounds(pad, pad, s - pad, s - pad)
    }
    dd.draw(c)
}

private fun activityIcon(ctx: Context, app: AppInfo): Drawable {
    val pm = ctx.packageManager
    return try { pm.getActivityIcon(app.cn) } catch (e: Throwable) { pm.defaultActivityIcon }
}

/** Маска иконки считается один раз на приложение и кэшируется (перекраска потом почти бесплатна). */
fun maskFor(ctx: Context, app: AppInfo): ByteArray {
    IconCache.masks.get(app.pkg)?.let { return it }
    val s = ICON_PX
    val d = activityIcon(ctx, app)
    val f = try { buildMask(d, d as? AdaptiveIconDrawable, s, s / 4) } catch (_: Throwable) { FloatArray(s * s) }
    val b = ByteArray(s * s) { (f[it].coerceIn(0f, 1f) * 255f + 0.5f).toInt().toByte() }
    IconCache.masks.put(app.pkg, b)
    return b
}

fun renderIcon(ctx: Context, app: AppInfo, themed: Boolean, fg: Int, bg: Int): Bitmap {
    val s = ICON_PX
    val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)

    if (!themed) {
        val d = activityIcon(ctx, app)
        val adaptive = d as? AdaptiveIconDrawable
        val c = Canvas(out)
        try {
            if (adaptive != null) {
                drawLayer(adaptive.background, c, s, s / 4)
                drawLayer(adaptive.foreground, c, s, s / 4)
            } else {
                val pc = plateColor(d, s)
                c.drawColor(pc ?: bg)
                drawLegacy(d, c, s, pc != null, 0.16f)
            }
        } catch (_: Throwable) {}
        return out
    }

    // Тематическая иконка всегда собирается из маски и двух цветов темы.
    val mask = maskFor(ctx, app)
    val fr = (fg shr 16) and 255
    val fgG = (fg shr 8) and 255
    val fb = fg and 255
    val br = (bg shr 16) and 255
    val bgG = (bg shr 8) and 255
    val bb = bg and 255
    val res = IntArray(s * s)
    for (i in res.indices) {
        val m = (mask[i].toInt() and 255) / 255f
        val r = (br + (fr - br) * m).toInt()
        val g = (bgG + (fgG - bgG) * m).toInt()
        val b = (bb + (fb - bb) * m).toInt()
        res[i] = (255 shl 24) or (r shl 16) or (g shl 8) or b
    }
    out.setPixels(res, 0, s, 0, 0, s, s)
    return out
}

@Composable
fun AppIcon(app: AppInfo, size: Dp) {
    val ctx = LocalContext.current
    val s = MaterialTheme.colorScheme
    val themed = prefs.iconMode == "themed"
    val (fg, bg) = if (themed) themedColors(s) else (Color.Transparent to s.surfaceVariant)
    val pack = prefs.iconPack
    val key = "${app.pkg}|$themed|${fg.toArgb()}|${bg.toArgb()}|$pack"
    val res by produceState<Pair<ImageBitmap, Boolean>?>(IconCache.bitmaps.get(key), key) {
        val cached = IconCache.bitmaps.get(key)
        value = cached ?: withContext(Dispatchers.Default) {
            runCatching {
                val pb = if (pack.isNotEmpty()) IconPacks.render(ctx, pack, app) else null
                if (pb != null) (pb.asImageBitmap() to true)
                else (renderIcon(ctx, app, themed, fg.toArgb(), bg.toArgb()).asImageBitmap() to false)
            }.getOrNull()
        }?.also { IconCache.bitmaps.put(key, it) }
    }
    // иконки из набора рисуем как есть (у них своя форма), остальные — в выбранной форме
    Box(Modifier.size(size).then(if (res?.second == true) Modifier else Modifier.clip(shapeOf(prefs.iconShape)))) {
        res?.let { Image(it.first, contentDescription = app.label, modifier = Modifier.fillMaxSize()) }
    }
}
