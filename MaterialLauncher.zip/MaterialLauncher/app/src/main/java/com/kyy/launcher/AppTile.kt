package com.kyy.launcher

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Средний цвет по краю картинки иконки (прозрачные пиксели не считаем): им заливается растянутая плитка. */
private fun edgeColor(bmp: ImageBitmap): Color? = runCatching {
    val b = bmp.asAndroidBitmap()
    val w = b.width
    val h = b.height
    if (w < 4 || h < 4) return@runCatching null
    var r = 0L; var g = 0L; var bl = 0L; var n = 0
    val inset = (minOf(w, h) * 0.06f).toInt()
    fun add(x: Int, y: Int) {
        val p = b.getPixel(x.coerceIn(0, w - 1), y.coerceIn(0, h - 1))
        if (android.graphics.Color.alpha(p) > 200) {
            r += android.graphics.Color.red(p); g += android.graphics.Color.green(p); bl += android.graphics.Color.blue(p); n++
        }
    }
    for (i in 0..15) {
        val t = i / 15f
        val x = (inset + t * (w - 1 - 2 * inset)).toInt()
        val y = (inset + t * (h - 1 - 2 * inset)).toInt()
        add(x, inset); add(x, h - 1 - inset); add(inset, y); add(w - 1 - inset, y)
    }
    if (n == 0) null else Color((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
}.getOrNull()

/** Растянутая иконка (2×1, 1×2, 2×2…): плитка в выбранной форме иконок, внутри — сама иконка. */
@Composable
fun AppTile(app: AppInfo, labels: Boolean, iconSize: Int, modifier: Modifier = Modifier) {
    val s = MaterialTheme.colorScheme
    val res = rememberAppIconRes(app)
    val bg = remember(res) { res?.first?.let { edgeColor(it) } } ?: s.surfaceVariant
    val dark = bg.luminance() < 0.5f
    BoxWithConstraints(
        modifier.clip(shapeOf(prefs.iconShape)).background(bg),
        contentAlignment = Alignment.Center
    ) {
        val side = minOf(maxWidth, maxHeight)
        val inner = minOf(iconSize.dp * 1.35f, side * (if (labels) 0.5f else 0.62f))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AppIcon(app, inner)
            if (labels) {
                Text(
                    app.label, color = if (dark) Color.White else Color.Black.copy(alpha = .85f),
                    fontSize = 12.sp, maxLines = 1, fontWeight = FontWeight.Bold, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp, start = 8.dp, end = 8.dp)
                )
            }
        }
    }
}

/** Плитка на рабочем столе: тап запускает приложение, как у обычной иконки. */
@Composable
fun AppTileItem(app: AppInfo, labels: Boolean, iconSize: Int, hidden: Boolean, interactive: Boolean) {
    val open = LocalOpenTile.current
    val launchPkg = LocalLaunchPkg.current
    val unlock = LocalUnlock.current
    val sw = LocalContext.current.resources.displayMetrics.widthPixels.toFloat()
    var rect by remember { mutableStateOf<Rect?>(null) }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        if (pressed && interactive) 0.94f else 1f, spring(dampingRatio = 0.5f, stiffness = 520f), label = "tilePress"
    )
    AppTile(
        app, labels, iconSize,
        Modifier.fillMaxSize().padding(4.dp)
            .onGloballyPositioned { rect = it.boundsInWindow() }
            .graphicsLayer {
                var k = pressScale
                val u = unlock()
                if (u != 1f && prefs.unlockStyle == "normal") {
                    val cx = rect?.center?.x ?: (sw / 2f)
                    translationX = (cx - sw / 2f) * 1.15f * (1f - u)
                    k *= (0.5f + 0.5f * u).coerceAtLeast(0f)
                    alpha = (u * 1.6f).coerceIn(0f, 1f)
                }
                scaleX = k
                scaleY = k
                if (hidden || launchPkg(app.pkg, rect)) alpha = 0f
            }
            .then(
                if (interactive) Modifier.clickable(interactionSource = src, indication = null) { open(app, rect) }
                else Modifier
            )
    )
}
