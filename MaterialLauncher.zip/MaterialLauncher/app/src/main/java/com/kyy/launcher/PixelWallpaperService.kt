package com.kyy.launcher

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.Display
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import androidx.core.content.ContextCompat

/**
 * Живые обои «Google Pixel»: цветной фон и фото внутри формы на экране блокировки.
 * При разблокировке форма плавно раскрывается на весь экран, при блокировке — сворачивается обратно.
 * Рисование идёт в отдельном потоке, чтобы занятый UI-поток при разблокировке не давал рывков.
 */
class PixelWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = PixelEngine()

    inner class PixelEngine : Engine() {
        private val svc = this@PixelWallpaperService
        private val handler = Handler(Looper.getMainLooper())
        private val km = svc.getSystemService(KeyguardManager::class.java)
        private val pm = svc.getSystemService(PowerManager::class.java)
        private val pPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

        @Volatile private var bg: Bitmap? = null
        @Volatile private var pp = PixelParams()
        private var rt: HandlerThread? = null
        private var rh: Handler? = null

        // только главный поток
        private var shown = false
        private var destroyed = false
        private var instant = true      // следующее обновление сразу в конечное состояние, без анимации
        private var goingAway = false   // система сообщила, что экран блокировки уходит
        private var previewOpen = false
        private var polling = false
        private var receiverOn = false
        private var loadToken = 0

        // только поток рисования: e = 0 форма, 1 весь экран
        private var pe = 0f
        private var peFrom = 0f
        private var peTo = 0f
        private var pStart = 0L
        private var pDur = 0.5f
        private var pRunning = false

        private val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { refresh() }
        }

        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "rev") loadAssetsAsync()
        }

        // пока экран заблокирован, несколько раз в секунду проверяем замок,
        // чтобы форма раскрылась сразу после разблокировки
        private val pollRun = object : Runnable {
            override fun run() {
                if (!polling) return
                if (!km.isKeyguardLocked) refresh() else handler.postDelayed(this, 100)
            }
        }

        // ---------- жизненный цикл ----------

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)
            PixelStore.prefs(svc).registerOnSharedPreferenceChangeListener(prefsListener)
            // касание нужно только в превью выбора обоев: тап показывает раскрытие
            setTouchEventsEnabled(isPreview)
            loadAssetsAsync()
        }

        override fun onDestroy() {
            destroyed = true
            PixelStore.prefs(svc).unregisterOnSharedPreferenceChangeListener(prefsListener)
            unregisterRx()
            stopPoll()
            rh?.removeCallbacksAndMessages(null)
            rt?.quitSafely()
            rt = null
            rh = null
            super.onDestroy()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            shown = visible
            if (visible) {
                // при включении экрана сразу рисуем нужное состояние (форма на экране блокировки, фото на рабочем столе),
                // а не доигрываем анимацию с прошлого раза
                instant = true
                registerRx()
            } else {
                goingAway = false
                unregisterRx()
            }
            refresh()
        }

        // Система сообщает обоям о начале разблокировки раньше, чем isKeyguardLocked меняется,
        // поэтому анимацию успевает быть видно.
        override fun onCommand(
            action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean
        ): Bundle? {
            if (!isPreview) {
                when (action) {
                    "android.wallpaper.keyguardgoingaway" -> {
                        goingAway = true
                        refresh()
                    }
                    "android.wallpaper.goingtosleep" -> goingAway = false
                }
            }
            return super.onCommand(action, x, y, z, extras, resultRequested)
        }

        override fun onTouchEvent(event: MotionEvent?) {
            if (event == null) return
            if (isPreview && event.actionMasked == MotionEvent.ACTION_UP) {
                previewOpen = !previewOpen
                refresh()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            refresh()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            shown = false
            unregisterRx()
            stopPoll()
            if (rt != null) renderPost { stopAnim() }
            super.onSurfaceDestroyed(holder)
        }

        // События экрана слушаем только пока обои видны; приёмник не экспортируется.
        private fun registerRx() {
            if (receiverOn) return
            fun filter(withPowerSave: Boolean) = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
                if (withPowerSave) addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            }
            // некоторые прошивки отказывают в регистрации — обои из-за этого падать не должны
            try {
                ContextCompat.registerReceiver(svc, receiver, filter(true), ContextCompat.RECEIVER_NOT_EXPORTED)
                receiverOn = true
            } catch (e: Exception) {
                try {
                    ContextCompat.registerReceiver(svc, receiver, filter(false), ContextCompat.RECEIVER_NOT_EXPORTED)
                    receiverOn = true
                } catch (e2: Exception) {
                }
            }
        }

        private fun unregisterRx() {
            if (!receiverOn) return
            try { svc.unregisterReceiver(receiver) } catch (e: Exception) { }
            receiverOn = false
        }

        // ---------- логика состояния ----------

        private fun renderPost(r: () -> Unit) {
            if (rt == null) {
                rt = HandlerThread("pixelwall-render", Process.THREAD_PRIORITY_DISPLAY).also { it.start() }
                rh = Handler(rt!!.looper)
            }
            rh?.post { r() }
        }

        private fun refresh() {
            if (!shown || (!isPreview && !pm.isInteractive)) {
                // скрыто или экран выключен: ни кадров, ни опроса
                goingAway = false
                stopPoll()
                if (rt != null) renderPost { stopAnim() }
                return
            }
            val wantOpen = if (isPreview) previewOpen else (goingAway || !km.isKeyguardLocked)
            val target = if (wantOpen) 1f else 0f
            val inst = instant
            instant = false
            if (wantOpen) stopPoll() else startPoll()
            renderPost { animateTo(target, inst) }
        }

        private fun startPoll() {
            if (polling || isPreview) return
            polling = true
            handler.postDelayed(pollRun, 120)
        }

        private fun stopPoll() {
            polling = false
            handler.removeCallbacks(pollRun)
        }

        // ---------- всё ниже работает в потоке рисования ----------

        private val frameCb = object : Choreographer.FrameCallback {
            override fun doFrame(t: Long) {
                if (!pRunning) return
                // отсчёт начинается с первого настоящего кадра, поздний старт не съедает анимацию
                if (pStart == 0L) pStart = t
                val p = ((t - pStart) / 1e9f / pDur).coerceIn(0f, 1f)
                val inv = 1f - p
                pe = peFrom + (peTo - peFrom) * (1f - inv * inv * inv)
                draw()
                if (p >= 1f) {
                    pe = peTo
                    pRunning = false
                    rateHint(false)
                } else {
                    Choreographer.getInstance().postFrameCallback(this)
                }
            }
        }

        private fun animateTo(target: Float, jump: Boolean) {
            if (jump) {
                Choreographer.getInstance().removeFrameCallback(frameCb)
                pRunning = false
                pe = target
                peTo = target
                draw()
                return
            }
            if (!pRunning && pe == target) {
                peTo = target
                draw()
                return
            }
            if (pRunning && peTo == target) return
            peFrom = pe
            peTo = target
            pStart = 0L
            pDur = if (target > pe) 0.5f else 0.6f
            if (!pRunning) {
                pRunning = true
                rateHint(true)
                Choreographer.getInstance().postFrameCallback(frameCb)
            }
        }

        private fun stopAnim() {
            Choreographer.getInstance().removeFrameCallback(frameCb)
            if (pRunning) rateHint(false)
            pRunning = false
        }

        private fun draw() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = try {
                    holder.lockHardwareCanvas()
                } catch (e: Exception) {
                    holder.lockCanvas()
                }
                if (c != null) {
                    c.drawColor(Color.BLACK)
                    val b = bg
                    if (b != null) {
                        PixelScene.draw(c, c.width.toFloat(), c.height.toFloat(), b, pp, pe, pPaint)
                    } else {
                        c.drawColor(pp.bg)
                    }
                }
            } catch (e: Exception) {
                // поверхность ещё не готова
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (e: Exception) { }
                }
            }
        }

        // просим систему о полной частоте обновления на время анимации (на некоторых прошивках обои идут в 30 к/с)
        private fun rateHint(on: Boolean) {
            if (Build.VERSION.SDK_INT < 30) return
            try {
                val hz = svc.getSystemService(DisplayManager::class.java)
                    .getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: 60f
                surfaceHolder.surface.setFrameRate(if (on) hz else 0f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT)
            } catch (e: Throwable) { }
        }

        // ---------- данные ----------

        // Декодирование идёт в фоне, чтобы обои никогда не подвисали.
        private fun loadAssetsAsync() {
            val token = ++loadToken
            Thread {
                val photo = try { PixelStore.loadPhoto(svc) } catch (e: Throwable) { null }
                val params = PixelStore.params(svc)
                handler.post {
                    if (destroyed || token != loadToken) return@post
                    stopPoll()
                    if (rt != null) renderPost { stopAnim() }
                    bg = photo
                    pp = params
                    instant = true
                    goingAway = false
                    refresh()
                }
            }.start()
        }
    }
}
