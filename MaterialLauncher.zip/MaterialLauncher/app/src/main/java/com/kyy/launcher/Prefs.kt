package com.kyy.launcher

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

lateinit var prefs: Prefs

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        CustomFonts.init(this)
    }
}

class StateProp<T : Any>(
    private val sp: SharedPreferences,
    private val key: String,
    private val def: T
) : ReadWriteProperty<Any?, T> {
    private val st = mutableStateOf(read())

    @Suppress("UNCHECKED_CAST")
    private fun read(): T = when (def) {
        is Boolean -> sp.getBoolean(key, def)
        is Int -> sp.getInt(key, def)
        else -> sp.getString(key, def as String) ?: def
    } as T

    override fun getValue(thisRef: Any?, property: KProperty<*>): T = st.value

    override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        st.value = value
        val e = sp.edit()
        when (value) {
            is Boolean -> e.putBoolean(key, value)
            is Int -> e.putInt(key, value)
            else -> e.putString(key, value as String)
        }
        e.apply()
    }
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    var themeMode by StateProp(sp, "themeMode", "system")   // system/light/dark
    var accent by StateProp(sp, "accent", "system")         // system или имя из Palette
    var palette by StateProp(sp, "palette", "tonal")        // стиль палитры Material You
    var contrast by StateProp(sp, "contrast", 0)            // 0..100 %
    var corner by StateProp(sp, "corner", 100)              // скругление углов 0..100 %
    var font by StateProp(sp, "font", "rounded")            // system/rounded/serif/mono или custom:файл.ttf
    var weightBoost by StateProp(sp, "weightBoost", 100)    // 0/100/200
    var iconMode by StateProp(sp, "iconMode", "themed")     // original/themed
    var iconShape by StateProp(sp, "iconShape", "cookie")
    var iconColor by StateProp(sp, "iconColor", "auto")     // auto или имя из Palette
    var iconSize by StateProp(sp, "iconSize", 56)
    // размер иконок в меню приложений; пока не задан отдельно, равен размеру на главном экране
    var drawerIconSize by StateProp(sp, "drawerIconSize", sp.getInt("iconSize", 56))
    var iconPack by StateProp(sp, "iconPack", "")           // пакет стороннего набора иконок, "" = системные
    var showLabels by StateProp(sp, "showLabels", true)
    var showSearch by StateProp(sp, "showSearch", false)
    var showClock by StateProp(sp, "showClock", false)
    var showInfo by StateProp(sp, "showInfo", false)
    var dockSize by StateProp(sp, "dockSize", 56)           // размер иконок в доке, dp
    var dockBg by StateProp(sp, "dockBg", true)             // фон дока
    var homeCols by StateProp(sp, "homeCols", 4)
    var homeRows by StateProp(sp, "homeRows", 4)             // 0 = авто, иначе число рядов на главном экране (по умолчанию 4)
    var drawerCols by StateProp(sp, "drawerCols", 4)
    var animBlur by StateProp(sp, "animBlur", false)           // размытие фона во время анимации запуска (Android 12+)
    var animsEnabled by StateProp(sp, "animsEnabled", true) // общий выключатель всех анимаций
    var openAnim by StateProp(sp, "openAnim", true)
    var openDelay by StateProp(sp, "openDelay", 1000)       // пауза перед запуском приложения, мс
    var previewUnlock by StateProp(sp, "previewUnlock", false)
    var animSpeed by StateProp(sp, "animSpeed", 100)        // 50..200 %, скорость пружины Pixel-анимации
    var unlockAnim by StateProp(sp, "unlockAnim", true)
    var unlockStyle by StateProp(sp, "unlockStyle", "pixel") // pixel/normal
    var dock by StateProp(sp, "dock", "")
    var dockInit by StateProp(sp, "dockInit", false)
    var home by StateProp(sp, "home", "")                    // устаревший список pkg|pkg, только для миграции
    var homeItems by StateProp(sp, "homeItems", "")          // pkg,page,col,row,fx,fy;... (см. HomeGrid.kt)
    var homeMigrated by StateProp(sp, "homeMigrated", false)
    var folders by StateProp(sp, "folders", "")                // id~название~pkg|pkg;... (см. Folders.kt)
    var welcomeDone by StateProp(sp, "welcomeDone", false)   // экран приветствия показан
    var widgets by StateProp(sp, "widgets", "")
    var widgetRects by StateProp(sp, "widgetRects", "")      // id:x:y:w:h (dp);...
    var qsbId by StateProp(sp, "qsbId", -1)
    var qsbAsked by StateProp(sp, "qsbAsked", false)
}

val Palette: Map<String, Long> = linkedMapOf(
    "blue" to 0xFF4285F4,
    "red" to 0xFFEA4335,
    "green" to 0xFF34A853,
    "yellow" to 0xFFFBBC04,
    "orange" to 0xFFFF7043,
    "purple" to 0xFF9C27B0,
    "pink" to 0xFFE91E63,
    "teal" to 0xFF009688,
    "gray" to 0xFF607D8B
)

fun String.addPkg(p: String) = (split("|").filter { it.isNotEmpty() && it != p } + p).joinToString("|")
fun String.delPkg(p: String) = split("|").filter { it.isNotEmpty() && it != p }.joinToString("|")
fun String.pkgs() = split("|").filter { it.isNotEmpty() }
