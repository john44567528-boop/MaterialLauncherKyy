package com.kyy.launcher

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.floor
import kotlin.math.max

// ───────────────────────── модель папок ─────────────────────────
// Папка = элемент главного экрана с pkg "folder:<id>" (позиция и размер — как у иконки, см. HomeGrid.kt)
// + запись в prefs.folders: "id~название~pkg|pkg|pkg;..."

class Folder(val id: String, val name: String, val pkgs: List<String>)

private fun cleanName(s: String) = s.replace(Regex("[;~|,\\n]"), " ").trim().take(24)

fun parseFolders(s: String): List<Folder> = s.split(";").mapNotNull { e ->
    val p = e.split("~")
    if (p.size != 3 || p[0].isEmpty()) null
    else Folder(p[0], p[1], p[2].split("|").filter { it.isNotEmpty() })
}

fun saveFolders(l: List<Folder>) {
    val enc = l.joinToString(";") { "${it.id}~${cleanName(it.name)}~${it.pkgs.joinToString("|")}" }
    if (enc != prefs.folders) prefs.folders = enc
}

/** Иконку навели на другую: получилась папка из двух (или иконка добавилась в уже существующую папку). */
fun List<HomeItem>.mergedInto(dragPkg: String, targetPkg: String): List<HomeItem> {
    val target = firstOrNull { it.pkg == targetPkg } ?: return this
    val fs = parseFolders(prefs.folders)
    val dragApp = dragPkg.substringBefore('#')   // у копии id вида pkg#2, в папке хранится сам пакет
    if (target.isFolder) {
        val id = target.folderId
        saveFolders(fs.map { if (it.id == id && dragApp !in it.pkgs) Folder(it.id, it.name, it.pkgs + dragApp) else it })
        return filter { it.pkg != dragPkg }
    }
    if (target.appPkg == dragApp) return this
    val id = "f" + System.currentTimeMillis().toString(36)
    saveFolders(fs + Folder(id, "", listOf(target.appPkg, dragApp)))
    return filter { it.pkg != dragPkg && it.pkg != target.pkg } +
        HomeItem("folder:$id", target.page, target.col, target.row, target.fx, target.fy)
}

/** Убрать приложение из папки. Если в папке осталось меньше двух — папка распадается. */
fun List<HomeItem>.withoutMember(pkg: String): List<HomeItem> {
    val fs = parseFolders(prefs.folders)
    if (fs.none { pkg in it.pkgs }) return this
    var res = this
    val out = ArrayList<Folder>()
    for (f in fs) {
        if (pkg !in f.pkgs) { out.add(f); continue }
        val rest = f.pkgs.filter { it != pkg }
        if (rest.size >= 2) { out.add(Folder(f.id, f.name, rest)); continue }
        val key = "folder:${f.id}"
        val at = res.firstOrNull { it.pkg == key }
        res = res.filter { it.pkg != key }
        if (at != null && rest.size == 1) res = res + HomeItem(res.freshId(rest[0]), at.page, at.col, at.row, at.fx, at.fy)
    }
    saveFolders(out)
    return res
}

/** Расформировать папку: приложения возвращаются на экран. */
fun List<HomeItem>.dissolved(item: HomeItem, cols: Int): List<HomeItem> {
    val all = parseFolders(prefs.folders)
    val f = all.firstOrNull { it.id == item.folderId }
    saveFolders(all.filter { it.id != item.folderId })
    var res = filter { it.pkg != item.pkg }
    f?.pkgs?.forEachIndexed { i, p ->
        if (i == 0) res = res + HomeItem(res.freshId(p), item.page, item.col, item.row, item.fx, item.fy)
        else {
            val t = res.firstFree(cols)
            res = res + HomeItem(res.freshId(p), t.first, t.second, t.third)
        }
    }
    return res
}

/** Чистка: удалённые приложения выпадают из папок, пустые и одиночные папки исчезают, дубликаты убираются. */
fun cleanFolders(items: List<HomeItem>, byPkg: Map<String, AppInfo>): List<HomeItem> {
    val fs = parseFolders(prefs.folders)
    val seen = HashSet<String>()
    var res = items
    val out = ArrayList<Folder>()
    for (f in fs) {
        val key = "folder:${f.id}"
        val at = res.firstOrNull { it.pkg == key } ?: continue
        val m = f.pkgs.filter { (it in byPkg || isPkgInstalled(it)) && seen.add(it) }
        if (m.size >= 2) out.add(Folder(f.id, f.name, m))
        else {
            res = res.filter { it.pkg != key }
            if (m.size == 1) res = res + HomeItem(res.freshId(m[0]), at.page, at.col, at.row, at.fx, at.fy)
        }
    }
    saveFolders(out)
    val keys = out.map { "folder:${it.id}" }.toSet()
    // убираем только то, что точно удалено из системы; приложение, которого просто нет в загруженном списке, остаётся на месте
    return res.filter { if (it.isFolder) it.pkg in keys else (it.appPkg in byPkg || isPkgInstalled(it.appPkg)) }
}

// ───────────────────────── фон папок (цвет, прозрачность, Liquid Glass) ─────────────────────────

private fun folderGlass() = prefs.folderStyle == "glass"
private fun folderFill() = 1f - prefs.folderTransp.coerceIn(0, 100) / 100f

/** Цвет плашки папки: «как тема» (themeColor) или выбранный в настройках. */
fun folderBase(themeColor: Color): Color {
    val c = prefs.folderColor
    return when {
        c == "mono_black" -> Color(0xFF121212)
        c == "mono_gray" -> Color(0xFF9E9E9E)
        c == "mono_white" -> Color(0xFFF7F7F7)
        c.startsWith("hue:") -> {
            val h = (c.removePrefix("hue:").toFloatOrNull() ?: 0f).coerceIn(0f, 360f)
            Color(android.graphics.Color.HSVToColor(floatArrayOf(h, .55f, .85f)))
        }
        else -> Palette[c]?.let { Color(it) } ?: themeColor
    }
}

/** Цвет текста и мини-иконок поверх плашки: на прозрачной — белый (под ней тёмная подложка), на плотной — по яркости цвета. */
fun folderOn(themeBase: Color, themeOn: Color): Color {
    val visible = if (folderGlass()) folderFill() * .6f else folderFill()
    if (visible < .5f) return Color.White
    if (prefs.folderColor == "auto") return themeOn
    return if (folderBase(themeBase).luminance() > .5f) Color(0xFF1B1B1B) else Color.White
}

/**
 * Плашка папки (и плитка на рабочем столе, и открытое окно). «Обычный» стиль: заливка выбранным цветом с настраиваемой
 * прозрачностью. «Liquid Glass»: размытые обои, лёгкая подкраска, стеклянный блик и светлая кромка.
 * Размытие рисуется по копии обоев, как у дока (Android 12+); если обои прочитать нельзя, остаётся прозрачная подкраска.
 */
@Composable
fun FolderPlate(
    shape: Shape, themeBase: Color, modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.TopStart, content: @Composable BoxScope.() -> Unit
) {
    val glass = folderGlass()
    val fill = folderFill()
    val base = folderBase(themeBase)
    val ctx = LocalContext.current
    val resumeV = (ctx as? MainActivity)?.resume?.intValue ?: 0
    var b by remember { mutableStateOf(Rect.Zero) }
    Box(
        modifier.onGloballyPositioned { if (fill < .98f) b = it.boundsInWindow() }.clip(shape),
        contentAlignment = contentAlignment
    ) {
        if (fill < .98f) DockBlurBackdrop(Modifier.matchParentSize(), b.left, b.top, prefs.folderBlur, resumeV)
        Box(Modifier.matchParentSize().background(base.copy(alpha = if (glass) fill * .6f else fill)))
        if (glass) Box(
            Modifier.matchParentSize()
                .background(Brush.verticalGradient(listOf(Color.White.copy(.16f), Color.Transparent, Color.White.copy(.05f))))
                .background(Brush.linearGradient(listOf(Color.White.copy(.18f), Color.White.copy(.02f), Color.White.copy(.09f))))
                .border(
                    1.2.dp,
                    Brush.linearGradient(listOf(Color.White.copy(.85f), Color.White.copy(.08f), Color.White.copy(.45f))),
                    shape
                )
        )
        content()
    }
}

// ───────────────────────── папка на рабочем столе ─────────────────────────

/** Подобрать самый крупный размер мини-иконки (dp), при котором в область помещается нужное число; вернуть (размер, колонки, ряды). */
private fun fitGrid(aw: Float, ah: Float, gap: Float, want: Int): Triple<Int, Int, Int> {
    var mm = 52
    while (mm >= 28) {
        val cc = floor((aw + gap) / (mm + gap)).toInt()
        val rr = floor((ah + gap) / (mm + gap)).toInt()
        if (cc >= 1 && rr >= 1 && cc * rr >= want) return Triple(mm, cc, rr)
        mm -= 2
    }
    return Triple(
        28,
        max(1, floor((aw + gap) / (28 + gap)).toInt()),
        max(1, floor((ah + gap) / (28 + gap)).toInt())
    )
}

@Composable
private fun MiniApp(app: AppInfo, m: Int, interactive: Boolean) {
    val open = LocalOpen.current
    val launchPkg = LocalLaunchPkg.current
    var rect by remember { mutableStateOf<Rect?>(null) }
    val src = remember { MutableInteractionSource() }
    Box(
        Modifier.size(m.dp)
            .onGloballyPositioned { rect = it.boundsInWindow() }
            .graphicsLayer { alpha = if (launchPkg(app.pkg, rect)) 0f else 1f }
            .then(
                if (interactive) Modifier.clickable(interactionSource = src, indication = null) { open(app, rect) }
                else Modifier
            )
    ) { AppIcon(app, m.dp) }
}

/**
 * Папка на главном экране.
 * 1×1 — как на Google Pixel: плитка размером с иконку и 2×2 мини-иконки внутри.
 * Больше (2×1, 1×2, 2×2) — как на ColorOS: приложения лежат прямо в папке и запускаются одним тапом,
 * тап по пустому месту открывает папку целиком.
 */
@Composable
fun FolderView(
    f: Folder?, item: HomeItem, byPkg: Map<String, AppInfo>,
    labels: Boolean, iconSize: Int, hidden: Boolean, interactive: Boolean, onOpen: () -> Unit
) {
    if (f == null) return
    val s = MaterialTheme.colorScheme
    val apps = f.pkgs.mapNotNull { byPkg[it] }
    val name = f.name.ifBlank { "Папка" }
    val on = folderOn(s.secondaryContainer, s.onSecondaryContainer)
    val unlock = LocalUnlock.current
    val sw = LocalContext.current.resources.displayMetrics.widthPixels.toFloat()
    var rect by remember { mutableStateOf<Rect?>(null) }
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        if (pressed && interactive) 0.9f else 1f, spring(dampingRatio = 0.5f, stiffness = 520f), label = "folderPress"
    )
    val click = if (interactive) Modifier.clickable(interactionSource = src, indication = null, onClick = onOpen) else Modifier
    val big = item.w > 1 || item.h > 1

    @Composable
    fun Label() {
        Text(
            name, color = Color.White, fontSize = 12.sp, maxLines = 1,
            fontWeight = FontWeight.Bold, overflow = TextOverflow.Ellipsis,
            style = TextStyle(shadow = Shadow(Color.Black.copy(.35f), blurRadius = 6f)),
            modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp)
        )
    }

    Box(
        Modifier.fillMaxSize()
            .onGloballyPositioned { rect = it.boundsInWindow() }
            .graphicsLayer {
                val u = unlock()
                if (u != 1f && prefs.unlockStyle == "normal") {
                    val cx = rect?.center?.x ?: (sw / 2f)
                    translationX = (cx - sw / 2f) * 1.15f * (1f - u)
                    val sc = (0.5f + 0.5f * u).coerceAtLeast(0f)
                    scaleX = sc
                    scaleY = sc
                    alpha = (u * 1.6f).coerceIn(0f, 1f)
                }
                if (hidden) alpha = 0f
            }
    ) {
        if (!big) {
            Column(
                Modifier.fillMaxWidth().then(click).padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                FolderPlate(
                    shapeOf(prefs.iconShape), s.secondaryContainer,
                    Modifier
                        .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
                        .size(iconSize.dp),
                    Alignment.Center
                ) {
                    val m = iconSize * 0.36f
                    val gap = iconSize * 0.06f
                    Column(verticalArrangement = Arrangement.spacedBy(gap.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        for (r in 0..1) {
                            Row(horizontalArrangement = Arrangement.spacedBy(gap.dp)) {
                                for (c in 0..1) {
                                    val a = apps.getOrNull(r * 2 + c)
                                    if (a != null) AppIcon(a, m.dp) else Spacer(Modifier.size(m.dp))
                                }
                            }
                        }
                    }
                }
                if (labels) Label()
            }
        } else {
            Column(Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 4.dp)) {
                FolderPlate(rc(28), s.secondaryContainer, Modifier.weight(1f).fillMaxWidth().then(click)) {
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val pad = 10f
                    val gap = 8f
                    val aw = maxWidth.value - 2 * pad
                    val ah = maxHeight.value - 2 * pad
                    val cap = if (item.w * item.h == 2) 6 else 9
                    val want = minOf(apps.size, cap)
                    val (m, cols, rows) = fitGrid(aw, ah, gap, want)
                    val limit = minOf(cols * rows, cap)
                    val overflow = apps.size > limit
                    val shown = if (overflow) limit - 1 else apps.size
                    val used = shown + if (overflow) 1 else 0
                    val rowsUsed = (used + cols - 1) / cols
                    Column(
                        Modifier.align(Alignment.Center),
                        verticalArrangement = Arrangement.spacedBy(gap.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        for (r in 0 until rowsUsed) {
                            Row(horizontalArrangement = Arrangement.spacedBy(gap.dp)) {
                                for (c in 0 until cols) {
                                    val idx = r * cols + c
                                    when {
                                        idx < shown -> MiniApp(apps[idx], m, interactive)
                                        idx == shown && overflow -> Box(
                                            Modifier.size(m.dp).clip(RoundedCornerShape((m / 3).dp))
                                                .background(on.copy(alpha = .14f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                "+${apps.size - shown}", color = on,
                                                fontWeight = FontWeight.Bold, fontSize = (m / 3 + 3).sp
                                            )
                                        }
                                        else -> Spacer(Modifier.size(m.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                }
                if (labels) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Label() }
            }
        }
    }
}

// ───────────────────────── меню папки (размер) ─────────────────────────

@Composable
fun SizePicker(item: HomeItem, title: String, onSize: (Int, Int) -> Unit, divider: Boolean = false, dismiss: () -> Unit) {
    val s = MaterialTheme.colorScheme
    Text(
        title, color = s.onSurfaceVariant, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 12.dp, top = 6.dp, bottom = 8.dp)
    )
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(1 to 1, 2 to 1, 1 to 2, 2 to 2).forEach { (w, h) ->
            val sel = item.w == w && item.h == h
            Column(
                Modifier.weight(1f).height(64.dp).clip(rc(16))
                    .background(if (sel) s.primaryContainer else s.surfaceContainerHighest)
                    .clickable { dismiss(); onSize(w, h) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier.size((w * 12 + (w - 1) * 3).dp, (h * 12 + (h - 1) * 3).dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (sel) s.primary else s.onSurfaceVariant)
                )
                Text(
                    "$w×$h", fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    color = if (sel) s.onPrimaryContainer else s.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
    if (divider) HorizontalDivider(Modifier.padding(vertical = 8.dp, horizontal = 8.dp), color = s.outlineVariant)
}

@Composable
fun FolderMenuContent(item: HomeItem, onSize: (Int, Int) -> Unit, onDissolve: () -> Unit, dismiss: () -> Unit) {
    SizePicker(item, "Размер папки", onSize, divider = true, dismiss = dismiss)
    MenuRow(Icons.Filled.Close, "Расформировать", danger = true) { dismiss(); onDissolve() }
}

// ───────────────────────── открытая папка ─────────────────────────

@Composable
fun FolderOverlay(
    id: String, byPkg: Map<String, AppInfo>, menuFor: (AppInfo) -> List<MenuAction>,
    onRemove: (String) -> Unit, onClose: () -> Unit
) {
    val s = MaterialTheme.colorScheme
    val folder = parseFolders(prefs.folders).firstOrNull { it.id == id }
    if (folder == null) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val list = folder.pkgs.mapNotNull { byPkg[it] }
    var name by remember(id) { mutableStateOf(folder.name) }
    val outerOpen = LocalOpen.current
    val focus = LocalFocusManager.current
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val sc by animateFloatAsState(if (shown) 1f else 0.75f, spring(dampingRatio = 0.75f, stiffness = 420f), label = "fsc")
    val al by animateFloatAsState(if (shown) 1f else 0f, tween(180), label = "fal")
    val scope = rememberCoroutineScope()
    // закрытие: сначала плавно гаснем, потом убираем папку
    val closeAnimated: () -> Unit = { scope.launch { shown = false; kotlinx.coroutines.delay(170); onClose() } }
    val none = remember { MutableInteractionSource() }
    val labels = prefs.showLabels
    val on = folderOn(s.surfaceContainerHigh, s.onSurface)
    val plateShape = rc(36)

    Box(
        Modifier.fillMaxSize()
            .background(Color.Black.copy(alpha = .5f * al))
            .clickable(interactionSource = none, indication = null) { focus.clearFocus(); closeAnimated() }
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        FolderPlate(
            plateShape, s.surfaceContainerHigh,
            Modifier
                .padding(24.dp)
                .widthIn(max = 380.dp)
                .fillMaxWidth()
                .graphicsLayer { scaleX = sc; scaleY = sc; alpha = al }
                // тень только у плотной плашки: сквозь прозрачную она просвечивала бы
                .then(if (!folderGlass() && folderFill() >= .98f) Modifier.shadow(12.dp, plateShape) else Modifier)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (labels) BasicTextField(
                    value = name,
                    onValueChange = { v ->
                        name = v.take(24)
                        saveFolders(parseFolders(prefs.folders).map { if (it.id == id) Folder(it.id, name, it.pkgs) else it })
                    },
                    singleLine = true,
                    textStyle = TextStyle(
                        color = on, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
                    ),
                    cursorBrush = SolidColor(on),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { focus.clearFocus() }),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
                    decorationBox = { inner ->
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            if (name.isEmpty()) {
                                Text("Папка", color = on.copy(alpha = .6f), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                            inner()
                        }
                    }
                )
                // папка остаётся открытой: после закрытия приложения возвращаемся в неё, анимация закрытия сворачивается в иконку внутри папки
                CompositionLocalProvider(LocalOpen provides { app, r -> outerOpen(app, r) }) {
                    Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                        list.chunked(3).forEach { row ->
                            Row(Modifier.fillMaxWidth()) {
                                row.forEach { app ->
                                    val menu = listOf(
                                        MenuAction(Icons.Filled.Close, "Убрать из папки") { onRemove(app.pkg) }
                                    ) + menuFor(app)
                                    AppItem(app, labels, on, menu, Modifier.weight(1f))
                                }
                                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
        }
    }
}
