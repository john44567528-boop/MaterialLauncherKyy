package com.kyy.launcher

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.Xml
import androidx.core.content.res.ResourcesCompat
import org.xmlpull.v1.XmlPullParser

/**
 * Сторонние наборы иконок (формат ADW / Nova / Apex): приложение-набор с appfilter.xml,
 * где каждому компоненту сопоставлена картинка.
 */
object IconPacks {
    class Pack(val pkg: String, val label: String)
    private class Data(val byComponent: Map<String, String>, val byPkg: Map<String, String>)

    private val ACTIONS = listOf(
        "org.adw.launcher.THEMES",
        "com.novalauncher.THEME",
        "com.anddoes.launcher.THEME",
        "org.adw.launcher.icons.ACTION_PICK_ICON",
        "com.gau.go.launcherex.theme"
    )
    private val cache = HashMap<String, Data?>()

    /** Установленные на телефоне наборы иконок. */
    fun list(ctx: Context): List<Pack> {
        val pm = ctx.packageManager
        val found = LinkedHashMap<String, Pack>()
        for (a in ACTIONS) {
            runCatching {
                pm.queryIntentActivities(Intent(a), 0).forEach {
                    val p = it.activityInfo.packageName
                    if (p !in found) found[p] = Pack(p, it.loadLabel(pm).toString())
                }
            }
        }
        return found.values.sortedBy { it.label.lowercase() }
    }

    @Synchronized
    private fun load(ctx: Context, pack: String): Data? {
        if (cache.containsKey(pack)) return cache[pack]
        val d = runCatching { parse(ctx, pack) }.getOrNull()
        cache[pack] = d
        return d
    }

    private fun parse(ctx: Context, pack: String): Data? {
        val res = ctx.packageManager.getResourcesForApplication(pack)
        val parser: XmlPullParser
        val stream = runCatching { res.assets.open("appfilter.xml") }.getOrNull()
        if (stream != null) {
            parser = Xml.newPullParser()
            parser.setInput(stream, null)
        } else {
            val id = res.getIdentifier("appfilter", "xml", pack)
            if (id == 0) return null
            parser = res.getXml(id)
        }
        val comp = HashMap<String, String>()
        val byPkg = HashMap<String, String>()
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                val c = parser.getAttributeValue(null, "component")
                val d = parser.getAttributeValue(null, "drawable")
                if (c != null && d != null && c.startsWith("ComponentInfo{") && c.endsWith("}")) {
                    val inner = c.substring(14, c.length - 1)
                    val slash = inner.indexOf('/')
                    if (slash > 0) {
                        val p = inner.substring(0, slash)
                        var cls = inner.substring(slash + 1)
                        if (cls.startsWith(".")) cls = p + cls
                        comp["$p/$cls"] = d
                        if (p !in byPkg) byPkg[p] = d
                    }
                }
            }
            ev = parser.next()
        }
        return Data(comp, byPkg)
    }

    /** Иконка приложения из набора или null, если в наборе её нет. */
    fun render(ctx: Context, pack: String, app: AppInfo): Bitmap? {
        val data = load(ctx, pack) ?: return null
        val name = data.byComponent[app.cn.packageName + "/" + app.cn.className] ?: data.byPkg[app.pkg] ?: return null
        val res = ctx.packageManager.getResourcesForApplication(pack)
        var id = res.getIdentifier(name, "drawable", pack)
        if (id == 0) id = res.getIdentifier(name, "mipmap", pack)
        if (id == 0) return null
        val d = ResourcesCompat.getDrawable(res, id, null) ?: return null
        val s = 256
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s)
        d.draw(Canvas(out))
        return out
    }
}
