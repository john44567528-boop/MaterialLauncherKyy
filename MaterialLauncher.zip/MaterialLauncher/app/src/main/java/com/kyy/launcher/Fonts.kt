package com.kyy.launcher

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.em
import java.io.File

/** Свои шрифты (TTF, OTF): копируются в память приложения, в настройках выбираются как «custom:имя_файла». */
object CustomFonts {
    const val PREFIX = "custom:"
    private const val MAX_BYTES = 25L * 1024 * 1024

    private lateinit var app: Context
    private val cache = HashMap<String, FontFamily>()

    fun init(c: Context) { app = c.applicationContext }

    private fun dir() = File(app.filesDir, "fonts").apply { mkdirs() }

    /** Имена файлов импортированных шрифтов. */
    fun list(): List<String> =
        dir().listFiles()
            ?.filter { it.isFile && (it.extension.equals("ttf", true) || it.extension.equals("otf", true)) }
            ?.map { it.name }?.sortedBy { it.lowercase() } ?: emptyList()

    fun label(file: String) = file.substringBeforeLast('.')

    /** Семейство для Compose или null, если файла нет или он не читается. */
    fun family(file: String): FontFamily? {
        cache[file]?.let { return it }
        val f = File(dir(), file)
        if (!f.exists()) return null
        val tf = try { Typeface.Builder(f).build() } catch (e: Throwable) { null } ?: return null
        return FontFamily(tf).also { cache[file] = it }
    }

    /** Копирует шрифт из выбранного файла. Возвращает имя сохранённого файла или null, если это не шрифт. */
    fun import(uri: Uri): String? {
        val cr = app.contentResolver
        var display = uri.lastPathSegment ?: "font"
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0)?.let { n -> display = n }
        }
        val base = display.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N} _.-]"), "_").trim().take(40).ifEmpty { "font" }

        val tmp = File(dir(), ".import.tmp")
        var total = 0L
        val input = cr.openInputStream(uri) ?: return null
        input.use { inp ->
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_BYTES) { tmp.delete(); return null }
                    out.write(buf, 0, n)
                }
            }
        }

        // заголовок TrueType / OpenType / коллекции
        val head = ByteArray(4)
        val got = tmp.inputStream().use { it.read(head) }
        val sig = String(head, Charsets.ISO_8859_1)
        val isTrueType = got == 4 && (head.contentEquals(byteArrayOf(0, 1, 0, 0)) || sig == "true" || sig == "ttcf")
        val isOpenType = got == 4 && sig == "OTTO"
        if (!isTrueType && !isOpenType) { tmp.delete(); return null }

        val name = "$base." + if (isOpenType) "otf" else "ttf"
        val dst = File(dir(), name)
        if (dst.exists()) dst.delete()
        if (!tmp.renameTo(dst)) { tmp.delete(); return null }
        cache.remove(name)
        val ok = try { Typeface.Builder(dst).build() != null } catch (e: Throwable) { false }
        if (!ok) { dst.delete(); return null }
        return name
    }

    fun delete(file: String) {
        cache.remove(file)
        File(dir(), file).delete()
    }
}

/** Шрифт часов на экране блокировки. family == null — взять шрифт приложения как раньше. */
class ClockFont(val id: String, val label: String, val family: FontFamily?, val spacingEm: Float = 0f)

val ClockFont.spacing: TextUnit get() = if (spacingEm == 0f) TextUnit.Unspecified else spacingEm.em

/** Набор системных шрифтов для часов (как выбор стиля часов на Pixel) плюс свои TTF/OTF из CustomFonts. */
object LockClockFonts {
    private fun tf(name: String, style: Int = Typeface.NORMAL): FontFamily? =
        try { FontFamily(Typeface.create(name, style)) } catch (e: Throwable) { null }

    val presets: List<ClockFont> by lazy {
        listOf(
            ClockFont("theme", "Как в приложении", null),
            ClockFont("thin", "Тонкий", tf("sans-serif-thin")),
            ClockFont("light", "Лёгкий", tf("sans-serif-light")),
            ClockFont("regular", "Обычный", tf("sans-serif")),
            ClockFont("medium", "Средний", tf("sans-serif-medium")),
            ClockFont("bold", "Жирный", tf("sans-serif", Typeface.BOLD)),
            ClockFont("black", "Чёрный", tf("sans-serif-black")),
            ClockFont("rounded", "Скруглённый", tf("sans-serif-rounded")),
            ClockFont("cond", "Узкий", tf("sans-serif-condensed")),
            ClockFont("condlight", "Узкий лёгкий", tf("sans-serif-condensed-light")),
            ClockFont("condbold", "Узкий жирный", tf("sans-serif-condensed", Typeface.BOLD)),
            ClockFont("wide", "Разрежённый", tf("sans-serif-light"), 0.14f),
            ClockFont("widebold", "Широкий", tf("sans-serif-medium"), 0.08f),
            ClockFont("serif", "С засечками", tf("serif")),
            ClockFont("serifbold", "Засечки жирные", tf("serif", Typeface.BOLD)),
            ClockFont("italic", "Курсив", tf("sans-serif", Typeface.ITALIC)),
            ClockFont("serifitalic", "Курсив с засечками", tf("serif", Typeface.ITALIC)),
            ClockFont("smallcaps", "Капитель", tf("sans-serif-smallcaps")),
            ClockFont("mono", "Моно", tf("monospace")),
            ClockFont("typewriter", "Печатная машинка", tf("serif-monospace")),
            ClockFont("casual", "Casual", tf("casual")),
            ClockFont("cursive", "Рукописный", tf("cursive"))
        )
    }

    fun resolve(id: String): ClockFont {
        if (id.startsWith(CustomFonts.PREFIX)) {
            val file = id.removePrefix(CustomFonts.PREFIX)
            CustomFonts.family(file)?.let { return ClockFont(id, CustomFonts.label(file), it) }
        }
        return presets.firstOrNull { it.id == id } ?: presets.first()
    }
}
