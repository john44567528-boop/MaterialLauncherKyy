package com.kyy.launcher

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToInt

// ───────────────────────── модель ─────────────────────────

/**
 * Иконка на главном экране.
 * Обычная: лежит в ячейке сетки (page, col, row), fx/fy = -1.
 * DIY: стоит где угодно, fx/fy — положение левого верхнего угла в dp внутри страницы.
 */
data class HomeItem(
    val pkg: String,
    val page: Int,
    val col: Int,
    val row: Int,
    val fx: Float = -1f,
    val fy: Float = -1f,
    val w: Int = 1,   // размер в ячейках (больше 1 только у папок)
    val h: Int = 1
) {
    val free: Boolean get() = fx >= 0f && fy >= 0f
    val isFolder: Boolean get() = pkg.startsWith("folder:")
    val folderId: String get() = pkg.removePrefix("folder:")
    /** Пакет приложения: id копии вида "pkg#2" → "pkg" (одно приложение можно положить на экран много раз). */
    val appPkg: String get() = if (isFolder) pkg else pkg.substringBefore('#')
    fun covers(c: Int, r: Int) = c >= col && c < col + w && r >= row && r < row + h
    fun overlaps(o: HomeItem) = col < o.col + o.w && o.col < col + w && row < o.row + o.h && o.row < row + h
}

/** Сколько рядов помещается на странице (обновляет HomePage после измерения экрана). */
object HomeMetrics {
    var rows0 by mutableIntStateOf(5)   // первая страница: сверху часы и дата
    var rowsN by mutableIntStateOf(7)   // остальные страницы
    fun rowsFor(page: Int) = if (page == 0) rows0 else rowsN
}

fun parseHome(s: String): List<HomeItem> = s.split(";").mapNotNull { e ->
    val p = e.split(",")
    if (p.size != 6 && p.size != 8) return@mapNotNull null
    val page = p[1].toIntOrNull() ?: return@mapNotNull null
    val col = p[2].toIntOrNull() ?: return@mapNotNull null
    val row = p[3].toIntOrNull() ?: return@mapNotNull null
    val fx = p[4].toIntOrNull() ?: -1
    val fy = p[5].toIntOrNull() ?: -1
    val w = (p.getOrNull(6)?.toIntOrNull() ?: 1).coerceIn(1, 2)
    val h = (p.getOrNull(7)?.toIntOrNull() ?: 1).coerceIn(1, 2)
    if (p[0].isEmpty()) null else HomeItem(p[0], page, col, row, fx.toFloat(), fy.toFloat(), w, h)
}

fun List<HomeItem>.encode(): String = joinToString(";") {
    val x = if (it.free) it.fx.roundToInt() else -1
    val y = if (it.free) it.fy.roundToInt() else -1
    "${it.pkg},${it.page},${it.col},${it.row},$x,$y,${it.w},${it.h}"
}

private fun List<HomeItem>.occupant(page: Int, col: Int, row: Int, except: String?): HomeItem? =
    firstOrNull { !it.free && it.page == page && it.covers(col, row) && it.pkg != except }

/** Первая свободная ячейка (страница, колонка, ряд); если всё занято — новая страница. */
fun List<HomeItem>.firstFree(
    cols: Int, except: String? = null, w: Int = 1, h: Int = 1,
    rowsFor: (Int) -> Int = { HomeMetrics.rowsFor(it) }
): Triple<Int, Int, Int> {
    val last = (maxOfOrNull { it.page } ?: 0) + 1
    for (p in 0..last) {
        for (r in 0..(rowsFor(p) - h)) {
            for (c in 0..(cols - w)) {
                var ok = true
                for (dr in 0 until h) for (dc in 0 until w) if (occupant(p, c + dc, r + dr, except) != null) ok = false
                if (ok) return Triple(p, c, r)
            }
        }
    }
    return Triple(last + 1, 0, 0)
}

/** Свободный id для новой копии приложения: pkg, pkg#2, pkg#3… */
fun List<HomeItem>.freshId(pkg: String): String {
    if (none { it.pkg == pkg }) return pkg
    var n = 2
    while (any { it.pkg == "$pkg#$n" }) n++
    return "$pkg#$n"
}

/** Добавить приложение на экран; если оно уже там есть — появится ещё одна копия. */
fun List<HomeItem>.withAdded(pkg: String, cols: Int): List<HomeItem> {
    val t = firstFree(cols)
    return this + HomeItem(freshId(pkg), t.first, t.second, t.third)
}

const val REMOVE_HOME = "Убрать с экрана"

/** Положить иконку (или папку любого размера) в ячейку. Кого она накрыла — тот меняется с ней местами (1×1) или уходит в свободное место. */
fun List<HomeItem>.placedOnGrid(pkg: String, page: Int, col: Int, row: Int, cols: Int): List<HomeItem> {
    val me = firstOrNull { it.pkg == pkg } ?: return this
    val rows = HomeMetrics.rowsFor(page)
    val placed = me.copy(
        page = page, fx = -1f, fy = -1f,
        col = col.coerceIn(0, (cols - me.w).coerceAtLeast(0)),
        row = row.coerceIn(0, (rows - me.h).coerceAtLeast(0))
    )
    val others = filter { it.pkg != pkg }
    val hit = others.filter { !it.free && it.page == page && it.overlaps(placed) }
    var res = others.filter { o -> hit.none { it.pkg == o.pkg } } + placed
    if (hit.size == 1 && hit[0].w == 1 && hit[0].h == 1 && me.w == 1 && me.h == 1 && !me.free) {
        res = res + hit[0].copy(page = me.page, col = me.col, row = me.row, fx = -1f, fy = -1f)
    } else {
        for (o in hit) {
            val t = res.firstFree(cols, null, o.w, o.h)
            res = res + o.copy(page = t.first, col = t.second, row = t.third, fx = -1f, fy = -1f)
        }
    }
    return res
}

/** Изменить размер папки. Что мешает — переезжает в свободные ячейки. */
fun List<HomeItem>.resized(pkg: String, w: Int, h: Int, cols: Int): List<HomeItem> {
    val me = firstOrNull { it.pkg == pkg } ?: return this
    if (me.free) return map { if (it.pkg == pkg) it.copy(w = w, h = h) else it }
    val rows = HomeMetrics.rowsFor(me.page)
    val w2 = w.coerceAtMost(cols)
    val h2 = h.coerceAtMost(rows)
    val moved = me.copy(
        w = w2, h = h2,
        col = me.col.coerceAtMost(cols - w2).coerceAtLeast(0),
        row = me.row.coerceAtMost(rows - h2).coerceAtLeast(0)
    )
    val others = filter { it.pkg != pkg }
    val hit = others.filter { !it.free && it.page == me.page && it.overlaps(moved) }
    var res = others.filter { o -> hit.none { it.pkg == o.pkg } } + moved
    for (o in hit) {
        val t = res.firstFree(cols, null, o.w, o.h)
        res = res + o.copy(page = t.first, col = t.second, row = t.third)
    }
    return res
}

/** DIY: поставить иконку в произвольную точку страницы. */
fun List<HomeItem>.placedFree(pkg: String, page: Int, fx: Float, fy: Float): List<HomeItem> =
    map { if (it.pkg == pkg) it.copy(page = page, fx = fx, fy = fy) else it }

/** Убрать пустые страницы (первая остаётся всегда). */
fun List<HomeItem>.compacted(): List<HomeItem> {
    if (isEmpty()) return this
    val used = map { it.page }.toSortedSet()
    val order = (listOf(0) + used.filter { it != 0 })
    val remap = order.withIndex().associate { (i, p) -> p to i }
    return map { it.copy(page = remap[it.page] ?: 0) }
}

/**
 * Иконки, которые не влезают в сетку (поменяли колонки / размер / повернули экран) — раскладываем по свободным ячейкам.
 * Только для ПОКАЗА: результат нельзя сохранять в настройки, иначе при повороте экрана или смене высоты панелей
 * иконки навсегда съезжают со своих мест. Сохранённые позиции остаются как есть и снова встают на место,
 * когда экран вернулся к прежнему размеру.
 */
fun List<HomeItem>.normalized(cols: Int, rowsFor: (Int) -> Int = { HomeMetrics.rowsFor(it) }): List<HomeItem> {
    var res = this
    for (item in this) {
        val w = item.w.coerceAtMost(cols)
        val h = item.h.coerceAtMost(rowsFor(item.page))
        if (!item.free && (item.col + w > cols || item.row + h > rowsFor(item.page))) {
            val rest = res.filter { it.pkg != item.pkg }
            val t = rest.firstFree(cols, null, w, h, rowsFor)
            res = rest + item.copy(page = t.first, col = t.second, row = t.third, w = w, h = h)
        }
    }
    return res
}

fun homeAdd(pkg: String) {
    prefs.homeItems = parseHome(prefs.homeItems).withAdded(pkg, prefs.homeCols).compacted().encode()
}

fun homeRemove(pkg: String) {
    prefs.homeItems = parseHome(prefs.homeItems).filter { it.appPkg != pkg }.withoutMember(pkg).compacted().encode()
}

/** Старый список «pkg|pkg|…» → сетка; как и раньше, иконки прижаты к низу первой страницы. */
fun migrateLegacy(pkgs: List<String>, cols: Int): List<HomeItem> {
    val rows0 = HomeMetrics.rows0
    val rowsN = HomeMetrics.rowsN
    val need = (pkgs.size + cols - 1) / cols
    val startFlat = (rows0 - need).coerceAtLeast(0) * cols
    return pkgs.mapIndexed { i, pkg ->
        val flat = startFlat + i
        val cap0 = rows0 * cols
        if (flat < cap0) HomeItem(pkg, 0, flat % cols, flat / cols)
        else {
            val rest = flat - cap0
            val capN = rowsN * cols
            val inPage = rest % capN
            HomeItem(pkg, 1 + rest / capN, inPage % cols, inPage / cols)
        }
    }
}

class DragState(val item: HomeItem, val app: AppInfo?, val grab: Offset, start: Offset) {
    var pos by mutableStateOf(start)
}

// ───────────────────────── экран ─────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomePage(
    a: MainActivity,
    apps: List<AppInfo>,
    menuFor: (AppInfo) -> List<MenuAction>,
    diy: Boolean,
    onOpenFolder: (String) -> Unit,
    onDiyDone: () -> Unit
) {
    val s = MaterialTheme.colorScheme
    val dens = LocalDensity.current.density
    val haptic = LocalHapticFeedback.current
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val cols = prefs.homeCols
    val labels = prefs.showLabels
    val iconSize = prefs.iconSize
    val showClock = prefs.showClock
    val showInfo = prefs.showInfo
    val stored = remember(prefs.homeItems) { parseHome(prefs.homeItems) }

    var box by remember { mutableStateOf(IntSize.Zero) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    var drag by remember { mutableStateOf<DragState?>(null) }
    var menu by remember { mutableStateOf<Pair<AppInfo, Rect>?>(null) }
    var menuItem by remember { mutableStateOf<HomeItem?>(null) }
    var fmenu by remember { mutableStateOf<Pair<HomeItem, Rect>?>(null) }
    val folders = remember(prefs.folders) { parseFolders(prefs.folders) }

    // ── геометрия (dp) ──
    val padH = 16f
    val userRows = prefs.homeRows
    val wDp = box.width / dens
    val hDp = box.height / dens
    val cellW = ((wDp - 2 * padH) / cols).coerceAtLeast(1f)
    val top0 = 12f + (if (showClock) 178f else 0f) + (if (showInfo) 64f else 0f)
    val bottomPad = 12f
    // «Авто»: высота ячейки по размеру иконки. Заданное число рядов: ячейки подгоняются, чтобы ряды заняли всю свободную высоту
    val cellH = if (userRows > 0) ((hDp - top0 - bottomPad) / userRows).coerceAtLeast(44f)
                else iconSize + 16f + (if (labels) 22f else 0f)
    val rows0 = floor((hDp - top0 - bottomPad) / cellH + 0.02f).toInt().coerceAtLeast(1)
    val rowsN = floor((hDp - 12f - bottomPad) / cellH + 0.02f).toInt().coerceAtLeast(1)
    val geoKey = listOf<Any>(box, cols, labels, iconSize, showClock, showInfo, userRows)
    // То, что видно на экране: сохранённая раскладка, подогнанная под текущий размер. В настройки это не пишется.
    val items = remember(stored, box, cols, rows0, rowsN) {
        if (box.height <= 0) stored
        else stored.normalized(cols) { if (it == 0) rows0 else rowsN }
    }

    fun topOf(page: Int) = if (page == 0) top0 else 12f
    fun rowsOf(page: Int) = if (page == 0) rows0 else rowsN
    fun cellRect(page: Int, col: Int, row: Int, w: Int = 1, h: Int = 1): Rect {
        val l = (padH + col * cellW) * dens
        val t = (topOf(page) + row * cellH) * dens
        return Rect(l, t, l + cellW * w * dens, t + cellH * h * dens)
    }
    fun itemRect(i: HomeItem): Rect {
        if (!i.free) return cellRect(i.page, i.col, i.row, i.w, i.h)
        val ww = cellW * i.w
        val hh = cellH * i.h
        val x = i.fx.coerceIn(0f, maxOf(0f, wDp - ww))
        val y = i.fy.coerceIn(0f, maxOf(0f, hDp - hh))
        return Rect(x * dens, y * dens, (x + ww) * dens, (y + hh) * dens)
    }
    fun targetOf(d: DragState, page: Int): Triple<Int, Int, Int> {
        val cx = (d.pos.x - d.grab.x) / dens + cellW / 2f
        val cy = (d.pos.y - d.grab.y) / dens + cellH / 2f
        val c = floor((cx - padH) / cellW).toInt().coerceIn(0, (cols - d.item.w).coerceAtLeast(0))
        val r = floor((cy - topOf(page)) / cellH).toInt().coerceIn(0, (rowsOf(page) - d.item.h).coerceAtLeast(0))
        return Triple(page, c, r)
    }
    fun hitTest(p: Offset, page: Int): HomeItem? {
        if (page == 0) {
            for (id in a.widgets.toList()) {
                val r = a.rects[id] ?: continue
                if (p.x >= r.x * dens && p.x <= (r.x + r.w) * dens && p.y >= r.y * dens && p.y <= (r.y + r.h) * dens) return null
            }
        }
        return items.lastOrNull { it.page == page && (it.isFolder || it.appPkg in byPkg) && itemRect(it).contains(p) }
    }

    // ── страницы ──
    val pageCount = (items.maxOfOrNull { it.page } ?: 0) + 1
    val total = if (drag != null) pageCount + 1 else pageCount   // во время переноса справа можно создать новую страницу
    val totalNow by rememberUpdatedState(total)
    val pager = rememberPagerState { totalNow }
    LaunchedEffect(pager) { snapshotFlow { pager.currentPage }.collect { a.homePage.intValue = it } }
    LaunchedEffect(pager) { snapshotFlow { pager.isScrollInProgress }.collect { a.pageScrolling.value = it } }

    // метрики, миграция старого списка, чистка удалённых приложений
    LaunchedEffect(box.height > 0, rows0, rowsN, cols, apps) {
        if (box.height <= 0) return@LaunchedEffect
        HomeMetrics.rows0 = rows0
        HomeMetrics.rowsN = rowsN
        var list = parseHome(prefs.homeItems)
        if (!prefs.homeMigrated) {
            if (apps.isEmpty()) return@LaunchedEffect
            list = migrateLegacy(prefs.home.pkgs().filter { it in byPkg }, cols)
            prefs.homeMigrated = true
        }
        if (apps.isNotEmpty()) list = cleanFolders(list, byPkg)
        // Геометрию сюда не подмешиваем: сохраняем только настоящие изменения (миграция, удалённые приложения)
        val enc = list.compacted().encode()
        if (enc != prefs.homeItems) prefs.homeItems = enc
    }

    // у края экрана при переносе — листаем страницу
    val edgeDir by remember {
        derivedStateOf {
            val d = drag
            val edge = 36f * dens
            if (d == null) 0 else if (d.pos.x < edge) -1 else if (d.pos.x > box.width - edge) 1 else 0
        }
    }
    LaunchedEffect(edgeDir) {
        if (edgeDir != 0) {
            delay(500)
            while (true) {
                val t = pager.currentPage + edgeDir
                if (t < 0 || t >= totalNow) break
                pager.animateScrollToPage(t)
                delay(450)
            }
        }
    }

    // подсветка ячейки, куда упадёт иконка
    val tgt by remember(geoKey, diy) {
        derivedStateOf {
            val d = drag
            if (d == null || diy) null else targetOf(d, pager.currentPage)
        }
    }

    // иконку навели на другую иконку / папку — после короткой паузы вместо обмена местами получится папка
    val mergeCand by remember(geoKey, diy, items, byPkg) {
        derivedStateOf {
            val d = drag
            if (d == null || diy || d.item.isFolder || d.app == null) null
            else {
                val t = targetOf(d, pager.currentPage)
                val o = items.firstOrNull {
                    !it.free && it.page == t.first && it.pkg != d.item.pkg && it.covers(t.second, t.third) &&
                        it.appPkg != d.item.appPkg && (it.isFolder || it.appPkg in byPkg)
                }
                if (o == null) null
                else {
                    val dcx = (d.pos.x - d.grab.x) + cellW * dens / 2f
                    val dcy = (d.pos.y - d.grab.y) + cellH * dens / 2f
                    val r = itemRect(o)
                    val near = if (o.w == 1 && o.h == 1)
                        abs(dcx - r.center.x) < cellW * dens * 0.38f && abs(dcy - r.center.y) < cellH * dens * 0.38f
                    else r.contains(Offset(dcx, dcy))
                    if (near) o.pkg else null
                }
            }
        }
    }
    var mergeId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(mergeCand) {
        mergeId = null
        if (mergeCand != null) {
            delay(300)
            mergeId = mergeCand
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { box = it }
            .onGloballyPositioned { origin = it.positionInWindow(); a.pagerBounds = it.boundsInWindow() }
            .pointerInput(items, diy, geoKey) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    if (drag != null || menu != null || fmenu != null || pager.isScrollInProgress) return@awaitEachGesture
                    val hit = hitTest(down.position, pager.currentPage) ?: return@awaitEachGesture
                    val app = byPkg[hit.appPkg]
                    if (app == null && !hit.isFolder) return@awaitEachGesture
                    val rect = itemRect(hit)
                    val grab = down.position - rect.topLeft
                    val slop = viewConfiguration.touchSlop
                    // в DIY-режиме касания по иконкам не запускают приложения
                    if (diy) down.consume()

                    // 1) ждём: отпускание (тап) / сдвиг (свайп или DIY-перенос) / долгое нажатие
                    val first = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                        var res = 0
                        while (res == 0) {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            val c = ev.changes.firstOrNull { it.id == down.id }
                            res = if (c == null) 3
                            else if (c.isConsumed) 3
                            else if (!c.pressed) { if (diy) c.consume(); 1 }
                            else if ((c.position - down.position).getDistance() > slop) { if (diy) c.consume(); 2 }
                            else 0
                        }
                        res
                    }
                    when (first) {
                        1, 3 -> return@awaitEachGesture
                        2 -> if (!diy) return@awaitEachGesture   // обычный свайп: страницы листает pager
                        else -> haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    }

                    // 2) иконка «взята»: двигаем, пока палец на экране; без движения — меню
                    var dragging = false
                    var released = false
                    try {
                        if (first == 2) {
                            dragging = true
                            drag = DragState(hit, app, grab, down.position)
                        }
                        while (true) {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            val c = ev.changes.firstOrNull { it.id == down.id }
                            ev.changes.forEach { it.consume() }
                            if (c == null) break
                            if (!c.pressed) { released = true; break }
                            if (!dragging && (c.position - down.position).getDistance() > slop) {
                                dragging = true
                                drag = DragState(hit, app, grab, c.position)
                            }
                            if (dragging) drag?.pos = c.position
                        }
                        val d = drag
                        if (released && dragging && d != null) {
                            val pg = pager.currentPage
                            val list = if (diy) {
                                val fx = ((d.pos.x - d.grab.x) / dens).coerceIn(0f, maxOf(0f, wDp - cellW))
                                val fy = ((d.pos.y - d.grab.y) / dens).coerceIn(0f, maxOf(0f, hDp - cellH))
                                items.placedFree(d.item.pkg, pg, fx, fy)
                            } else if (mergeId != null && d.app != null) {
                                items.mergedInto(d.item.pkg, mergeId!!)
                            } else {
                                val t = targetOf(d, pg)
                                items.placedOnGrid(d.item.pkg, t.first, t.second, t.third, cols)
                            }
                            prefs.homeItems = list.compacted().encode()
                        } else if (released && !dragging && first == null) {
                            if (hit.isFolder) fmenu = hit to rect else if (app != null) { menuItem = hit; menu = app to rect }
                        }
                    } finally {
                        drag = null
                    }
                }
            }
    ) {
        HorizontalPager(
            state = pager,
            userScrollEnabled = drag == null,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            Box(Modifier.fillMaxSize()) {
                if (page == 0) {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        Spacer(Modifier.height(12.dp))
                        if (showClock) {
                            ClockBlobs()
                            Spacer(Modifier.height(14.dp))
                        }
                        if (showInfo) InfoChips()
                    }
                }
                items.forEach { item ->
                    val app = byPkg[item.appPkg]
                    if (item.page == page && (app != null || item.isFolder)) {
                        key(item.pkg) {
                            val r = itemRect(item)
                            Box(
                                Modifier
                                    .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                                    .size((cellW * item.w).dp, (cellH * item.h).dp)
                                    .then(
                                        if (diy) Modifier.border(1.5.dp, s.primary.copy(alpha = .55f), rc(20))
                                        else Modifier
                                    )
                            ) {
                                if (item.isFolder) {
                                    FolderView(
                                        folders.firstOrNull { it.id == item.folderId }, item, byPkg, labels, iconSize,
                                        hidden = drag?.item?.pkg == item.pkg, interactive = !diy,
                                        onOpen = { onOpenFolder(item.folderId) }
                                    )
                                } else if (app != null) {
                                    AppItem(
                                        app, labels, Color.White, emptyList(), Modifier.fillMaxWidth(), iconSize,
                                        managed = true, hidden = drag?.item?.pkg == item.pkg
                                    )
                                }
                            }
                        }
                    }
                }
                // виджеты живут на первой странице: каждый можно свободно двигать и тянуть
                if (page == 0) {
                    BoxWithConstraints(Modifier.fillMaxSize()) {
                        val mw = maxWidth.value
                        val mh = maxHeight.value
                        a.widgets.toList().forEach { id ->
                            val r = a.rects[id]
                            if (r != null && a.wm.getAppWidgetInfo(id) != null) key(id) { PlacedWidget(a, id, r, mw, mh) }
                        }
                    }
                }
            }
        }

        tgt?.let { t ->
            if (mergeId == null) {
                val sp = drag?.item
                val rr = cellRect(t.first, t.second, t.third, sp?.w ?: 1, sp?.h ?: 1)
                Box(
                    Modifier
                        .offset { IntOffset(rr.left.roundToInt(), rr.top.roundToInt()) }
                        .size(rr.width.div(dens).dp, rr.height.div(dens).dp)
                        .background(s.primary.copy(alpha = .2f), rc(22))
                )
            }
        }

        // «получится папка»: подсвечиваем иконку / папку, на которую навели
        mergeId?.let { id ->
            items.firstOrNull { it.pkg == id }?.let { o ->
                val r = itemRect(o)
                if (o.w > 1 || o.h > 1) {
                    Box(
                        Modifier
                            .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                            .size((cellW * o.w).dp, (cellH * o.h).dp)
                            .background(s.primary.copy(alpha = .28f), rc(28))
                    )
                } else {
                    val sz = iconSize + 18
                    Box(
                        Modifier
                            .offset {
                                IntOffset(
                                    (r.center.x - sz * dens / 2f).roundToInt(),
                                    (r.top + (6f + iconSize / 2f - sz / 2f) * dens).roundToInt()
                                )
                            }
                            .size(sz.dp)
                            .clip(shapeOf(prefs.iconShape))
                            .background(s.primary.copy(alpha = .32f))
                    )
                }
            }
        }

        // точки-индикатор страниц
        if (total > 1 && !diy) {
            Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)) {
                repeat(total) { i ->
                    val sel = i == pager.currentPage
                    val dotW by animateDpAsState(if (sel) 22.dp else 6.dp, label = "dotW")
                    Box(
                        Modifier.padding(3.dp).size(dotW, 6.dp).clip(CircleShape)
                            .background(if (sel) s.primary else Color.White.copy(alpha = .45f))
                    )
                }
            }
        }

        if (diy) {
            Text(
                "DIY · Готово", color = s.onPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)
                    .clip(CircleShape).background(s.primary)
                    .clickable { onDiyDone() }
                    .padding(horizontal = 22.dp, vertical = 10.dp)
            )
        }

        // иконка под пальцем
        drag?.let { d ->
            Box(
                Modifier
                    .offset { IntOffset((d.pos.x - d.grab.x).roundToInt(), (d.pos.y - d.grab.y).roundToInt()) }
                    .size((cellW * d.item.w).dp, (cellH * d.item.h).dp)
                    .graphicsLayer { scaleX = 1.1f; scaleY = 1.1f }
            ) {
                if (d.item.isFolder) {
                    FolderView(
                        folders.firstOrNull { it.id == d.item.folderId }, d.item, byPkg, labels, iconSize,
                        hidden = false, interactive = false, onOpen = {}
                    )
                } else if (d.app != null) {
                    Column(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        AppIcon(d.app, iconSize.dp)
                        if (labels) {
                            Text(
                                d.app.label, color = Color.White, fontSize = 12.sp, maxLines = 1,
                                fontWeight = FontWeight.Bold, overflow = TextOverflow.Ellipsis,
                                style = TextStyle(shadow = Shadow(Color.Black.copy(.35f), blurRadius = 6f)),
                                modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        fmenu?.let { (fi, r) ->
            FloatingMenu(
                (origin.x + r.center.x).roundToInt(),
                (origin.y + r.top).roundToInt(),
                (origin.y + r.bottom).roundToInt(),
                { fmenu = null }
            ) {
                FolderMenuContent(
                    fi,
                    { w, h -> prefs.homeItems = items.resized(fi.pkg, w, h, cols).compacted().encode() },
                    { prefs.homeItems = items.dissolved(fi, cols).compacted().encode() },
                    { fmenu = null }
                )
            }
        }

        menu?.let { (app, r) ->
            FloatingMenu(
                (origin.x + r.center.x).roundToInt(),
                (origin.y + r.top).roundToInt(),
                (origin.y + r.bottom).roundToInt(),
                { menu = null }
            ) {
                val mi = menuItem
                // «Убрать с экрана» здесь убирает именно эту копию
                val acts = if (mi == null) menuFor(app) else menuFor(app).filter { it.label != REMOVE_HOME } +
                    MenuAction(Icons.Filled.Close, REMOVE_HOME, danger = true) {
                        prefs.homeItems = items.filter { it.pkg != mi.pkg }.compacted().encode()
                    }
                AppMenuContent(app, acts) { menu = null }
            }
        }
    }
}
