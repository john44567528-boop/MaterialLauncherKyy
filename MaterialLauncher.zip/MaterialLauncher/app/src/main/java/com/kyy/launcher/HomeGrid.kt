package com.kyy.launcher

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInParent
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.floor
import kotlin.math.roundToInt

// ───────────────────────── модель ─────────────────────────

/**
 * Иконка на главном экране.
 * Обычная: лежит в ячейке сетки (page, col, row), fx/fy = -1.
 * DIY: стоит где угодно, fx/fy — положение левого верхнего угла (до поворота и масштаба) в dp внутри страницы;
 * rot и sz поворачивают и масштабируют иконку вокруг её центра.
 */
data class HomeItem(
    val pkg: String,
    val page: Int,
    val col: Int,
    val row: Int,
    val fx: Float = -1f,
    val fy: Float = -1f,
    val w: Int = 1,   // размер в ячейках (больше 1 только у папок)
    val h: Int = 1,
    val rot: Float = 0f,   // DIY: поворот, градусы (по часовой)
    val sz: Float = 1f     // DIY: масштаб (1 = обычный размер)
) {
    val free: Boolean get() = fx >= 0f && fy >= 0f
    val isFolder: Boolean get() = pkg.startsWith("folder:")
    val folderId: String get() = pkg.removePrefix("folder:")
    /** Пакет приложения: id копии вида "pkg#2" → "pkg" (одно приложение можно положить на экран много раз). */
    val appPkg: String get() = if (isFolder) pkg else pkg.substringBefore('#')
    fun covers(c: Int, r: Int) = c >= col && c < col + w && r >= row && r < row + h
    fun overlaps(o: HomeItem) = col < o.col + o.w && o.col < col + w && row < o.row + o.h && o.row < row + h
}

/** Сколько рядов помещается на странице (обновляет HomePage после измерения экрана). */
object HomeMetrics {
    var rows0 by mutableIntStateOf(5)   // первая страница
    var rowsN by mutableIntStateOf(7)   // остальные страницы
    fun rowsFor(page: Int) = if (page == 0) rows0 else rowsN
    /** Страницы виджетов (id -> страница): нужны, чтобы пустые страницы убирались, а страницы только с виджетами оставались. */
    var widgetPages: androidx.compose.runtime.snapshots.SnapshotStateMap<Int, Int>? = null
    var onWidgetPagesChanged: (() -> Unit)? = null
}

fun parseHome(s: String): List<HomeItem> = s.split(";").mapNotNull { e ->
    val p = e.split(",")
    if (p.size != 6 && p.size != 8 && p.size != 10) return@mapNotNull null
    val page = p[1].toIntOrNull() ?: return@mapNotNull null
    val col = p[2].toIntOrNull() ?: return@mapNotNull null
    val row = p[3].toIntOrNull() ?: return@mapNotNull null
    val fx = p[4].toIntOrNull() ?: -1
    val fy = p[5].toIntOrNull() ?: -1
    val w = (p.getOrNull(6)?.toIntOrNull() ?: 1).coerceIn(1, 2)
    val h = (p.getOrNull(7)?.toIntOrNull() ?: 1).coerceIn(1, 2)
    val rot = (p.getOrNull(8)?.toIntOrNull() ?: 0).toFloat()
    val sz = ((p.getOrNull(9)?.toIntOrNull() ?: 100) / 100f).coerceIn(MIN_SZ, MAX_SZ)
    if (p[0].isEmpty()) null else HomeItem(p[0], page, col, row, fx.toFloat(), fy.toFloat(), w, h, rot, sz)
}

fun List<HomeItem>.encode(): String = joinToString(";") {
    val x = if (it.free) it.fx.roundToInt() else -1
    val y = if (it.free) it.fy.roundToInt() else -1
    val r = if (it.free) it.rot.roundToInt() else 0
    val z = if (it.free) (it.sz * 100f).roundToInt() else 100
    "${it.pkg},${it.page},${it.col},${it.row},$x,$y,${it.w},${it.h},$r,$z"
}

const val MIN_SZ = 0.4f
const val MAX_SZ = 4f

private fun List<HomeItem>.occupant(page: Int, col: Int, row: Int, except: String?): HomeItem? =
    firstOrNull { !it.free && it.page == page && it.covers(col, row) && it.pkg != except }

/** Первая свободная ячейка (страница, колонка, ряд); если всё занято — новая страница. */
fun List<HomeItem>.firstFree(
    cols: Int, except: String? = null, w: Int = 1, h: Int = 1,
    rowsFor: (Int) -> Int = { HomeMetrics.rowsFor(it) }
): Triple<Int, Int, Int> {
    val last = (maxOfOrNull { it.page } ?: 0) + 1
    for (p in 0..last) {
        for (r in 0..(rowsFor(p) - h)) {
            for (c in 0..(cols - w)) {
                var ok = true
                for (dr in 0 until h) for (dc in 0 until w) if (occupant(p, c + dc, r + dr, except) != null) ok = false
                if (ok) return Triple(p, c, r)
            }
        }
    }
    return Triple(last + 1, 0, 0)
}

/** Свободный id для новой копии приложения: pkg, pkg#2, pkg#3… */
fun List<HomeItem>.freshId(pkg: String): String {
    if (none { it.pkg == pkg }) return pkg
    var n = 2
    while (any { it.pkg == "$pkg#$n" }) n++
    return "$pkg#$n"
}

/** Добавить приложение на экран; если оно уже там есть — появится ещё одна копия. */
fun List<HomeItem>.withAdded(pkg: String, cols: Int): List<HomeItem> {
    val t = firstFree(cols)
    return this + HomeItem(freshId(pkg), t.first, t.second, t.third)
}

const val REMOVE_HOME = "Убрать с экрана"

/** Положить иконку (или папку любого размера) в ячейку. Кого она накрыла — тот меняется с ней местами (1×1) или уходит в свободное место. */
fun List<HomeItem>.placedOnGrid(pkg: String, page: Int, col: Int, row: Int, cols: Int): List<HomeItem> {
    val me = firstOrNull { it.pkg == pkg } ?: return this
    val rows = HomeMetrics.rowsFor(page)
    val placed = me.copy(
        page = page, fx = -1f, fy = -1f, rot = 0f, sz = 1f,
        col = col.coerceIn(0, (cols - me.w).coerceAtLeast(0)),
        row = row.coerceIn(0, (rows - me.h).coerceAtLeast(0))
    )
    val others = filter { it.pkg != pkg }
    val hit = others.filter { !it.free && it.page == page && it.overlaps(placed) }
    var res = others.filter { o -> hit.none { it.pkg == o.pkg } } + placed
    if (hit.size == 1 && hit[0].w == 1 && hit[0].h == 1 && me.w == 1 && me.h == 1 && !me.free) {
        res = res + hit[0].copy(page = me.page, col = me.col, row = me.row, fx = -1f, fy = -1f)
    } else {
        for (o in hit) {
            val t = res.firstFree(cols, null, o.w, o.h)
            res = res + o.copy(page = t.first, col = t.second, row = t.third, fx = -1f, fy = -1f)
        }
    }
    return res
}

/** Изменить размер папки. Что мешает — переезжает в свободные ячейки. */
fun List<HomeItem>.resized(pkg: String, w: Int, h: Int, cols: Int): List<HomeItem> {
    val me = firstOrNull { it.pkg == pkg } ?: return this
    if (me.free) return map { if (it.pkg == pkg) it.copy(w = w, h = h) else it }
    val rows = HomeMetrics.rowsFor(me.page)
    val w2 = w.coerceAtMost(cols)
    val h2 = h.coerceAtMost(rows)
    val moved = me.copy(
        w = w2, h = h2,
        col = me.col.coerceAtMost(cols - w2).coerceAtLeast(0),
        row = me.row.coerceAtMost(rows - h2).coerceAtLeast(0)
    )
    val others = filter { it.pkg != pkg }
    val hit = others.filter { !it.free && it.page == me.page && it.overlaps(moved) }
    var res = others.filter { o -> hit.none { it.pkg == o.pkg } } + moved
    for (o in hit) {
        val t = res.firstFree(cols, null, o.w, o.h)
        res = res + o.copy(page = t.first, col = t.second, row = t.third)
    }
    return res
}

/** DIY: поставить иконку в произвольную точку страницы. */
fun List<HomeItem>.placedFree(pkg: String, page: Int, fx: Float, fy: Float): List<HomeItem> =
    map { if (it.pkg == pkg) it.copy(page = page, fx = fx, fy = fy) else it }

/** DIY: повернуть и/или изменить размер иконки. */
fun List<HomeItem>.withXform(pkg: String, rot: Float, sz: Float): List<HomeItem> =
    map { if (it.pkg == pkg && it.free) it.copy(rot = rot, sz = sz.coerceIn(MIN_SZ, MAX_SZ)) else it }

/** Временное значение поворота/масштаба, пока палец тянет ручку (в настройки пишется при отпускании). */
private data class LiveXf(val pkg: String, val rot: Float, val sz: Float)

/** Убрать пустые страницы (первая остаётся всегда). */
fun List<HomeItem>.compacted(): List<HomeItem> {
    val wp = HomeMetrics.widgetPages
    if (isEmpty() && wp.isNullOrEmpty()) return this
    // страница не пустая, если на ней есть иконка или виджет
    val used = (map { it.page } + (wp?.values?.toList() ?: emptyList())).toSortedSet()
    val order = (listOf(0) + used.filter { it != 0 })
    val remap = order.withIndex().associate { (i, p) -> p to i }
    if (wp != null) {
        var changed = false
        wp.entries.toList().forEach { (id, pg) ->
            val n = remap[pg] ?: 0
            if (n != pg) { wp[id] = n; changed = true }
        }
        if (changed) HomeMetrics.onWidgetPagesChanged?.invoke()
    }
    return map { it.copy(page = remap[it.page] ?: 0) }
}

/**
 * Иконки, которые не влезают в сетку (поменяли колонки / размер / повернули экран) — раскладываем по свободным ячейкам.
 * Только для ПОКАЗА: результат нельзя сохранять в настройки, иначе при повороте экрана или смене высоты панелей
 * иконки навсегда съезжают со своих мест. Сохранённые позиции остаются как есть и снова встают на место,
 * когда экран вернулся к прежнему размеру.
 */
fun List<HomeItem>.normalized(cols: Int, rowsFor: (Int) -> Int = { HomeMetrics.rowsFor(it) }): List<HomeItem> {
    var res = this
    for (item in this) {
        val w = item.w.coerceAtMost(cols)
        val h = item.h.coerceAtMost(rowsFor(item.page))
        if (!item.free && (item.col + w > cols || item.row + h > rowsFor(item.page))) {
            val rest = res.filter { it.pkg != item.pkg }
            val t = rest.firstFree(cols, null, w, h, rowsFor)
            res = rest + item.copy(page = t.first, col = t.second, row = t.third, w = w, h = h)
        }
    }
    return res
}

fun homeAdd(pkg: String) {
    prefs.homeItems = parseHome(prefs.homeItems).withAdded(pkg, prefs.homeCols).compacted().encode()
}

fun homeRemove(pkg: String) {
    prefs.homeItems = parseHome(prefs.homeItems).filter { it.appPkg != pkg }.withoutMember(pkg).compacted().encode()
}

/** Старый список «pkg|pkg|…» → сетка; как и раньше, иконки прижаты к низу первой страницы. */
fun migrateLegacy(pkgs: List<String>, cols: Int): List<HomeItem> {
    val rows0 = HomeMetrics.rows0
    val rowsN = HomeMetrics.rowsN
    val need = (pkgs.size + cols - 1) / cols
    val startFlat = (rows0 - need).coerceAtLeast(0) * cols
    return pkgs.mapIndexed { i, pkg ->
        val flat = startFlat + i
        val cap0 = rows0 * cols
        if (flat < cap0) HomeItem(pkg, 0, flat % cols, flat / cols)
        else {
            val rest = flat - cap0
            val capN = rowsN * cols
            val inPage = rest % capN
            HomeItem(pkg, 1 + rest / capN, inPage % cols, inPage / cols)
        }
    }
}

class DragState(val item: HomeItem, val app: AppInfo?, val grab: Offset, start: Offset) {
    var pos by mutableStateOf(start)
}

// ───────────────────────── экран ─────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomePage(
    a: MainActivity,
    apps: List<AppInfo>,
    menuFor: (AppInfo) -> List<MenuAction>,
    diy: Boolean,
    onOpenFolder: (String) -> Unit,
    onDiyDone: () -> Unit
) {
    val s = MaterialTheme.colorScheme
    val dens = LocalDensity.current.density
    val haptic = LocalHapticFeedback.current
    val appCtx = LocalContext.current
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val cols = prefs.homeCols
    val labels = prefs.showLabels
    val iconSize = prefs.iconSize
    val stored = remember(prefs.homeItems) { parseHome(prefs.homeItems) }

    var box by remember { mutableStateOf(IntSize.Zero) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    var drag by remember { mutableStateOf<DragState?>(null) }
    var menu by remember { mutableStateOf<Pair<AppInfo, Rect>?>(null) }
    var menuItem by remember { mutableStateOf<HomeItem?>(null) }
    var fmenu by remember { mutableStateOf<Pair<HomeItem, Rect>?>(null) }
    val folders = remember(prefs.folders) { parseFolders(prefs.folders) }
    // DIY: выбранная иконка (у неё есть ручки поворота и размера), временные значения на время жеста, кнопка «Готово»
    var selected by remember { mutableStateOf<String?>(null) }
    var live by remember { mutableStateOf<LiveXf?>(null) }
    var doneRect by remember { mutableStateOf(Rect.Zero) }
    LaunchedEffect(diy) { if (!diy) { selected = null; live = null } }

    // ── геометрия (dp) ──
    val padH = 16f
    val userRows = prefs.homeRows
    val wDp = box.width / dens
    val hDp = box.height / dens
    val cellW = ((wDp - 2 * padH) / cols).coerceAtLeast(1f)
    val top0 = 12f
    val bottomPad = 12f
    // «Авто»: высота ячейки по размеру иконки. Заданное число рядов: ячейки подгоняются, чтобы ряды заняли всю свободную высоту
    val cellH = if (userRows > 0) ((hDp - top0 - bottomPad) / userRows).coerceAtLeast(44f)
                else iconSize + 16f + (if (labels) 22f else 0f)
    val rows0 = floor((hDp - top0 - bottomPad) / cellH + 0.02f).toInt().coerceAtLeast(1)
    val rowsN = floor((hDp - 12f - bottomPad) / cellH + 0.02f).toInt().coerceAtLeast(1)
    val geoKey = listOf<Any>(box, cols, labels, iconSize, userRows)
    // То, что видно на экране: сохранённая раскладка, подогнанная под текущий размер. В настройки это не пишется.
    val items = remember(stored, box, cols, rows0, rowsN) {
        if (box.height <= 0) stored
        else stored.normalized(cols) { if (it == 0) rows0 else rowsN }
    }

    fun topOf(page: Int) = if (page == 0) top0 else 12f
    fun rowsOf(page: Int) = if (page == 0) rows0 else rowsN
    fun cellRect(page: Int, col: Int, row: Int, w: Int = 1, h: Int = 1): Rect {
        val l = (padH + col * cellW) * dens
        val t = (topOf(page) + row * cellH) * dens
        return Rect(l, t, l + cellW * w * dens, t + cellH * h * dens)
    }
    // Свободная иконка (DIY) занимает ровно столько места, сколько нужно ей самой (иконка + подпись), а не целую ячейку сетки
    fun freeBase(i: HomeItem): Pair<Float, Float> =
        if (i.isFolder || i.w > 1 || i.h > 1) (cellW * i.w) to (cellH * i.h)
        else (iconSize + 20f).coerceAtLeast(76f) to (iconSize + 12f + (if (labels) 22f else 0f))
    fun baseDp(i: HomeItem): Pair<Float, Float> = if (i.free) freeBase(i) else (cellW * i.w) to (cellH * i.h)
    fun eff(i: HomeItem): HomeItem {
        val l = live
        return if (l != null && l.pkg == i.pkg && i.free) i.copy(rot = l.rot, sz = l.sz) else i
    }
    /** Прямоугольник иконки без учёта поворота и масштаба (они считаются вокруг его центра). */
    fun itemRect(i: HomeItem): Rect {
        if (!i.free) return cellRect(i.page, i.col, i.row, i.w, i.h)
        val (bw, bh) = freeBase(i)
        val cx = (i.fx + bw / 2f).coerceIn(0f, wDp)
        val cy = (i.fy + bh / 2f).coerceIn(0f, hDp)
        return Rect((cx - bw / 2f) * dens, (cy - bh / 2f) * dens, (cx + bw / 2f) * dens, (cy + bh / 2f) * dens)
    }
    fun hitsItem(i: HomeItem, p: Offset): Boolean {
        val r = itemRect(i)
        if (!i.free || (i.rot == 0f && i.sz == 1f)) return r.contains(p)
        val th = Math.toRadians(i.rot.toDouble()).toFloat()
        val dx = p.x - r.center.x
        val dy = p.y - r.center.y
        val lx = (dx * cos(th) + dy * sin(th)) / i.sz
        val ly = (-dx * sin(th) + dy * cos(th)) / i.sz
        return abs(lx) <= r.width / 2f && abs(ly) <= r.height / 2f
    }
    fun rotHandle(i: HomeItem): Offset {
        val r = itemRect(i)
        val th = Math.toRadians(i.rot.toDouble()).toFloat()
        val ly = -(r.height / 2f * i.sz + 32f * dens)
        return Offset(r.center.x - ly * sin(th), r.center.y + ly * cos(th))
    }
    fun sclHandle(i: HomeItem): Offset {
        val r = itemRect(i)
        val th = Math.toRadians(i.rot.toDouble()).toFloat()
        val lx = r.width / 2f * i.sz
        val ly = r.height / 2f * i.sz
        return Offset(r.center.x + lx * cos(th) - ly * sin(th), r.center.y + lx * sin(th) + ly * cos(th))
    }
    fun selectedFree(page: Int): HomeItem? =
        items.firstOrNull { it.pkg == selected && it.page == page && it.free }?.let { eff(it) }
    /** Тап по иконке в DIY: выбрать её; если она стояла в сетке — отпустить на то же место, чтобы можно было крутить и менять размер. */
    fun selectForDiy(item: HomeItem, rect: Rect) {
        selected = item.pkg
        if (!item.free) {
            val (bw, _) = freeBase(item)
            val fx = rect.left / dens + (rect.width / dens - bw) / 2f
            val fy = rect.top / dens
            prefs.homeItems = items.placedFree(item.pkg, item.page, fx, fy).compacted().encode()
        }
    }
    fun targetOf(d: DragState, page: Int): Triple<Int, Int, Int> {
        val cx = (d.pos.x - d.grab.x) / dens + cellW / 2f
        val cy = (d.pos.y - d.grab.y) / dens + cellH / 2f
        val c = floor((cx - padH) / cellW).toInt().coerceIn(0, (cols - d.item.w).coerceAtLeast(0))
        val r = floor((cy - topOf(page)) / cellH).toInt().coerceIn(0, (rowsOf(page) - d.item.h).coerceAtLeast(0))
        return Triple(page, c, r)
    }
    fun hitTest(p: Offset, page: Int): HomeItem? {
        for (id in a.widgets.toList()) {
            if ((a.widgetPage[id] ?: 0) != page) continue
            val r = a.rects[id] ?: continue
            if (p.x >= r.x * dens && p.x <= (r.x + r.w) * dens && p.y >= r.y * dens && p.y <= (r.y + r.h) * dens) return null
        }
        if (diy) selectedFree(page)?.let { if (hitsItem(it, p)) return items.firstOrNull { o -> o.pkg == it.pkg } }
        return items.lastOrNull { it.page == page && (it.isFolder || it.appPkg in byPkg) && hitsItem(eff(it), p) }
    }

    // ── страницы ──
    val widgetMaxPage = a.widgetPage.values.maxOrNull() ?: 0
    val pageCount = maxOf(items.maxOfOrNull { it.page } ?: 0, widgetMaxPage) + 1
    val total = if (drag != null) pageCount + 1 else pageCount   // во время переноса справа можно создать новую страницу
    val totalNow by rememberUpdatedState(total)
    val pager = rememberPagerState { totalNow }
    LaunchedEffect(pager) { snapshotFlow { pager.currentPage }.collect { a.homePage.intValue = it } }
    LaunchedEffect(pager) { snapshotFlow { pager.isScrollInProgress }.collect { a.pageScrolling.value = it } }
    // виджет перенесли на другую страницу — листаем за ним
    val editId = a.editWidget.intValue
    val editPg = if (editId != -1) a.widgetPage[editId] else null
    LaunchedEffect(editId, editPg) {
        if (editPg != null && editPg != pager.currentPage) pager.animateScrollToPage(editPg.coerceIn(0, (totalNow - 1).coerceAtLeast(0)))
    }

    // метрики, миграция старого списка, чистка удалённых приложений
    LaunchedEffect(box.height > 0, rows0, rowsN, cols, apps) {
        if (box.height <= 0) return@LaunchedEffect
        HomeMetrics.rows0 = rows0
        HomeMetrics.rowsN = rowsN
        var list = parseHome(prefs.homeItems)
        if (!prefs.homeMigrated) {
            if (apps.isEmpty()) return@LaunchedEffect
            list = migrateLegacy(prefs.home.pkgs().filter { it in byPkg }, cols)
            prefs.homeMigrated = true
        }
        if (apps.isNotEmpty()) list = cleanFolders(list, byPkg)
        // Геометрию сюда не подмешиваем: сохраняем только настоящие изменения (миграция, удалённые приложения)
        val enc = list.compacted().encode()
        if (enc != prefs.homeItems) prefs.homeItems = enc
    }

    // у края экрана при переносе — листаем страницу
    val edgeDir by remember {
        derivedStateOf {
            val d = drag
            val edge = 36f * dens
            if (d == null) 0 else if (d.pos.x < edge) -1 else if (d.pos.x > box.width - edge) 1 else 0
        }
    }
    LaunchedEffect(edgeDir) {
        if (edgeDir != 0) {
            delay(500)
            while (true) {
                val t = pager.currentPage + edgeDir
                if (t < 0 || t >= totalNow) break
                pager.animateScrollToPage(t)
                delay(450)
            }
        }
    }

    // подсветка ячейки, куда упадёт иконка
    val tgt by remember(geoKey, diy) {
        derivedStateOf {
            val d = drag
            if (d == null || diy) null else targetOf(d, pager.currentPage)
        }
    }

    // иконку навели на другую иконку / папку — после короткой паузы вместо обмена местами получится папка
    val mergeCand by remember(geoKey, diy, items, byPkg) {
        derivedStateOf {
            val d = drag
            if (d == null || diy || d.item.isFolder || d.app == null || d.item.w > 1 || d.item.h > 1) null
            else {
                val t = targetOf(d, pager.currentPage)
                val o = items.firstOrNull {
                    !it.free && it.page == t.first && it.pkg != d.item.pkg && it.covers(t.second, t.third) &&
                        it.appPkg != d.item.appPkg && (it.isFolder || it.appPkg in byPkg) && (it.isFolder || (it.w == 1 && it.h == 1))
                }
                if (o == null) null
                else {
                    val dcx = (d.pos.x - d.grab.x) + cellW * dens / 2f
                    val dcy = (d.pos.y - d.grab.y) + cellH * dens / 2f
                    val r = itemRect(o)
                    val near = if (o.w == 1 && o.h == 1)
                        abs(dcx - r.center.x) < cellW * dens * 0.38f && abs(dcy - r.center.y) < cellH * dens * 0.38f
                    else r.contains(Offset(dcx, dcy))
                    if (near) o.pkg else null
                }
            }
        }
    }
    var mergeId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(mergeCand) {
        mergeId = null
        if (mergeCand != null) {
            delay(300)
            mergeId = mergeCand
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { box = it }
            .onGloballyPositioned { origin = it.positionInWindow(); a.pagerBounds = it.boundsInWindow() }
            .pointerInput(items, diy, geoKey) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    if (drag != null || menu != null || fmenu != null || pager.isScrollInProgress) return@awaitEachGesture
                    if (diy) {
                        // кнопка «Готово» важнее любых иконок под ней
                        if (doneRect.inflate(10f * dens).contains(down.position)) return@awaitEachGesture
                        // ручки выбранной иконки: поворот и размер
                        val sel = selectedFree(pager.currentPage)
                        if (sel != null) {
                            val grabR = 28f * dens
                            val onRot = (down.position - rotHandle(sel)).getDistance() < grabR
                            val onScl = !onRot && (down.position - sclHandle(sel)).getDistance() < grabR
                            if (onRot || onScl) {
                                down.consume()
                                val r = itemRect(sel)
                                val c = r.center
                                val half = hypot(r.width / 2f, r.height / 2f)
                                try {
                                    while (true) {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                        ev.changes.forEach { it.consume() }
                                        if (!ch.pressed) break
                                        val v = ch.position - c
                                        val l = live ?: LiveXf(sel.pkg, sel.rot, sel.sz)
                                        live = if (onRot) {
                                            var deg = Math.toDegrees(atan2(v.y, v.x).toDouble()).toFloat() + 90f
                                            deg = ((deg + 180f) % 360f + 360f) % 360f - 180f
                                            val snap = Math.round(deg / 45f) * 45f
                                            if (abs(deg - snap) < 4f) deg = snap   // «прилипание» к 0°, 45°, 90°…
                                            l.copy(rot = deg)
                                        } else l.copy(sz = (v.getDistance() / half).coerceIn(MIN_SZ, MAX_SZ))
                                    }
                                    live?.let { prefs.homeItems = items.withXform(it.pkg, it.rot, it.sz).compacted().encode() }
                                } finally { live = null }
                                return@awaitEachGesture
                            }
                        }
                    }
                    val hit = hitTest(down.position, pager.currentPage) ?: run {
                        if (diy) selected = null
                        return@awaitEachGesture
                    }
                    val app = byPkg[hit.appPkg]
                    if (app == null && !hit.isFolder) return@awaitEachGesture
                    val rect = itemRect(hit)
                    val grab = down.position - rect.topLeft
                    val slop = viewConfiguration.touchSlop
                    // в DIY-режиме касания по иконкам не запускают приложения
                    if (diy) down.consume()

                    // 1) ждём: отпускание (тап) / сдвиг (свайп или DIY-перенос) / долгое нажатие
                    val first = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                        var res = 0
                        while (res == 0) {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            val c = ev.changes.firstOrNull { it.id == down.id }
                            res = if (c == null) 3
                            else if (c.isConsumed) 3
                            else if (!c.pressed) { if (diy) c.consume(); 1 }
                            else if ((c.position - down.position).getDistance() > slop) { if (diy) c.consume(); 2 }
                            else 0
                        }
                        res
                    }
                    when (first) {
                        1 -> { if (diy) selectForDiy(hit, rect); return@awaitEachGesture }
                        3 -> return@awaitEachGesture
                        2 -> if (!diy) return@awaitEachGesture   // обычный свайп: страницы листает pager
                        else -> { haptic.performHapticFeedback(HapticFeedbackType.LongPress); app?.let { prefetchShortcuts(appCtx, it.pkg) } }
                    }
                    if (diy) selected = hit.pkg

                    // 2) иконка «взята»: двигаем, пока палец на экране; без движения — меню
                    var dragging = false
                    var released = false
                    try {
                        if (first == 2) {
                            dragging = true
                            drag = DragState(hit, app, grab, down.position)
                        }
                        while (true) {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            val c = ev.changes.firstOrNull { it.id == down.id }
                            ev.changes.forEach { it.consume() }
                            if (c == null) break
                            if (!c.pressed) { released = true; break }
                            if (!dragging && (c.position - down.position).getDistance() > slop) {
                                dragging = true
                                drag = DragState(hit, app, grab, c.position)
                            }
                            if (dragging) drag?.pos = c.position
                        }
                        val d = drag
                        if (released && dragging && d != null) {
                            val pg = pager.currentPage
                            val list = if (diy) {
                                // иконка из сетки при отпускании сжимается до своего размера: центр остаётся под пальцем
                                val (bw, bh) = freeBase(d.item)
                                val dragW = baseDp(d.item).first
                                val fx = ((d.pos.x - d.grab.x) / dens + (dragW - bw) / 2f).let { (it + bw / 2f).coerceIn(0f, wDp) - bw / 2f }
                                val fy = ((d.pos.y - d.grab.y) / dens).let { (it + bh / 2f).coerceIn(0f, hDp) - bh / 2f }
                                items.placedFree(d.item.pkg, pg, fx, fy)
                            } else if (mergeId != null && d.app != null) {
                                items.mergedInto(d.item.pkg, mergeId!!)
                            } else {
                                val t = targetOf(d, pg)
                                items.placedOnGrid(d.item.pkg, t.first, t.second, t.third, cols)
                            }
                            prefs.homeItems = list.compacted().encode()
                        } else if (released && !dragging && first == null) {
                            if (hit.isFolder) fmenu = hit to rect else if (app != null) { menuItem = hit; menu = app to rect }
                        }
                    } finally {
                        drag = null
                    }
                }
            }
    ) {
        HorizontalPager(
            state = pager,
            userScrollEnabled = drag == null,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            Box(Modifier.fillMaxSize()) {
                items.forEach { item ->
                    val app = byPkg[item.appPkg]
                    if (item.page == page && (app != null || item.isFolder)) {
                        key(item.pkg) {
                            val e = eff(item)
                            val r = itemRect(e)
                            val (bw, bh) = baseDp(e)
                            Box(
                                Modifier
                                    .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                                    .size(bw.dp, bh.dp)
                                    .graphicsLayer {
                                        if (e.free) { rotationZ = e.rot; scaleX = e.sz; scaleY = e.sz }
                                    }
                                    .then(
                                        if (diy && e.pkg != selected) Modifier.border(1.5.dp, s.primary.copy(alpha = .55f), rc(20))
                                        else Modifier
                                    )
                            ) {
                                if (item.isFolder) {
                                    FolderView(
                                        folders.firstOrNull { it.id == item.folderId }, item, byPkg, labels, iconSize,
                                        hidden = drag?.item?.pkg == item.pkg, interactive = !diy,
                                        onOpen = { onOpenFolder(item.folderId) }
                                    )
                                } else if (app != null && (item.w > 1 || item.h > 1)) {
                                    // растянутая иконка: плитка в выбранной форме иконок
                                    AppTileItem(app, labels, iconSize, hidden = drag?.item?.pkg == item.pkg, interactive = !diy)
                                } else if (app != null) {
                                    AppItem(
                                        app, labels, Color.White, emptyList(), Modifier.fillMaxWidth(), iconSize,
                                        managed = true, hidden = drag?.item?.pkg == item.pkg
                                    )
                                }
                            }
                        }
                    }
                }
                // виджеты стоят каждый на своей странице: их можно свободно двигать, тянуть и переносить между страницами
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val mw = maxWidth.value
                    val mh = maxHeight.value
                    a.widgets.toList().forEach { id ->
                        val r = a.rects[id]
                        if ((a.widgetPage[id] ?: 0) == page && r != null && a.wm.getAppWidgetInfo(id) != null)
                            key(id) { PlacedWidget(a, id, r, mw, mh) }
                    }
                }
            }
        }

        tgt?.let { t ->
            if (mergeId == null) {
                val sp = drag?.item
                val rr = cellRect(t.first, t.second, t.third, sp?.w ?: 1, sp?.h ?: 1)
                Box(
                    Modifier
                        .offset { IntOffset(rr.left.roundToInt(), rr.top.roundToInt()) }
                        .size(rr.width.div(dens).dp, rr.height.div(dens).dp)
                        .background(s.primary.copy(alpha = .2f), rc(22))
                )
            }
        }

        // «получится папка»: подсвечиваем иконку / папку, на которую навели
        mergeId?.let { id ->
            items.firstOrNull { it.pkg == id }?.let { o ->
                val r = itemRect(o)
                if (o.w > 1 || o.h > 1) {
                    Box(
                        Modifier
                            .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                            .size((cellW * o.w).dp, (cellH * o.h).dp)
                            .background(s.primary.copy(alpha = .28f), rc(28))
                    )
                } else {
                    val sz = iconSize + 18
                    Box(
                        Modifier
                            .offset {
                                IntOffset(
                                    (r.center.x - sz * dens / 2f).roundToInt(),
                                    (r.top + (6f + iconSize / 2f - sz / 2f) * dens).roundToInt()
                                )
                            }
                            .size(sz.dp)
                            .clip(shapeOf(prefs.iconShape))
                            .background(s.primary.copy(alpha = .32f))
                    )
                }
            }
        }

        // DIY: рамка и ручки выбранной иконки (↻ — повернуть, угол — размер)
        if (diy && drag == null && !pager.isScrollInProgress) {
            selectedFree(pager.currentPage)?.let { sel ->
                val r = itemRect(sel)
                val (bw, bh) = baseDp(sel)
                Box(
                    Modifier
                        .offset { IntOffset(r.left.roundToInt(), r.top.roundToInt()) }
                        .size(bw.dp, bh.dp)
                        .graphicsLayer { rotationZ = sel.rot; scaleX = sel.sz; scaleY = sel.sz }
                        .border((2f / sel.sz).dp, s.primary, rc(20))
                )
                DiyHandle(rotHandle(sel), dens) {
                    Icon(Icons.Filled.Refresh, null, tint = s.onPrimary, modifier = Modifier.size(18.dp))
                }
                DiyHandle(sclHandle(sel), dens) {
                    val col = s.onPrimary
                    Canvas(Modifier.size(14.dp)) {
                        val w = 2.dp.toPx()
                        drawLine(col, Offset(w, w), Offset(size.width - w, size.height - w), w, StrokeCap.Round)
                        drawLine(col, Offset(size.width - w, size.height * .35f), Offset(size.width - w, size.height - w), w, StrokeCap.Round)
                        drawLine(col, Offset(size.width * .35f, size.height - w), Offset(size.width - w, size.height - w), w, StrokeCap.Round)
                    }
                }
            }
        }

        // точки-индикатор страниц
        if (total > 1 && !diy) {
            Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)) {
                repeat(total) { i ->
                    val sel = i == pager.currentPage
                    val dotW by animateDpAsState(if (sel) 22.dp else 6.dp, label = "dotW")
                    Box(
                        Modifier.padding(3.dp).size(dotW, 6.dp).clip(CircleShape)
                            .background(if (sel) s.primary else Color.White.copy(alpha = .45f))
                    )
                }
            }
        }

        if (diy) {
            Text(
                "DIY · Готово", color = s.onPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)
                    .onGloballyPositioned { doneRect = it.boundsInParent() }
                    .clip(CircleShape).background(s.primary)
                    .clickable { onDiyDone() }
                    .padding(horizontal = 22.dp, vertical = 10.dp)
            )
        }

        // иконка под пальцем
        drag?.let { d ->
            val (dw, dh) = baseDp(d.item)
            Box(
                Modifier
                    .offset { IntOffset((d.pos.x - d.grab.x).roundToInt(), (d.pos.y - d.grab.y).roundToInt()) }
                    .size(dw.dp, dh.dp)
                    .graphicsLayer {
                        val k = if (d.item.free) d.item.sz else 1f
                        rotationZ = if (d.item.free) d.item.rot else 0f
                        scaleX = k * 1.1f; scaleY = k * 1.1f
                    }
            ) {
                if (d.item.isFolder) {
                    FolderView(
                        folders.firstOrNull { it.id == d.item.folderId }, d.item, byPkg, labels, iconSize,
                        hidden = false, interactive = false, onOpen = {}
                    )
                } else if (d.app != null && (d.item.w > 1 || d.item.h > 1)) {
                    AppTileItem(d.app, labels, iconSize, hidden = false, interactive = false)
                } else if (d.app != null) {
                    Column(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        AppIcon(d.app, iconSize.dp)
                        if (labels) {
                            Text(
                                d.app.label, color = Color.White, fontSize = 12.sp, maxLines = 1,
                                fontWeight = FontWeight.Bold, overflow = TextOverflow.Ellipsis,
                                style = TextStyle(shadow = Shadow(Color.Black.copy(.35f), blurRadius = 6f)),
                                modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        fmenu?.let { (fi, r) ->
            FloatingMenu(
                (origin.x + r.center.x).roundToInt(),
                (origin.y + r.top).roundToInt(),
                (origin.y + r.bottom).roundToInt(),
                { fmenu = null }
            ) {
                FolderMenuContent(
                    fi,
                    { w, h -> prefs.homeItems = items.resized(fi.pkg, w, h, cols).compacted().encode() },
                    { prefs.homeItems = items.dissolved(fi, cols).compacted().encode() },
                    { fmenu = null }
                )
            }
        }

        menu?.let { (app, r) ->
            FloatingMenu(
                (origin.x + r.center.x).roundToInt(),
                (origin.y + r.top).roundToInt(),
                (origin.y + r.bottom).roundToInt(),
                { menu = null }
            ) {
                val mi = menuItem
                // «Убрать с экрана» здесь убирает именно эту копию
                val acts = if (mi == null) menuFor(app) else menuFor(app).filter { it.label != REMOVE_HOME } +
                    MenuAction(Icons.Filled.Close, REMOVE_HOME, danger = true) {
                        prefs.homeItems = items.filter { it.pkg != mi.pkg }.compacted().encode()
                    }
                if (mi != null) {
                    SizePicker(
                        mi, "Размер иконки",
                        { w, h -> prefs.homeItems = items.resized(mi.pkg, w, h, cols).compacted().encode() },
                        divider = true
                    ) { menu = null }
                }
                AppMenuContent(app, acts) { menu = null }
            }
        }
    }
}

/** Круглая ручка DIY-режима с центром в точке pos (пиксели). */
@Composable
private fun DiyHandle(pos: Offset, dens: Float, content: @Composable () -> Unit) {
    val s = MaterialTheme.colorScheme
    Box(
        Modifier
            .offset { IntOffset((pos.x - 15f * dens).roundToInt(), (pos.y - 15f * dens).roundToInt()) }
            .size(30.dp).clip(CircleShape).background(s.primary),
        contentAlignment = Alignment.Center
    ) { content() }
}
