package com.kyy.launcher

import androidx.compose.animation.core.CubicBezierEasing

/** Единые кривые движения Material 3: появление замедляется плавно, уход ускоряется мягко. */
object Motion {
    val EmphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)
    val EmphasizedAccelerate = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)
    val Standard = CubicBezierEasing(0.2f, 0f, 0f, 1f)
}
