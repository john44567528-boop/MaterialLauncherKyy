package com.kyy.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.io.File

/**
 * Свои названия и иконки приложений. Названия лежат в app_overrides.json, картинки в app_icons/<пакет>.png
 * (папка приложения). Исходное приложение не трогаем, всё только внутри лаунчера.
 */
object AppOverrides {
    /** Меняется при любом изменении, чтобы иконки перерисовались. */
    var version by mutableIntStateOf(0)

    private var labels: MutableMap<String, String>? = null
    private var icons: MutableMap<String, Long>? = null
    private var packs: MutableMap<String, String>? = null

    private fun dir() = File(App.ctx.filesDir, "app_icons").apply { mkdirs() }
    private fun labelFile() = File(App.ctx.filesDir, "app_overrides.json")

    @Synchronized
    private fun loadLabels(): MutableMap<String, String> {
        labels?.let { return it }
        val m = HashMap<String, String>()
        try {
            val j = JSONObject(labelFile().readText())
            j.keys().forEach { m[it] = j.getString(it) }
        } catch (_: Throwable) {}
        labels = m
        return m
    }

    @Synchronized
    private fun loadIcons(): MutableMap<String, Long> {
        icons?.let { return it }
        val m = HashMap<String, Long>()
        try {
            dir().listFiles()?.filter { it.extension == "png" }?.forEach { m[it.nameWithoutExtension] = it.lastModified() }
        } catch (_: Throwable) {}
        icons = m
        return m
    }

    private fun packFile() = File(App.ctx.filesDir, "app_packs.json")

    @Synchronized
    private fun loadPacks(): MutableMap<String, String> {
        packs?.let { return it }
        val m = HashMap<String, String>()
        try {
            val j = JSONObject(packFile().readText())
            j.keys().forEach { m[it] = j.getString(it) }
        } catch (_: Throwable) {}
        packs = m
        return m
    }

    /** Набор иконок, выбранный для этого приложения (пакет набора), или null — тогда действует общий набор из настроек. */
    @Synchronized
    fun pack(pkg: String): String? = loadPacks()[pkg]

    @Synchronized
    fun setPack(pkg: String, pack: String?) {
        val m = loadPacks()
        if (pack.isNullOrEmpty()) m.remove(pkg) else m[pkg] = pack
        try { packFile().writeText(JSONObject(m as Map<*, *>).toString()) } catch (_: Throwable) {}
        version++
    }

    @Synchronized
    fun label(pkg: String): String? = loadLabels()[pkg]

    @Synchronized
    fun setLabel(pkg: String, name: String?) {
        val m = loadLabels()
        val v = name?.trim()?.take(40).orEmpty()
        if (v.isEmpty()) m.remove(pkg) else m[pkg] = v
        try { labelFile().writeText(JSONObject(m as Map<*, *>).toString()) } catch (_: Throwable) {}
        version++
    }

    @Synchronized
    fun stamp(pkg: String): Long = loadIcons()[pkg] ?: 0L

    fun hasIcon(pkg: String) = stamp(pkg) != 0L

    fun loadBitmap(pkg: String): Bitmap? =
        try { BitmapFactory.decodeFile(File(dir(), "$pkg.png").path) } catch (_: Throwable) { null }

    @Synchronized
    fun clearIcon(pkg: String) {
        try { File(dir(), "$pkg.png").delete() } catch (_: Throwable) {}
        loadIcons().remove(pkg)
        version++
    }

    /** Картинка из галереи: по центру обрезаем до квадрата, уменьшаем до 256 px (с учётом поворота из EXIF). */
    fun setIcon(ctx: Context, uri: Uri, pkg: String): Boolean = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (o.outWidth / (sample * 2) >= 512 && o.outHeight / (sample * 2) >= 512) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: throw IllegalStateException("decode")
        val deg = try {
            ctx.contentResolver.openInputStream(uri)?.use {
                when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            } ?: 0f
        } catch (_: Throwable) { 0f }
        if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
        File(dir(), "$pkg.png").outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        synchronized(this) { loadIcons()[pkg] = System.currentTimeMillis() }
        version++
        true
    } catch (_: Throwable) { false }
}

/** Окно «Своя иконка и название» для приложения. */
@Composable
fun AppEditDialog(a: MainActivity, app: AppInfo, onClose: () -> Unit) {
    val ctx = LocalContext.current
    AppOverrides.version   // читаем, чтобы окно обновлялось после смены картинки или набора
    val original = remember(app.pkg) {
        val pm = ctx.packageManager
        try { pm.getActivityInfo(app.cn, 0).loadLabel(pm).toString() } catch (_: Throwable) { app.pkg }
    }
    var name by remember { mutableStateOf(AppOverrides.label(app.pkg) ?: "") }
    var showPacks by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (AppOverrides.setIcon(ctx, uri, app.pkg)) a.appsVersion.intValue++
            else Toast.makeText(ctx, "Не удалось загрузить изображение", Toast.LENGTH_SHORT).show()
        }
    }
    val chosenPack = AppOverrides.pack(app.pkg)
    val changed = AppOverrides.hasIcon(app.pkg) || AppOverrides.label(app.pkg) != null || chosenPack != null
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Иконка и название") },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
            ) {
                AppIcon(app, 72.dp)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(40) }, singleLine = true,
                    label = { Text("Название") }, placeholder = { Text(original) }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { pick.launch("image/*") }) { Text("Выбрать картинку из галереи") }
                OutlinedButton(onClick = { showPacks = !showPacks }) { Text("Иконка из набора иконок") }
                if (showPacks) {
                    PackChoices(app, chosenPack) { pack ->
                        // выбранная из набора иконка заменяет картинку из галереи, иначе галерея перекрыла бы её
                        AppOverrides.clearIcon(app.pkg)
                        AppOverrides.setPack(app.pkg, pack)
                        a.appsVersion.intValue++
                    }
                }
                if (AppOverrides.hasIcon(app.pkg) || chosenPack != null) {
                    OutlinedButton(onClick = {
                        AppOverrides.clearIcon(app.pkg); AppOverrides.setPack(app.pkg, null); a.appsVersion.intValue++
                    }) { Text("Вернуть родную иконку") }
                }
                if (changed) {
                    TextButton(onClick = {
                        AppOverrides.clearIcon(app.pkg); AppOverrides.setPack(app.pkg, null); AppOverrides.setLabel(app.pkg, null)
                        a.appsVersion.intValue++; onClose()
                    }) { Text("Сбросить иконку и название") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                AppOverrides.setLabel(app.pkg, name)
                a.appsVersion.intValue++
                onClose()
            }) { Text("Готово") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Отмена") } }
    )
}

/** Ряд установленных наборов иконок: у каждого показана иконка именно этого приложения; наборы без неё серые и не нажимаются. */
@Composable
private fun PackChoices(app: AppInfo, chosen: String?, onPick: (String) -> Unit) {
    val ctx = LocalContext.current
    val s = MaterialTheme.colorScheme
    val packs = remember { IconPacks.list(ctx) }
    if (packs.isEmpty()) {
        Text(
            "На телефоне не найдено ни одного набора иконок", color = s.onSurfaceVariant, fontSize = 13.sp,
            modifier = Modifier.padding(top = 8.dp)
        )
        return
    }
    val previews by produceState<List<Pair<IconPacks.Pack, ImageBitmap?>>?>(null, app.pkg) {
        value = withContext(Dispatchers.Default) {
            packs.map { p -> p to runCatching { IconPacks.render(ctx, p.pkg, app)?.asImageBitmap() }.getOrNull() }
        }
    }
    val list = previews
    if (list == null) {
        Text("Загрузка…", color = s.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        return
    }
    Text(
        "Выберите набор: иконка возьмётся из него только для этого приложения. Серые наборы такой иконки не содержат.",
        color = s.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
    )
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 8.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        list.forEach { (p, bmp) ->
            val sel = chosen == p.pkg
            Column(
                Modifier.width(76.dp).clip(RoundedCornerShape(16.dp))
                    .background(if (sel) s.primaryContainer else s.surfaceContainerHighest)
                    .then(if (bmp != null) Modifier.clickable { onPick(p.pkg) } else Modifier)
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
                    if (bmp != null) Image(bmp, contentDescription = p.label, modifier = Modifier.fillMaxSize())
                    else Text("—", color = s.onSurfaceVariant.copy(alpha = .5f))
                }
                Text(
                    p.label, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (bmp == null) s.onSurfaceVariant.copy(alpha = .5f) else if (sel) s.onPrimaryContainer else s.onSurface
                )
            }
        }
    }
}
