package com.kyy.launcher

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : ComponentActivity() {
    val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LauncherTheme { SettingsScreen(this) } }
    }

    override fun onResume() { super.onResume(); tick.intValue++ }
}

fun isDefaultLauncher(a: Activity): Boolean {
    val ri = a.packageManager.resolveActivity(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY
    )
    return ri?.activityInfo?.packageName == a.packageName
}

fun defaultAction(a: Activity, isDef: Boolean, l: ManagedActivityResultLauncher<Intent, ActivityResult>) {
    try {
        if (!isDef && Build.VERSION.SDK_INT >= 29) {
            val rm = a.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                l.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                return
            }
        }
        l.launch(Intent(Settings.ACTION_HOME_SETTINGS))
    } catch (e: Exception) {
        try { a.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) } catch (_: Exception) {}
    }
}

// ---------- компоненты ----------

@Composable
fun Section(t: String) = Text(
    t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
    modifier = Modifier.padding(start = 8.dp, top = 22.dp, bottom = 8.dp)
)

@Composable
fun SCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(rc(28)).background(MaterialTheme.colorScheme.surfaceContainer).padding(16.dp),
        content = content
    )
}

@Composable
fun Blob(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.size(48.dp).clip(shapeOf("flower")).background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center, content = content
    )
}

@Composable
fun NavRow(icon: ImageVector?, glyph: String?, title: String, sub: String, onClick: () -> Unit) {
    val s = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(rc(24)).background(s.surfaceContainer)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Blob {
            if (icon != null) Icon(icon, null, tint = s.onPrimaryContainer)
            else Text(glyph ?: "", fontWeight = FontWeight.Bold, color = s.onPrimaryContainer)
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = s.onSurface)
            Text(sub, style = MaterialTheme.typography.bodyMedium, color = s.onSurfaceVariant)
        }
    }
}

@Composable
fun SwitchRow(t: String, v: Boolean, sub: String? = null, c: (Boolean) -> Unit) = Row(
    Modifier.fillMaxWidth().clip(rc(16)).clickable { c(!v) }.padding(vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
) {
    Column(Modifier.weight(1f).padding(end = 12.dp)) {
        Text(t, color = MaterialTheme.colorScheme.onSurface)
        if (sub != null) Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Switch(v, c, thumbContent = {
        Icon(if (v) Icons.Filled.Check else Icons.Filled.Close, null, Modifier.size(SwitchDefaults.IconSize))
    })
}

@Composable
fun Chips(opts: List<Pair<String, String>>, sel: String, on: (String) -> Unit) = Row(
    Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)
) {
    opts.forEach { (k, l) -> ChoiceChip(l, k == sel) { on(k) } }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WrapChips(opts: List<Pair<String, String>>, sel: String, on: (String) -> Unit) = FlowRow(
    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
) {
    opts.forEach { (k, l) -> ChoiceChip(l, k == sel) { on(k) } }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ShapeChips(sel: String, on: (String) -> Unit) = FlowRow(
    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
) {
    val s = MaterialTheme.colorScheme
    ShapeNames.forEach { (k, l) ->
        ChoiceChip(l, k == sel, leading = {
            Box(Modifier.size(18.dp).clip(shapeOf(k)).background(if (k == sel) s.onPrimary else s.primary))
        }) { on(k) }
    }
}

@Composable
fun ColorDots(sel: String, autoKey: String, autoLabel: String, mono: Boolean = false, on: (String) -> Unit) = Row(
    Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp),
    verticalAlignment = Alignment.CenterVertically
) {
    ChoiceChip(autoLabel, sel == autoKey) { on(autoKey) }
    Palette.forEach { (k, v) ->
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color(v))
                .border(if (k == sel) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                .clickable { on(k) }
        )
    }
    if (mono) {
        // чёрный / серый / белый: у светлых и тёмных кружков нужна тонкая обводка, чтобы они не сливались с фоном
        listOf("mono_black" to 0xFF121212, "mono_gray" to 0xFF9E9E9E, "mono_white" to 0xFFF7F7F7).forEach { (k, v) ->
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Color(v))
                    .border(
                        if (k == sel) 3.dp else 1.dp,
                        if (k == sel) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant,
                        CircleShape
                    )
                    .clickable { on(k) }
            )
        }
    }
}

@Composable
fun SliderRow(
    title: String, label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    val s = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), color = s.onSurface, fontWeight = FontWeight.Medium)
        Box(Modifier.clip(rc(20)).background(s.primary).padding(horizontal = 12.dp, vertical = 5.dp)) {
            Text(label, color = s.onPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
    M3Slider(value, onChange, range)
}

/** Образец иконок: показывает выбранную форму, цвет, размер и подписи. Живёт только на странице «Иконки». */
@Composable
fun SettingsPreview() {
    val s = MaterialTheme.colorScheme
    val (fg, bg) = if (prefs.iconMode == "themed") themedColors(s) else s.onSecondaryContainer to s.secondaryContainer
    val sz = prefs.iconSize.coerceIn(40, 64).dp
    Row(
        Modifier.fillMaxWidth().clip(rc(28)).background(s.surfaceVariant.copy(alpha = .6f)).padding(vertical = 18.dp, horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        listOf(
            Icons.Filled.Phone to "Звонки", Icons.Filled.Email to "Почта", Icons.Filled.Place to "Карты",
            Icons.Filled.Star to "Избранное", Icons.Filled.SettingsIcon to "Настройки"
        ).forEach { (ic, name) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                Box(Modifier.size(sz).clip(shapeOf(prefs.iconShape)).background(bg), contentAlignment = Alignment.Center) {
                    Icon(ic, null, tint = fg)
                }
                if (prefs.showLabels) {
                    Text(
                        name, color = s.onSurfaceVariant, fontSize = 11.sp, maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
    }
}

// ---------- экраны ----------

@Composable
fun SettingsScreen(a: SettingsActivity) {
    val s = MaterialTheme.colorScheme
    var page by remember { mutableStateOf("main") }
    BackHandler(page != "main") { page = "main" }
    val title = when (page) {
        "colors" -> "Цвета и тема"
        "fonts" -> "Шрифты"
        "icons" -> "Иконки"
        "home" -> "Главный экран"
        "anim" -> "Анимации"
        "lock" -> "Экран блокировки"
        else -> "Настройки"
    }
    Surface(Modifier.fillMaxSize(), color = s.background) {
        Column(Modifier.systemBarsPadding()) {
            Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (page != "main") {
                    IconButton(
                        onClick = { page = "main" },
                        modifier = Modifier.size(44.dp).clip(CircleShape).background(s.primaryContainer)
                    ) { Icon(Icons.Filled.ArrowBack, "Назад", tint = s.onPrimaryContainer) }
                    Spacer(Modifier.width(14.dp))
                }
                Text(title, style = MaterialTheme.typography.headlineMedium, color = s.onSurface)
                if (page == "main") {
                    Spacer(Modifier.width(10.dp))
                    BetaBadge()
                }
            }
            Crossfade(page, label = "page", modifier = Modifier.weight(1f)) { p ->
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                    when (p) {
                        "colors" -> ColorsPage()
                        "fonts" -> FontsPage()
                        "icons" -> IconsPage()
                        "home" -> HomeSettingsPage()
                        "anim" -> AnimPage()
                        "lock" -> LockSettingsPage()
                        else -> MainPage(a) { page = it }
                    }
                    Spacer(Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
fun MainPage(a: SettingsActivity, go: (String) -> Unit) {
    val s = MaterialTheme.colorScheme
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { a.tick.intValue++ }
    val isDef = remember(a.tick.intValue) { isDefaultLauncher(a) }

    Row(
        Modifier.fillMaxWidth().clip(rc(32)).background(s.primary)
            .clickable { defaultAction(a, isDef, launcher) }.padding(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(56.dp).clip(shapeOf("scallop")).background(s.onPrimary.copy(alpha = .22f)),
            contentAlignment = Alignment.Center
        ) { Icon(if (isDef) Icons.Filled.Check else Icons.Filled.Home, null, tint = s.onPrimary) }
        Spacer(Modifier.width(16.dp))
        Column {
            Text("Material Launcher", color = s.onPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(
                if (isDef) "Ваш рабочий стол" else "Нажмите, чтобы сделать лаунчером по умолчанию",
                color = s.onPrimary.copy(alpha = .85f)
            )
        }
    }

    Section("Внешний вид")
    NavRow(Icons.Filled.Create, null, "Цвета и тема", "Material You, акцентный цвет, палитра, контраст") { go("colors") }
    NavRow(null, "Тт", "Шрифты", "Гарнитура, жирность") { go("fonts") }
    NavRow(Icons.Filled.Star, null, "Иконки", "Форма, тематические иконки, размер, подписи") { go("icons") }
    NavRow(Icons.Filled.PlayArrow, null, "Анимации", "Открытие приложений, разблокировка, скорость") { go("anim") }

    Section("Рабочий стол")
    NavRow(Icons.Filled.Home, null, "Главный экран", "Сетка, док, поиск Google, сброс") { go("home") }
    NavRow(Icons.Filled.Lock, null, "Экран блокировки", "Часы, виртуальный отпечаток, скорость сканирования") { go("lock") }

}

@Composable
fun ColorsPage() {
    SCard {
        Text("Тема", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        Chips(listOf("system" to "Системная", "light" to "Светлая", "dark" to "Тёмная"), prefs.themeMode) { prefs.themeMode = it }
        Spacer(Modifier.height(16.dp))
        Text("Акцентный цвет", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        ColorDots(prefs.accent, "system", "Material You") { prefs.accent = it }
    }
    Section("Палитра")
    SCard {
        WrapChips(
            listOf(
                "tonal" to "Тональный", "fidelity" to "Точный", "vibrant" to "Яркий",
                "expressive" to "Выразительный", "rainbow" to "Радужный", "fruit" to "Фруктовый",
                "neutral" to "Нейтральный", "mono" to "Монохромный"
            ), prefs.palette
        ) { prefs.palette = it }
        Spacer(Modifier.height(12.dp))
        SliderRow("Контраст", "${prefs.contrast}%", prefs.contrast.toFloat(), 0f..100f) { prefs.contrast = it.toInt() }
    }
    Section("Формы")
    SCard {
        SliderRow("Скругление углов", "${prefs.corner}%", prefs.corner.toFloat(), 0f..100f) { prefs.corner = it.toInt() }
    }
}

@Composable
fun AnimPage() {
    val s = MaterialTheme.colorScheme
    SCard {
        SwitchRow("Анимации", prefs.animsEnabled) { prefs.animsEnabled = it }
    }
    if (!prefs.animsEnabled) return
    Section("Открытие и закрытие приложений")
    SCard {
        SwitchRow("Анимация открытия и закрытия", prefs.openAnim) { prefs.openAnim = it }
        Spacer(Modifier.height(14.dp))
        SliderRow("Скорость анимации", "${prefs.animSpeed}%", prefs.animSpeed.toFloat(), 50f..200f) {
            prefs.animSpeed = (it / 5f).toInt() * 5
        }
        Spacer(Modifier.height(14.dp))
        SliderRow("Пауза перед открытием", "${prefs.openDelay} мс", prefs.openDelay.toFloat(), 0f..2000f) {
            prefs.openDelay = (it / 100f).toInt() * 100
        }
        Spacer(Modifier.height(6.dp))
        SwitchRow(
            "Размывать фон при анимации",
            prefs.animBlur,
            if (android.os.Build.VERSION.SDK_INT >= 31) "Не для слабых устройств" else "Не для слабых устройств · нужен Android 12+"
        ) { prefs.animBlur = it }
    }
    Section("Разблокировка")
    SCard {
        SwitchRow("Анимация разблокировки", prefs.unlockAnim) { prefs.unlockAnim = it }
        if (prefs.unlockAnim) {
            Spacer(Modifier.height(10.dp))
            Chips(
                listOf("pixel" to "Google Pixel", "normal" to "Обычная"),
                if (prefs.unlockStyle == "normal") "normal" else "pixel"
            ) { prefs.unlockStyle = it }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { prefs.previewUnlock = true }) { Text("Показать анимацию") }
        }
    }
}

@Composable
fun FontsPage() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var custom by remember { mutableStateOf(CustomFonts.list()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val name = withContext(Dispatchers.IO) { try { CustomFonts.import(uri) } catch (e: Throwable) { null } }
                if (name == null) {
                    Toast.makeText(ctx, "Не удалось открыть шрифт. Нужен файл TTF или OTF", Toast.LENGTH_LONG).show()
                } else {
                    custom = CustomFonts.list()
                    prefs.font = CustomFonts.PREFIX + name
                }
            }
        }
    }
    SCard {
        Text("Гарнитура", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        WrapChips(
            listOf("rounded" to "Скруглённый", "system" to "Системный", "serif" to "С засечками", "mono" to "Моно") +
                custom.map { (CustomFonts.PREFIX + it) to CustomFonts.label(it) },
            prefs.font
        ) { prefs.font = it }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Импортировать шрифт (TTF, OTF)") }
        }
        if (prefs.font.startsWith(CustomFonts.PREFIX)) {
            Spacer(Modifier.height(4.dp))
            TextButton(onClick = {
                CustomFonts.delete(prefs.font.removePrefix(CustomFonts.PREFIX))
                prefs.font = "rounded"
                custom = CustomFonts.list()
            }) { Text("Удалить выбранный шрифт") }
        }
        Spacer(Modifier.height(16.dp))
        Text("Жирность", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        Chips(listOf("0" to "Обычная", "100" to "Средняя", "200" to "Жирная"), "${prefs.weightBoost}") { prefs.weightBoost = it.toInt() }
    }
}

@Composable
fun BetaBadge() {
    val s = MaterialTheme.colorScheme
    Text(
        "beta", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = s.onTertiaryContainer,
        modifier = Modifier.clip(CircleShape).background(s.tertiaryContainer).padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun IconsPage() {
    val ctx = LocalContext.current
    SettingsPreview()
    Spacer(Modifier.height(12.dp))
    SCard {
        Text("Вид иконок", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        Chips(listOf("original" to "Оригинальные", "themed" to "Тематические (перекрас) · beta"), prefs.iconMode) { prefs.iconMode = it }
        Spacer(Modifier.height(16.dp))
        val packs = remember { IconPacks.list(ctx) }
        Text("Набор иконок", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        WrapChips(listOf("" to "Системные") + packs.map { it.pkg to it.label }, prefs.iconPack) { prefs.iconPack = it }
        Text(
            if (packs.isEmpty()) "Наборы иконок (Nova, ADW, Apex) на телефоне не найдены. Установите набор из Google Play, и он появится здесь."
            else "Приложения, которых нет в наборе, остаются с обычными иконками.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text("Форма иконок", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        ShapeChips(prefs.iconShape) { prefs.iconShape = it }
        Spacer(Modifier.height(16.dp))
        Text("Цвет тематических иконок", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        ColorDots(prefs.iconColor, "auto", "Как акцент", mono = true) {
            prefs.iconColor = it
            if (it.startsWith("mono_")) prefs.iconMode = "themed"   // перекрас работает только в тематическом режиме
        }
        Spacer(Modifier.height(16.dp))
        SliderRow("Размер иконок", "${prefs.iconSize} dp", prefs.iconSize.toFloat(), 40f..100f) { prefs.iconSize = it.toInt() }
        SliderRow("Размер иконок в меню приложений", "${prefs.drawerIconSize} dp", prefs.drawerIconSize.toFloat(), 40f..100f) { prefs.drawerIconSize = it.toInt() }
        SwitchRow("Подписи под иконками", prefs.showLabels) { prefs.showLabels = it }
    }
}

@Composable
fun HomeSettingsPage() {
    SCard {
        SwitchRow("Часы", prefs.showClock) { prefs.showClock = it }
        SwitchRow("Дата и заряд батареи", prefs.showInfo) { prefs.showInfo = it }
    }
    Section("Док")
    SCard {
        SliderRow("Размер иконок в доке", "${prefs.dockSize} dp", prefs.dockSize.toFloat(), 36f..100f) { prefs.dockSize = it.toInt() }
        SwitchRow("Фон дока", prefs.dockBg) { prefs.dockBg = it }
        if (prefs.dockBg) {
            Spacer(Modifier.height(10.dp))
            SliderRow("Затемнение дока", "${prefs.dockDim}%", prefs.dockDim.toFloat(), 0f..100f) { prefs.dockDim = it.toInt() }
            SliderRow("Размытие дока", "${prefs.dockBlur}%", prefs.dockBlur.toFloat(), 0f..100f) { prefs.dockBlur = it.toInt() }
            Text(
                "Размытие рисуется по копии обоев (Android 12+). Если система не даёт лаунчеру прочитать обои, например живые, размытия не будет, а затемнение работает всегда.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
    Section("Сетка")
    SCard {
        Text("Колонок на главном экране", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        Chips(listOf(4, 5, 6, 7).map { "$it" to "$it" }, "${prefs.homeCols}") { prefs.homeCols = it.toInt() }
        Spacer(Modifier.height(16.dp))
        Text("Рядов на главном экране", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        Chips(listOf("0" to "Авто") + (4..10).map { "$it" to "$it" }, "${prefs.homeRows}") { prefs.homeRows = it.toInt() }
        Spacer(Modifier.height(16.dp))
        Text("Колонок в списке приложений", fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        Chips(listOf(4, 5, 6).map { "$it" to "$it" }, "${prefs.drawerCols}") { prefs.drawerCols = it.toInt() }
    }
    Section("Поиск")
    SCard {
        SwitchRow("Виджет поиска Google под доком", prefs.showSearch) { prefs.showSearch = it }
        OutlinedButton(onClick = { prefs.qsbAsked = false; prefs.qsbId = -1 }) { Text("Добавить виджет поиска заново") }
        Text(
            "Откройте главный экран после нажатия — лаунчер запросит разрешение на виджет.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
    Section("Сброс")
    SCard {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { prefs.dock = ""; prefs.dockInit = false }) { Text("Сбросить док") }
            OutlinedButton(onClick = { prefs.home = ""; prefs.homeItems = ""; prefs.homeMigrated = true }) { Text("Очистить главный") }
        }
        OutlinedButton(onClick = { prefs.welcomeDone = false }) { Text("Показать приветствие снова") }
    }
}


@Composable
fun LockSettingsPage() {
    val s = MaterialTheme.colorScheme
    SCard {
        SwitchRow(
            "Свой экран блокировки", prefs.lockEnabled,
            "Выключен по умолчанию. Если включить, анимация разблокировки играет только после отпечатка или свайпа вверх"
        ) { prefs.lockEnabled = it }
    }
    Section("Часы")
    SCard {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            LockPreview(Modifier.fillMaxWidth(.62f).aspectRatio(9f / 19.5f))
        }
        Text(
            "Тяните часы пальцем в любое место, щипком меняйте размер.",
            fontSize = 12.sp, color = s.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
        )
        Chips(listOf("stack" to "Столбиком (Pixel)", "line" to "В строку"), prefs.lockClockStyle) { prefs.lockClockStyle = it }
        Spacer(Modifier.height(10.dp))
        if (prefs.lockClockStyle == "stack") {
            SliderRow("Расстояние между цифрами", "${prefs.lockClockGap}%", prefs.lockClockGap.toFloat(), 30f..110f) { prefs.lockClockGap = it.toInt() }
        }
        SwitchRow("Дата под часами", prefs.lockDate) { prefs.lockDate = it }
        SliderRow("Размер часов", "${prefs.lockClockScale}%", prefs.lockClockScale.toFloat(), 30f..300f) { prefs.lockClockScale = it.toInt() }
        OutlinedButton(onClick = { prefs.lockClockX = 500; prefs.lockClockY = 230; prefs.lockClockScale = 100; prefs.lockClockGap = 70 }) { Text("Вернуть часы на место") }
    }
    Section("Отпечаток пальца")
    SCard {
        // слайдер в «скорости»: чем больше, тем быстрее; хранится время в мс (450 мс = 100%)
        val speed = (45000f / prefs.lockScanMs.coerceAtLeast(1) + 0.5f).toInt().coerceIn(25, 400)
        SliderRow("Скорость сканирования", "$speed%", speed.toFloat(), 25f..400f) {
            prefs.lockScanMs = (45000f / it.coerceAtLeast(25f)).toInt()
        }
        Text(
            "Время «сканирования»: ${prefs.lockScanMs} мс. Отпечаток только нарисован, настоящий палец приложение не читает: прижмите и подержите значок, и откроется рабочий стол.",
            fontSize = 12.sp, color = s.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
        )
        val ctx = LocalContext.current
        val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                val ok = saveFingerprintImage(ctx, uri)
                if (!ok) Toast.makeText(ctx, "Не удалось загрузить изображение", Toast.LENGTH_SHORT).show()
            }
        }
        Text("Своя картинка на отпечатке", fontWeight = FontWeight.Medium, color = s.onSurface)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pick.launch("image/*") }) { Text("Выбрать изображение") }
            if (prefs.lockFpImage.isNotEmpty()) OutlinedButton(onClick = { removeFingerprintImage(ctx) }) { Text("Убрать") }
        }
        if (prefs.lockFpImage.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Chips(listOf("fill" to "Заполнить (обрезать)", "fit" to "Вписать целиком"), prefs.lockFpFit) { prefs.lockFpFit = it }
        }
        Spacer(Modifier.height(12.dp))
        var attempt by remember { mutableIntStateOf(0) }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            key(attempt) { FingerprintButton(prefs.lockScanMs, true, 84.dp) { attempt++ } }
        }
    }
}
