package com.kyy.launcher

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : ComponentActivity() {
    val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        edgeToEdgeTransparent()
        setContent { LauncherTheme { SettingsScreen(this) } }
    }

    override fun onResume() { super.onResume(); tick.intValue++ }
}

fun isDefaultLauncher(a: Activity): Boolean {
    val ri = a.packageManager.resolveActivity(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY
    )
    return ri?.activityInfo?.packageName == a.packageName
}

fun defaultAction(a: Activity, isDef: Boolean, l: ManagedActivityResultLauncher<Intent, ActivityResult>) {
    try {
        if (!isDef && Build.VERSION.SDK_INT >= 29) {
            val rm = a.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                l.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                return
            }
        }
        l.launch(Intent(Settings.ACTION_HOME_SETTINGS))
    } catch (e: Exception) {
        try { a.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)) } catch (_: Exception) {}
    }
}

// ---------- строительные блоки ----------

/** Подпись раздела над группой настроек. */
@Composable
fun Section(t: String) = Text(
    t, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
    modifier = Modifier.padding(start = 16.dp, top = 26.dp, bottom = 10.dp)
)

@Composable
fun HintText(t: String, modifier: Modifier = Modifier) = Text(
    t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    modifier = modifier.padding(top = 8.dp)
)

internal class GroupRow(val onClick: (() -> Unit)?, val content: @Composable ColumnScope.() -> Unit)

/** Набор строк одной группы. Первая и последняя получают крупные углы, средние почти прямые, как в M3 Expressive. */
class GroupBuilder {
    private val list = mutableListOf<GroupRow>()
    internal val count get() = list.size
    internal fun rowAt(i: Int) = list[i]

    /** Своя строка. Если задан onClick, вся плашка нажимается. */
    fun item(onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
        list += GroupRow(onClick, content)
    }

    /** Переключатель. */
    fun toggle(title: String, value: Boolean, sub: String? = null, onChange: (Boolean) -> Unit) =
        item(onClick = { onChange(!value) }) { ToggleContent(title, value, sub, onChange) }

    /** Ползунок со значением. */
    fun slider(
        title: String, label: String, value: Float, range: ClosedFloatingPointRange<Float>,
        onChange: (Float) -> Unit
    ) = item { SliderRow(title, label, value, range, onChange) }

    /** Заголовок, под ним любой выбор, внизу необязательная подсказка. */
    fun block(title: String, hint: String? = null, content: @Composable ColumnScope.() -> Unit) = item {
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(12.dp))
        content()
        if (hint != null) HintText(hint)
    }

    /** Нажимаемая строка-действие (сброс, выбор файла и т. п.). */
    fun action(title: String, sub: String? = null, danger: Boolean = false, onClick: () -> Unit) =
        item(onClick) {
            val s = MaterialTheme.colorScheme
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, color = if (danger) s.error else s.primary)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = s.onSurfaceVariant)
        }

    /** Пункт навигации с цветной фигурой-значком. */
    fun nav(
        icon: ImageVector?, glyph: String?, shape: String, tone: Int,
        title: String, sub: String, onClick: () -> Unit
    ) = item(onClick) { NavContent(icon, glyph, shape, tone, title, sub) }
}

@Composable
fun SettingsGroup(build: GroupBuilder.() -> Unit) {
    val s = MaterialTheme.colorScheme
    val g = GroupBuilder().apply(build)
    val k = prefs.corner / 100f
    val big = (28 * k).dp
    val small = (6 * k).dp
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        for (i in 0 until g.count) {
            val r = g.rowAt(i)
            val top = if (i == 0) big else small
            val bottom = if (i == g.count - 1) big else small
            val oc = r.onClick
            Column(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(top, top, bottom, bottom))
                    .background(s.surfaceContainer)
                    .then(if (oc != null) Modifier.clickable(onClick = oc) else Modifier)
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) { r.content(this) }
        }
    }
}

/** Пары «фон / содержимое» для цветных значков: 0 — основной, 1 — вторичный, 2 — третичный. */
private fun toneColors(tone: Int, s: ColorScheme): Pair<Color, Color> = when (tone) {
    1 -> s.secondaryContainer to s.onSecondaryContainer
    2 -> s.tertiaryContainer to s.onTertiaryContainer
    else -> s.primaryContainer to s.onPrimaryContainer
}

@Composable
private fun NavContent(icon: ImageVector?, glyph: String?, shape: String, tone: Int, title: String, sub: String) {
    val s = MaterialTheme.colorScheme
    val (bg, fg) = toneColors(tone, s)
    Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(52.dp).clip(shapeOf(shape)).background(bg),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) Icon(icon, null, tint = fg)
            else Text(glyph ?: "", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = fg)
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = s.onSurface)
            Text(sub, style = MaterialTheme.typography.bodyMedium, color = s.onSurfaceVariant)
        }
        Icon(Icons.Filled.KeyboardArrowRight, null, tint = s.onSurfaceVariant)
    }
}

@Composable
private fun ToggleContent(title: String, v: Boolean, sub: String?, c: (Boolean) -> Unit) {
    val s = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 16.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = s.onSurface)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = s.onSurfaceVariant)
        }
        Switch(v, c, thumbContent = {
            Icon(if (v) Icons.Filled.Check else Icons.Filled.Close, null, Modifier.size(SwitchDefaults.IconSize))
        })
    }
}

@Composable
fun SliderRow(
    title: String, label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    val s = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, color = s.onSurface)
        Text(
            label, color = s.onPrimaryContainer, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.clip(CircleShape).background(s.primaryContainer).padding(horizontal = 12.dp, vertical = 5.dp)
        )
    }
    M3Slider(value, onChange, range)
}

/** Кнопка внутри блока (когда нужна именно кнопка, а не строка-действие). */
@Composable
fun TonalAction(text: String, onClick: () -> Unit) =
    FilledTonalButton(onClick = onClick, shape = rc(20)) { Text(text) }

/** Выбор из нескольких вариантов в одну строку: соединённые кнопки, выбранная — круглая и плотная. */
@Composable
fun ConnectedChoice(opts: List<Pair<String, String>>, sel: String, on: (String) -> Unit) {
    val s = MaterialTheme.colorScheme
    val k = prefs.corner / 100f
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        opts.forEach { (key, label) ->
            val picked = key == sel
            val corner by animateDpAsState(((if (picked) 24 else 10) * k).dp, spring(0.7f, 600f), label = "corner")
            val bg by animateColorAsState(if (picked) s.primary else s.surfaceContainerHighest, label = "bg")
            val fg by animateColorAsState(if (picked) s.onPrimary else s.onSurfaceVariant, label = "fg")
            Box(
                Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(corner)).background(bg)
                    .clickable { on(key) }.padding(horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label, color = fg, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun Chips(opts: List<Pair<String, String>>, sel: String, on: (String) -> Unit) = Row(
    Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)
) {
    opts.forEach { (k, l) -> ChoiceChip(l, k == sel) { on(k) } }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WrapChips(opts: List<Pair<String, String>>, sel: String, on: (String) -> Unit) = FlowRow(
    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
) {
    opts.forEach { (k, l) -> ChoiceChip(l, k == sel) { on(k) } }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ShapeChips(sel: String, on: (String) -> Unit) = FlowRow(
    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
) {
    val s = MaterialTheme.colorScheme
    ShapeNames.forEach { (k, l) ->
        ChoiceChip(l, k == sel, leading = {
            Box(Modifier.size(18.dp).clip(shapeOf(k)).background(if (k == sel) s.onPrimary else s.primary))
        }) { on(k) }
    }
}

@Composable
fun ColorDots(sel: String, autoKey: String, autoLabel: String, mono: Boolean = false, on: (String) -> Unit) = Row(
    Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp),
    verticalAlignment = Alignment.CenterVertically
) {
    val s = MaterialTheme.colorScheme
    @Composable
    fun Dot(k: String, v: Long, ring: Boolean) {
        val c = Color(v)
        val picked = k == sel
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(c)
                .then(if (ring && !picked) Modifier.border(1.dp, s.outlineVariant, CircleShape) else Modifier)
                .clickable { on(k) },
            contentAlignment = Alignment.Center
        ) {
            if (picked) Icon(Icons.Filled.Check, null, tint = if (c.luminance() > .5f) Color.Black else Color.White)
        }
    }
    ChoiceChip(autoLabel, sel == autoKey) { on(autoKey) }
    Palette.forEach { (k, v) -> Dot(k, v, false) }
    if (mono) {
        // чёрный / серый / белый: у светлых кружков нужна тонкая обводка, чтобы они не сливались с фоном
        listOf("mono_black" to 0xFF121212, "mono_gray" to 0xFF9E9E9E, "mono_white" to 0xFFF7F7F7).forEach { (k, v) -> Dot(k, v, true) }
    }
}

@Composable
fun BetaBadge() {
    val s = MaterialTheme.colorScheme
    Text(
        "beta", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = s.onTertiaryContainer,
        modifier = Modifier.clip(CircleShape).background(s.tertiaryContainer).padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

/** Образец иконок: показывает выбранную форму, цвет, размер и подписи. Живёт только на странице «Иконки». */
@Composable
fun SettingsPreview() {
    val s = MaterialTheme.colorScheme
    val (fg, bg) = if (prefs.iconMode == "themed") themedColors(s) else s.onSecondaryContainer to s.secondaryContainer
    val sz = prefs.iconSize.coerceIn(40, 64).dp
    Row(
        Modifier.fillMaxWidth().clip(rc(28)).background(s.surfaceContainerLow).padding(vertical = 20.dp, horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        listOf(
            Icons.Filled.Phone to "Звонки", Icons.Filled.Email to "Почта", Icons.Filled.Place to "Карты",
            Icons.Filled.Star to "Избранное", Icons.Filled.SettingsIcon to "Настройки"
        ).forEach { (ic, name) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                Box(Modifier.size(sz).clip(shapeOf(prefs.iconShape)).background(bg), contentAlignment = Alignment.Center) {
                    Icon(ic, null, tint = fg)
                }
                if (prefs.showLabels) {
                    Text(
                        name, color = s.onSurfaceVariant, fontSize = 11.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
    }
}

/** Образец темы: четыре фигуры в основных цветах палитры, меняются сразу при выборе. */
@Composable
fun ThemePreview() {
    val s = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(rc(28)).background(s.surfaceContainerLow).padding(vertical = 22.dp, horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
    ) {
        @Composable
        fun Swatch(shape: String, bg: Color, fg: Color, ic: ImageVector, size: Int) {
            Box(Modifier.size(size.dp).clip(shapeOf(shape)).background(bg), contentAlignment = Alignment.Center) {
                Icon(ic, null, tint = fg)
            }
        }
        Swatch("cookie", s.primary, s.onPrimary, Icons.Filled.Home, 72)
        Swatch("flower", s.secondaryContainer, s.onSecondaryContainer, Icons.Filled.Star, 60)
        Swatch("scallop", s.tertiaryContainer, s.onTertiaryContainer, Icons.Filled.Lock, 68)
        Swatch("clover", s.surfaceContainerHighest, s.onSurfaceVariant, Icons.Filled.Create, 56)
    }
}

/** Образец шрифта: показывает выбранную гарнитуру и жирность. */
@Composable
fun FontPreview() {
    val s = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(rc(28)).background(s.primaryContainer).padding(24.dp)
    ) {
        Text("Aa", style = MaterialTheme.typography.displayMedium, color = s.onPrimaryContainer)
        Spacer(Modifier.height(6.dp))
        Text(
            "Съешь ещё этих мягких французских булок, да выпей чаю",
            style = MaterialTheme.typography.bodyLarge, color = s.onPrimaryContainer
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "0123456789  The quick brown fox",
            style = MaterialTheme.typography.labelLarge, color = s.onPrimaryContainer.copy(alpha = .75f)
        )
    }
}

// ---------- каркас экрана ----------

/** Страница с большим сворачивающимся заголовком. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PageScaffold(
    title: String, onBack: (() -> Unit)?, badge: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val s = MaterialTheme.colorScheme
    val behavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(behavior.nestedScrollConnection),
        containerColor = s.background,
        topBar = {
            LargeTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = s.onSurface)
                        if (badge) {
                            Spacer(Modifier.width(10.dp))
                            BetaBadge()
                        }
                    }
                },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.padding(start = 6.dp).size(44.dp).clip(CircleShape).background(s.primaryContainer)
                        ) { Icon(Icons.Filled.ArrowBack, "Назад", tint = s.onPrimaryContainer) }
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = s.background, scrolledContainerColor = s.background
                ),
                scrollBehavior = behavior
            )
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
        ) {
            content()
            Spacer(Modifier.height(32.dp))
        }
    }
}

private fun pageTitle(p: String) = when (p) {
    "colors" -> "Цвета и тема"
    "fonts" -> "Шрифты"
    "icons" -> "Иконки"
    "home" -> "Главный экран"
    "anim" -> "Анимации"
    "lock" -> "Экран блокировки"
    "about" -> "О лаунчере"
    else -> "Настройки"
}

@Composable
fun SettingsScreen(a: SettingsActivity) {
    var page by rememberSaveable { mutableStateOf("main") }
    BackHandler(page != "main") { page = "main" }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        AnimatedContent(
            targetState = page,
            transitionSpec = {
                if (targetState != "main")
                    (slideInHorizontally(tween(280)) { it / 8 } + fadeIn(tween(240))) togetherWith
                        (slideOutHorizontally(tween(280)) { -it / 8 } + fadeOut(tween(160)))
                else
                    (slideInHorizontally(tween(280)) { -it / 8 } + fadeIn(tween(240))) togetherWith
                        (slideOutHorizontally(tween(280)) { it / 8 } + fadeOut(tween(160)))
            },
            label = "page"
        ) { p ->
            PageScaffold(
                title = pageTitle(p),
                onBack = if (p != "main") ({ page = "main" }) else null,
                badge = p == "main"
            ) {
                when (p) {
                    "colors" -> ColorsPage()
                    "fonts" -> FontsPage()
                    "icons" -> IconsPage()
                    "home" -> HomeSettingsPage()
                    "anim" -> AnimPage()
                    "lock" -> LockSettingsPage()
                    "about" -> AboutPage()
                    else -> MainPage(a) { page = it }
                }
            }
        }
    }
}

// ---------- страницы ----------

@Composable
fun AboutPage() {
    val s = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { null }
    }
    Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(180.dp).clip(shapeOf("cookie")).background(s.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text("M", fontSize = 84.sp, fontWeight = FontWeight.Black, color = s.onPrimaryContainer)
        }
        Spacer(Modifier.height(24.dp))
        Text("Material Launcher", style = MaterialTheme.typography.headlineMedium, color = s.onSurface, textAlign = TextAlign.Center)
        if (version != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                "Версия $version", color = s.onSecondaryContainer, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(CircleShape).background(s.secondaryContainer).padding(horizontal = 14.dp, vertical = 6.dp)
            )
        }
        Spacer(Modifier.height(40.dp))
    }
    SettingsGroup {
        item {
            Text("Лаунчер находится в бете", style = MaterialTheme.typography.titleMedium, color = s.onSurface)
            Text("Что-то может работать нестабильно", style = MaterialTheme.typography.bodyMedium, color = s.onSurfaceVariant)
        }
        item {
            Text("Автор", style = MaterialTheme.typography.titleMedium, color = s.onSurface)
            Text("@kyyrick", style = MaterialTheme.typography.bodyMedium, color = s.primary, fontWeight = FontWeight.Bold)
        }
        item {
            Text(
                "Лаунчер не является копией лаунчера от m3 boss",
                style = MaterialTheme.typography.bodyMedium, color = s.onSurfaceVariant
            )
        }
    }
}

@Composable
fun MainPage(a: SettingsActivity, go: (String) -> Unit) {
    val s = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { a.tick.intValue++ }
    val isDef = remember(a.tick.intValue) { isDefaultLauncher(a) }
    val version = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { null }
    }

    // Карточка статуса: крупная, с большой полупрозрачной фигурой в углу
    Box(
        Modifier.fillMaxWidth().clip(rc(36)).background(s.primary)
            .clickable { defaultAction(a, isDef, launcher) }
    ) {
        Box(
            Modifier.align(Alignment.TopEnd).offset(x = 64.dp, y = (-56).dp).size(190.dp)
                .clip(shapeOf("cookie")).background(s.onPrimary.copy(alpha = .08f))
        )
        Column(Modifier.padding(24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(64.dp).clip(shapeOf("scallop")).background(s.onPrimary.copy(alpha = .2f)),
                    contentAlignment = Alignment.Center
                ) { Icon(if (isDef) Icons.Filled.Check else Icons.Filled.Home, null, tint = s.onPrimary) }
                Spacer(Modifier.width(18.dp))
                Column {
                    Text("Material Launcher", style = MaterialTheme.typography.titleLarge, color = s.onPrimary, fontWeight = FontWeight.Bold)
                    Text(
                        if (isDef) "Ваш рабочий стол" else "Сейчас не основной",
                        style = MaterialTheme.typography.bodyMedium, color = s.onPrimary.copy(alpha = .85f)
                    )
                }
            }
            if (!isDef) {
                Spacer(Modifier.height(18.dp))
                Text(
                    "Сделать основным", color = s.primary, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(CircleShape).background(s.onPrimary).padding(horizontal = 20.dp, vertical = 10.dp)
                )
            }
        }
    }

    Section("Оформление")
    SettingsGroup {
        nav(Icons.Filled.Create, null, "cookie", 0, "Цвета и тема", "Material You, акцент, палитра, контраст") { go("colors") }
        nav(null, "Aa", "flower", 1, "Шрифты", "Гарнитура и жирность") { go("fonts") }
        nav(Icons.Filled.Star, null, "scallop", 2, "Иконки", "Форма, цвет, размер, подписи") { go("icons") }
        nav(Icons.Filled.PlayArrow, null, "clover", 0, "Анимации", "Запуск приложений, разблокировка") { go("anim") }
    }

    Section("Рабочий стол")
    SettingsGroup {
        nav(Icons.Filled.Home, null, "flower", 1, "Главный экран", "Сетка, док, поиск, сброс") { go("home") }
        nav(Icons.Filled.Lock, null, "cookie", 2, "Экран блокировки", "Часы, отпечаток, быстрые кнопки") { go("lock") }
    }

    Section("Приложение")
    SettingsGroup {
        nav(null, "M", "cookie", 1, "О лаунчере", "Версия, автор") { go("about") }
    }

    Text(
        "Material Launcher" + if (version != null) " · $version" else "",
        style = MaterialTheme.typography.bodySmall, color = s.onSurfaceVariant,
        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 28.dp)
    )
}

@Composable
fun ColorsPage() {
    ThemePreview()
    Section("Тема")
    SettingsGroup {
        block("Режим") {
            ConnectedChoice(listOf("system" to "Системная", "light" to "Светлая", "dark" to "Тёмная"), prefs.themeMode) { prefs.themeMode = it }
        }
        block("Акцентный цвет") {
            ColorDots(prefs.accent, "system", "Material You") { prefs.accent = it }
        }
    }
    Section("Палитра")
    SettingsGroup {
        block("Стиль палитры") {
            WrapChips(
                listOf(
                    "tonal" to "Тональный", "fidelity" to "Точный", "vibrant" to "Яркий",
                    "expressive" to "Выразительный", "rainbow" to "Радужный", "fruit" to "Фруктовый",
                    "neutral" to "Нейтральный", "mono" to "Монохромный"
                ), prefs.palette
            ) { prefs.palette = it }
        }
        slider("Контраст", "${prefs.contrast}%", prefs.contrast.toFloat(), 0f..100f) { prefs.contrast = it.toInt() }
    }
    Section("Формы")
    SettingsGroup {
        slider("Скругление углов", "${prefs.corner}%", prefs.corner.toFloat(), 0f..100f) { prefs.corner = it.toInt() }
    }
}

@Composable
fun FontsPage() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var custom by remember { mutableStateOf(CustomFonts.list()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val name = withContext(Dispatchers.IO) { try { CustomFonts.import(uri) } catch (e: Throwable) { null } }
                if (name == null) {
                    Toast.makeText(ctx, "Не удалось открыть шрифт. Нужен файл TTF или OTF", Toast.LENGTH_LONG).show()
                } else {
                    custom = CustomFonts.list()
                    prefs.font = CustomFonts.PREFIX + name
                }
            }
        }
    }
    FontPreview()
    Section("Гарнитура")
    SettingsGroup {
        block("Шрифт приложения") {
            WrapChips(
                listOf("rounded" to "Скруглённый", "system" to "Системный", "serif" to "С засечками", "mono" to "Моно") +
                    custom.map { (CustomFonts.PREFIX + it) to CustomFonts.label(it) },
                prefs.font
            ) { prefs.font = it }
        }
        action("Импортировать шрифт", "Файл TTF или OTF") { picker.launch(arrayOf("*/*")) }
        if (prefs.font.startsWith(CustomFonts.PREFIX)) {
            action("Удалить выбранный шрифт", danger = true) {
                CustomFonts.delete(prefs.font.removePrefix(CustomFonts.PREFIX))
                prefs.font = "rounded"
                custom = CustomFonts.list()
            }
        }
    }
    Section("Жирность")
    SettingsGroup {
        block("Насыщенность текста") {
            ConnectedChoice(listOf("0" to "Обычная", "100" to "Средняя", "200" to "Жирная"), "${prefs.weightBoost}") { prefs.weightBoost = it.toInt() }
        }
    }
}

@Composable
fun IconsPage() {
    val ctx = LocalContext.current
    val packs = remember { IconPacks.list(ctx) }
    SettingsPreview()
    Section("Внешний вид")
    SettingsGroup {
        block("Вид иконок") {
            ConnectedChoice(listOf("original" to "Оригинальные", "themed" to "Тематические · beta"), prefs.iconMode) { prefs.iconMode = it }
        }
        block(
            "Набор иконок",
            if (packs.isEmpty()) "Наборы иконок (Nova, ADW, Apex) на телефоне не найдены. Установите набор из Google Play, и он появится здесь."
            else "Приложения, которых нет в наборе, остаются с обычными иконками."
        ) {
            WrapChips(listOf("" to "Системные") + packs.map { it.pkg to it.label }, prefs.iconPack) { prefs.iconPack = it }
        }
    }
    Section("Форма и цвет")
    SettingsGroup {
        block("Форма иконок") { ShapeChips(prefs.iconShape) { prefs.iconShape = it } }
        block("Цвет тематических иконок") {
            ColorDots(prefs.iconColor, "auto", "Как акцент", mono = true) {
                prefs.iconColor = it
                if (it.startsWith("mono_")) prefs.iconMode = "themed"   // перекрас работает только в тематическом режиме
            }
        }
    }
    Section("Размер")
    SettingsGroup {
        slider("Размер иконок", "${prefs.iconSize} dp", prefs.iconSize.toFloat(), 40f..100f) { prefs.iconSize = it.toInt() }
        slider("В меню приложений", "${prefs.drawerIconSize} dp", prefs.drawerIconSize.toFloat(), 40f..100f) { prefs.drawerIconSize = it.toInt() }
        toggle("Подписи под иконками", prefs.showLabels) { prefs.showLabels = it }
    }
}

@Composable
fun AnimPage() {
    SettingsGroup {
        toggle("Анимации", prefs.animsEnabled, "Общий выключатель всех анимаций") { prefs.animsEnabled = it }
    }
    if (!prefs.animsEnabled) return
    Section("Открытие и закрытие приложений")
    SettingsGroup {
        toggle("Анимация открытия и закрытия", prefs.openAnim) { prefs.openAnim = it }
        slider("Скорость анимации", "${prefs.animSpeed}%", prefs.animSpeed.toFloat(), 50f..200f) {
            prefs.animSpeed = (it / 5f).toInt() * 5
        }
        slider("Пауза перед открытием", "${prefs.openDelay} мс", prefs.openDelay.toFloat(), 0f..2000f) {
            prefs.openDelay = (it / 100f).toInt() * 100
        }
        toggle(
            "Размывать фон при анимации",
            prefs.animBlur,
            if (Build.VERSION.SDK_INT >= 31) "Не для слабых устройств" else "Не для слабых устройств · нужен Android 12+"
        ) { prefs.animBlur = it }
    }
    Section("Разблокировка")
    SettingsGroup {
        toggle("Анимация разблокировки", prefs.unlockAnim) { prefs.unlockAnim = it }
        if (prefs.unlockAnim) {
            block("Стиль") {
                ConnectedChoice(
                    listOf("pixel" to "Google Pixel", "normal" to "Обычная"),
                    if (prefs.unlockStyle == "normal") "normal" else "pixel"
                ) { prefs.unlockStyle = it }
            }
            action("Показать анимацию") { prefs.previewUnlock = true }
        }
    }
}

@Composable
fun HomeSettingsPage() {
    val ctx = LocalContext.current
    Section("Сетка")
    SettingsGroup {
        block("Колонок на главном экране") {
            ConnectedChoice(listOf(4, 5, 6, 7).map { "$it" to "$it" }, "${prefs.homeCols}") { prefs.homeCols = it.toInt() }
        }
        block("Рядов на главном экране") {
            WrapChips(listOf("0" to "Авто") + (4..10).map { "$it" to "$it" }, "${prefs.homeRows}") { prefs.homeRows = it.toInt() }
        }
        block("Колонок в списке приложений") {
            ConnectedChoice(listOf(4, 5, 6).map { "$it" to "$it" }, "${prefs.drawerCols}") { prefs.drawerCols = it.toInt() }
        }
    }
    Section("Док")
    SettingsGroup {
        slider("Размер иконок в доке", "${prefs.dockSize} dp", prefs.dockSize.toFloat(), 36f..100f) { prefs.dockSize = it.toInt() }
        toggle("Фон дока", prefs.dockBg) { prefs.dockBg = it }
        if (prefs.dockBg) {
            slider("Затемнение дока", "${prefs.dockDim}%", prefs.dockDim.toFloat(), 0f..100f) { prefs.dockDim = it.toInt() }
            slider("Размытие дока", "${prefs.dockBlur}%", prefs.dockBlur.toFloat(), 0f..100f) { prefs.dockBlur = it.toInt() }
            item {
                HintText(
                    "Размытие рисуется по копии обоев (Android 12+). Если система не даёт лаунчеру прочитать обои, например живые, размытия не будет, а затемнение работает всегда.")
            }
        }
    }
    Section("Поиск")
    SettingsGroup {
        toggle("Виджет поиска Google под доком", prefs.showSearch) { prefs.showSearch = it }
        action("Добавить виджет поиска заново", "Откройте главный экран после нажатия: лаунчер запросит разрешение на виджет") {
            prefs.qsbAsked = false; prefs.qsbId = -1
        }
    }
    Section("Сброс и восстановление")
    SettingsGroup {
        action("Сбросить док", "Вернуть иконки дока к исходным", danger = true) { prefs.dock = ""; prefs.dockInit = false }
        action("Очистить главный экран", "Убрать все иконки с рабочего стола", danger = true) {
            prefs.homeCleared = true; prefs.home = ""; prefs.homeItems = ""; prefs.homeMigrated = true
        }
        action(
            "Восстановить расположение иконок",
            "Лаунчер сам хранит копии раскладки (главный экран, папки, док). Если иконки когда-нибудь пропадут, вернётся самая полная копия."
        ) {
            val ok = LayoutBackup.restoreBest()
            Toast.makeText(ctx, if (ok) "Расположение иконок восстановлено из копии" else "Копий раскладки пока нет", Toast.LENGTH_SHORT).show()
        }
        action("Показать приветствие снова") { prefs.welcomeDone = false }
    }
}

@Composable
fun LockSettingsPage() {
    val s = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val ok = saveFingerprintImage(ctx, uri)
            if (!ok) Toast.makeText(ctx, "Не удалось загрузить изображение", Toast.LENGTH_SHORT).show()
        }
    }
    var attempt by remember { mutableIntStateOf(0) }
    // слайдер в «скорости»: чем больше, тем быстрее; хранится время в мс (450 мс = 100%)
    val speed = (45000f / prefs.lockScanMs.coerceAtLeast(1) + 0.5f).toInt().coerceIn(25, 400)

    SettingsGroup {
        toggle(
            "Свой экран блокировки", prefs.lockEnabled,
            "Выключен по умолчанию. Если включить, анимация разблокировки играет только после отпечатка или свайпа вверх"
        ) { prefs.lockEnabled = it }
    }

    Section("Часы")
    SettingsGroup {
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                LockPreview(Modifier.fillMaxWidth(.62f).aspectRatio(9f / 19.5f))
            }
            HintText("Тяните часы пальцем в любое место, щипком меняйте размер.")
        }
        block("Стиль часов") {
            ConnectedChoice(listOf("stack" to "Столбиком (Pixel)", "line" to "В строку"), prefs.lockClockStyle) { prefs.lockClockStyle = it }
        }
        block("Шрифт часов") { ClockFontPicker() }
        if (prefs.lockClockStyle == "stack") {
            slider("Расстояние между цифрами", "${prefs.lockClockGap}%", prefs.lockClockGap.toFloat(), 30f..110f) { prefs.lockClockGap = it.toInt() }
        }
        toggle("Дата под часами", prefs.lockDate) { prefs.lockDate = it }
        slider("Размер часов", "${prefs.lockClockScale}%", prefs.lockClockScale.toFloat(), 30f..300f) { prefs.lockClockScale = it.toInt() }
        action("Вернуть часы на место") { prefs.lockClockX = 500; prefs.lockClockY = 230; prefs.lockClockScale = 100; prefs.lockClockGap = 70 }
    }

    Section("Виджеты и ярлыки")
    SettingsGroup {
        toggle("Заряд батареи", prefs.lockWBattery, "Под датой, двигается вместе с часами") { prefs.lockWBattery = it }
        toggle("Ближайший будильник", prefs.lockWAlarm, "Под датой, показывает время следующего будильника") { prefs.lockWAlarm = it }
        toggle("Фонарик", prefs.lockTorch, "Кнопка в левом нижнем углу") { prefs.lockTorch = it }
        toggle("Камера", prefs.lockCamera, "Кнопка в правом нижнем углу") { prefs.lockCamera = it }
        item { HintText("Это встроенные элементы лаунчера. Виджеты других приложений на экран блокировки пока не ставятся.") }
    }

    Section("Отпечаток пальца")
    SettingsGroup {
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                LockPreview(Modifier.fillMaxWidth(.62f).aspectRatio(9f / 19.5f), target = "fp")
            }
            HintText("Тяните отпечаток пальцем в любое место экрана или точнее настройте ползунками.")
        }
        slider("Положение по горизонтали", "${prefs.lockFpX / 10}%", prefs.lockFpX.toFloat(), 0f..1000f) { prefs.lockFpX = it.toInt() }
        slider("Положение по вертикали", "${prefs.lockFpY / 10}%", prefs.lockFpY.toFloat(), 0f..1000f) { prefs.lockFpY = it.toInt() }
        action("Вернуть отпечаток на место") { prefs.lockFpX = 500; prefs.lockFpY = 880 }
        toggle(
            "Подпись над отпечатком", prefs.lockHint,
            "Надпись «Коснитесь датчика или проведите вверх». Выключите, чтобы её не было"
        ) { prefs.lockHint = it }
        slider("Скорость сканирования", "$speed%", speed.toFloat(), 25f..400f) {
            prefs.lockScanMs = (45000f / it.coerceAtLeast(25f)).toInt()
        }
        item {
            HintText(
                "Время «сканирования»: ${prefs.lockScanMs} мс. Отпечаток только нарисован, настоящий палец приложение не читает: прижмите и подержите значок, и откроется рабочий стол.")
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                key(attempt) { FingerprintButton(prefs.lockScanMs, true, 84.dp) { attempt++ } }
            }
        }
    }

    Section("Значок отпечатка")
    SettingsGroup {
        block(
            "Вид значка",
            if (prefs.lockFpImage.isNotEmpty()) "Сейчас стоит своя картинка, она закрывает значок. Нажмите «Убрать» ниже, чтобы увидеть выбранный вид." else null
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("pixel" to "Pixel", "rings" to "Кольца", "spiral" to "Завиток").forEach { (k, l) ->
                    val sel = prefs.lockFpStyle == k
                    Column(
                        Modifier.weight(1f).clip(rc(20))
                            .background(if (sel) s.primaryContainer else s.surfaceContainerHighest)
                            .clickable { prefs.lockFpStyle = k }
                            .padding(vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        FingerprintGlyph(if (sel) s.onPrimaryContainer else s.onSurface, Modifier.size(44.dp), k)
                        Spacer(Modifier.height(6.dp))
                        Text(l, fontSize = 12.sp, color = if (sel) s.onPrimaryContainer else s.onSurfaceVariant)
                    }
                }
            }
        }
        action("Выбрать свою картинку", "Изображение из галереи на значке отпечатка") { pick.launch("image/*") }
        if (prefs.lockFpImage.isNotEmpty()) {
            action("Убрать свою картинку", danger = true) { removeFingerprintImage(ctx) }
            block("Как вписать картинку") {
                ConnectedChoice(listOf("fill" to "Заполнить (обрезать)", "fit" to "Вписать целиком"), prefs.lockFpFit) { prefs.lockFpFit = it }
            }
        }
    }
}

/** Плитки со шрифтами для часов на экране блокировки: каждая показывает «12:45» своим шрифтом. */
@Composable
fun ClockFontPicker() {
    val s = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var custom by remember { mutableStateOf(CustomFonts.list()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val name = withContext(Dispatchers.IO) { try { CustomFonts.import(uri) } catch (e: Throwable) { null } }
                if (name == null) {
                    Toast.makeText(ctx, "Не удалось открыть шрифт. Нужен файл TTF или OTF", Toast.LENGTH_LONG).show()
                } else {
                    custom = CustomFonts.list()
                    prefs.lockClockFont = CustomFonts.PREFIX + name   // только для часов, шрифт приложения не меняется
                }
            }
        }
    }
    val items = LockClockFonts.presets + custom.map { LockClockFonts.resolve(CustomFonts.PREFIX + it) }
    items.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { f ->
                val sel = f.id == prefs.lockClockFont
                Column(
                    Modifier.weight(1f).clip(rc(20))
                        .background(if (sel) s.primaryContainer else s.surfaceContainerHighest)
                        .clickable { prefs.lockClockFont = f.id }
                        .padding(vertical = 12.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val fg = if (sel) s.onPrimaryContainer else s.onSurface
                    ClockText(f, "12:45", 26.dp, if (f.family != null) FontWeight.Normal else FontWeight.Black, fg, false)
                    Text(
                        f.label, fontSize = 11.sp, maxLines = 1,
                        color = if (sel) s.onPrimaryContainer else s.onSurfaceVariant
                    )
                }
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
    TonalAction("Свой шрифт для часов (TTF, OTF)") { picker.launch(arrayOf("*/*")) }
}
