package com.kyy.launcher

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.graphics.shapes.CornerRounding
import androidx.graphics.shapes.RoundedPolygon
import androidx.graphics.shapes.star

class PolyShape(private val poly: RoundedPolygon, private val rotDeg: Float = 0f) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = Path()
        val w = size.width / 2f
        val h = size.height / 2f
        val rad = Math.toRadians(rotDeg.toDouble())
        val cs = kotlin.math.cos(rad).toFloat()
        val sn = kotlin.math.sin(rad).toFloat()
        // поворот вокруг центра, чтобы, например, треугольник смотрел вверх
        fun px(x: Float, y: Float) = (x * cs - y * sn + 1f) * w
        fun py(x: Float, y: Float) = (x * sn + y * cs + 1f) * h
        var first = true
        for (c in poly.cubics) {
            if (first) {
                path.moveTo(px(c.anchor0X, c.anchor0Y), py(c.anchor0X, c.anchor0Y))
                first = false
            }
            path.cubicTo(
                px(c.control0X, c.control0Y), py(c.control0X, c.control0Y),
                px(c.control1X, c.control1Y), py(c.control1X, c.control1Y),
                px(c.anchor1X, c.anchor1Y), py(c.anchor1X, c.anchor1Y)
            )
        }
        path.close()
        return Outline.Generic(path)
    }
}

val ShapeNames = listOf(
    "circle" to "Круг",
    "squircle" to "Сквиркл",
    "rounded" to "Скруглённый",
    "square" to "Квадрат",
    "teardrop" to "Капля",
    "cookie" to "Печенье",
    "flower" to "Цветок",
    "scallop" to "Волна",
    "clover" to "Клевер",
    "pentagon" to "Пятиугольник",
    "hexagon" to "Шестиугольник",
    "octagon" to "Восьмиугольник",
    "diamond" to "Ромб",
    "triangle" to "Треугольник",
    "star" to "Звезда",
    "sun" to "Солнце",
    "daisy" to "Ромашка",
    "cloud" to "Облако",
    "arch" to "Арка",
    "leaf" to "Лист",
    "custom" to "Своя"
)

private val shapeCache = HashMap<String, Shape>()

/** Квадрат и своя форма зависят от настроек, поэтому в общий кэш не попадают (читают prefs прямо при вызове). */
fun shapeOf(name: String): Shape = when (name) {
    "square" -> RoundedCornerShape(prefs.squareCorner.coerceIn(0, 50))
    "custom" -> customShapeOf(prefs.customShape)
    else -> cachedShape(name)
}

private fun cachedShape(name: String): Shape = shapeCache.getOrPut(name) {
    when (name) {
        "circle" -> CircleShape
        "squircle" -> RoundedCornerShape(35)
        "rounded" -> RoundedCornerShape(22)
        "teardrop" -> RoundedCornerShape(
            topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 8, bottomStartPercent = 50
        )
        "cookie" -> PolyShape(RoundedPolygon.star(10, 1f, 0.87f, CornerRounding(0.55f)))
        "flower" -> PolyShape(RoundedPolygon.star(8, 1f, 0.72f, CornerRounding(0.4f)))
        "scallop" -> PolyShape(RoundedPolygon.star(12, 1f, 0.9f, CornerRounding(0.6f)))
        "clover" -> PolyShape(RoundedPolygon.star(4, 1f, 0.6f, CornerRounding(0.5f)))
        "pentagon" -> PolyShape(RoundedPolygon(5, rounding = CornerRounding(0.2f)))
        "hexagon" -> PolyShape(RoundedPolygon(6, rounding = CornerRounding(0.2f)))
        "octagon" -> PolyShape(RoundedPolygon(8, rounding = CornerRounding(0.18f)))
        "diamond" -> PolyShape(RoundedPolygon(4, rounding = CornerRounding(0.22f)))
        "triangle" -> PolyShape(RoundedPolygon(3, rounding = CornerRounding(0.3f)), -90f)
        "star" -> PolyShape(RoundedPolygon.star(5, 1f, 0.52f, CornerRounding(0.14f)), -90f)
        "sun" -> PolyShape(RoundedPolygon.star(8, 1f, 0.78f, CornerRounding(0.2f)))
        "daisy" -> PolyShape(RoundedPolygon.star(6, 1f, 0.62f, CornerRounding(0.5f)))
        "cloud" -> PolyShape(RoundedPolygon.star(7, 1f, 0.84f, CornerRounding(0.65f)))
        "arch" -> RoundedCornerShape(
            topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 14, bottomStartPercent = 14
        )
        "leaf" -> RoundedCornerShape(
            topStartPercent = 50, topEndPercent = 10, bottomEndPercent = 50, bottomStartPercent = 10
        )
        else -> CircleShape
    }
}
