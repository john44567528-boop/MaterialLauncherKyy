package com.kyy.launcher

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.graphics.shapes.CornerRounding
import androidx.graphics.shapes.RoundedPolygon
import androidx.graphics.shapes.star

/**
 * Многоугольник/звезда из graphics-shapes, растянутый по своим реальным границам на всю плитку.
 * Раньше контур просто умещался в круг радиуса 1, поэтому ромб, треугольник, клевер, ромашка и звезда
 * занимали лишь 30–50% плитки (у круга 78%) и выглядели мельче остальных. Теперь любая форма
 * касается всех четырёх сторон плитки, как круг.
 */
class PolyShape(private val poly: RoundedPolygon, private val rotDeg: Float = 0f) : Shape {
    private val rad = Math.toRadians(rotDeg.toDouble())
    private val cs = kotlin.math.cos(rad).toFloat()
    private val sn = kotlin.math.sin(rad).toFloat()

    // контур в единичных координатах (после поворота): нужен только чтобы один раз узнать его границы
    private val unit: Path by lazy {
        val path = Path()
        var first = true
        for (c in poly.cubics) {
            if (first) {
                path.moveTo(ux(c.anchor0X, c.anchor0Y), uy(c.anchor0X, c.anchor0Y))
                first = false
            }
            path.cubicTo(
                ux(c.control0X, c.control0Y), uy(c.control0X, c.control0Y),
                ux(c.control1X, c.control1Y), uy(c.control1X, c.control1Y),
                ux(c.anchor1X, c.anchor1Y), uy(c.anchor1X, c.anchor1Y)
            )
        }
        path.close()
        path
    }
    private val bounds by lazy { unit.getBounds() }

    private fun ux(x: Float, y: Float) = x * cs - y * sn
    private fun uy(x: Float, y: Float) = x * sn + y * cs

    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val b = bounds
        val sx = size.width / (b.right - b.left).coerceAtLeast(1e-4f)
        val sy = size.height / (b.bottom - b.top).coerceAtLeast(1e-4f)
        // независимое растяжение по осям: границы формы всегда совпадают с границами плитки
        fun px(x: Float, y: Float) = (ux(x, y) - b.left) * sx
        fun py(x: Float, y: Float) = (uy(x, y) - b.top) * sy
        val path = Path()
        var first = true
        for (c in poly.cubics) {
            if (first) {
                path.moveTo(px(c.anchor0X, c.anchor0Y), py(c.anchor0X, c.anchor0Y))
                first = false
            }
            path.cubicTo(
                px(c.control0X, c.control0Y), py(c.control0X, c.control0Y),
                px(c.control1X, c.control1Y), py(c.control1X, c.control1Y),
                px(c.anchor1X, c.anchor1Y), py(c.anchor1X, c.anchor1Y)
            )
        }
        path.close()
        return Outline.Generic(path)
    }
}

val ShapeNames = listOf(
    "circle" to "Круг",
    "squircle" to "Сквиркл",
    "rounded" to "Скруглённый",
    "square" to "Квадрат",
    "teardrop" to "Капля",
    "cookie" to "Печенье",
    "flower" to "Цветок",
    "scallop" to "Волна",
    "clover" to "Клевер",
    "pentagon" to "Пятиугольник",
    "hexagon" to "Шестиугольник",
    "octagon" to "Восьмиугольник",
    "diamond" to "Ромб",
    "triangle" to "Треугольник",
    "star" to "Звезда",
    "sun" to "Солнце",
    "daisy" to "Ромашка",
    "cloud" to "Облако",
    "arch" to "Арка",
    "leaf" to "Лист",
    "custom" to "Своя"
)

private val shapeCache = HashMap<String, Shape>()

/** Квадрат и своя форма зависят от настроек, поэтому в общий кэш не попадают (читают prefs прямо при вызове). */
fun shapeOf(name: String): Shape = when (name) {
    "square" -> RoundedCornerShape(prefs.squareCorner.coerceIn(0, 50))
    "custom" -> customShapeOf(prefs.customShape)
    else -> cachedShape(name)
}

private fun cachedShape(name: String): Shape = shapeCache.getOrPut(name) {
    when (name) {
        "circle" -> CircleShape
        "squircle" -> RoundedCornerShape(35)
        "rounded" -> RoundedCornerShape(22)
        "teardrop" -> RoundedCornerShape(
            topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 8, bottomStartPercent = 50
        )
        "cookie" -> PolyShape(RoundedPolygon.star(10, 1f, 0.87f, CornerRounding(0.55f)))
        "flower" -> PolyShape(RoundedPolygon.star(8, 1f, 0.72f, CornerRounding(0.4f)))
        "scallop" -> PolyShape(RoundedPolygon.star(12, 1f, 0.9f, CornerRounding(0.6f)))
        "clover" -> PolyShape(RoundedPolygon.star(4, 1f, 0.6f, CornerRounding(0.5f)))
        "pentagon" -> PolyShape(RoundedPolygon(5, rounding = CornerRounding(0.2f)))
        "hexagon" -> PolyShape(RoundedPolygon(6, rounding = CornerRounding(0.2f)))
        "octagon" -> PolyShape(RoundedPolygon(8, rounding = CornerRounding(0.18f)))
        "diamond" -> PolyShape(RoundedPolygon(4, rounding = CornerRounding(0.34f)))
        "triangle" -> PolyShape(RoundedPolygon(3, rounding = CornerRounding(0.34f)), -90f)
        "star" -> PolyShape(RoundedPolygon.star(5, 1f, 0.58f, CornerRounding(0.2f)), -90f)
        "sun" -> PolyShape(RoundedPolygon.star(8, 1f, 0.78f, CornerRounding(0.2f)))
        "daisy" -> PolyShape(RoundedPolygon.star(6, 1f, 0.62f, CornerRounding(0.5f)))
        "cloud" -> PolyShape(RoundedPolygon.star(7, 1f, 0.84f, CornerRounding(0.65f)))
        "arch" -> RoundedCornerShape(
            topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 14, bottomStartPercent = 14
        )
        "leaf" -> RoundedCornerShape(
            topStartPercent = 50, topEndPercent = 10, bottomEndPercent = 50, bottomStartPercent = 10
        )
        else -> CircleShape
    }
}
