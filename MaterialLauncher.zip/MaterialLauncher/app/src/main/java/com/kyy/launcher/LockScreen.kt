package com.kyy.launcher

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ───────────────────────── снимок обоев (для размытия под доком) ─────────────────────────

/**
 * Копия системных обоев для размытия под доком. Обычное приложение может не иметь права читать обои
 * (зависит от версии Android и от того, живые ли обои), тогда вернётся null и размытие просто не рисуется.
 */
object WallSnap {
    private var cached: Bitmap? = null
    private var stamp = -1

    fun get(ctx: android.content.Context, version: Int): Bitmap? {
        if (stamp == version) return cached
        stamp = version
        cached = try {
            val wm = WallpaperManager.getInstance(ctx)
            val d = (wm.peekDrawable() ?: wm.drawable) as? BitmapDrawable
            val b = d?.bitmap
            if (b == null) null else {
                // для размытия хватает маленькой копии
                val k = minOf(1f, 540f / maxOf(b.width, b.height))
                if (k < 1f) Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true) else b
            }
        } catch (_: Throwable) { null }
        return cached
    }
}

// ───────────────────────── экран блокировки ─────────────────────────

private val lockShadow = TextStyle(shadow = Shadow(Color.Black.copy(.35f), blurRadius = 10f))

/** Часы как на Google Pixel: цифры столбиком (или в строку), под ними дата. */
@Composable
fun LockClock(unit: Dp, scale: Float, stacked: Boolean, showDate: Boolean) {
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - value % 60_000L + 30L)
        }
    }
    val is24 = DateFormat.is24HourFormat(ctx)
    val hh = SimpleDateFormat(if (is24) "HH" else "h", Locale.getDefault()).format(Date(now))
    val mm = SimpleDateFormat("mm", Locale.getDefault()).format(Date(now))
    val date = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date(now)).replaceFirstChar { it.uppercase() }
    val big = with(LocalDensity.current) { (unit * (if (stacked) 124f else 84f) * scale).toSp() }
    val small = with(LocalDensity.current) { (unit * 18f * scale).toSp() }
    val w = if (stacked) FontWeight.Black else FontWeight.ExtraBold
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (stacked) {
            Text(hh, fontSize = big, lineHeight = big * 0.86f, fontWeight = w, color = Color.White, style = lockShadow, textAlign = TextAlign.Center)
            Text(mm, fontSize = big, lineHeight = big * 0.86f, fontWeight = w, color = Color.White, style = lockShadow, textAlign = TextAlign.Center)
        } else {
            Text("$hh:$mm", fontSize = big, fontWeight = w, color = Color.White, style = lockShadow)
        }
        if (showDate) {
            Text(date, fontSize = small, fontWeight = FontWeight.Medium, color = Color.White.copy(alpha = .92f), style = lockShadow,
                modifier = Modifier.padding(top = (4f * scale).dp))
        }
    }
}

/** Рисует отпечаток пальца дугами (как значок на Pixel). */
@Composable
fun FingerprintGlyph(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = size.minDimension / 2f
        val sw = r * 0.085f
        // (радиус в долях, начальный угол, размах): дуги разной длины, раскрытые вниз и в стороны
        val arcs = listOf(
            Triple(0.16f, -90f - 150f, 300f),
            Triple(0.34f, -90f - 135f, 270f),
            Triple(0.52f, -90f - 118f, 236f),
            Triple(0.70f, -90f - 100f, 200f),
            Triple(0.88f, -90f - 78f, 156f)
        )
        arcs.forEach { (k, start, sweep) ->
            drawArc(color, start, sweep, false, Offset(c.x - r * k, c.y - r * k), Size(r * k * 2f, r * k * 2f),
                style = Stroke(sw, cap = StrokeCap.Round))
        }
        // короткие «гребни» внизу
        drawArc(color, 62f, 36f, false, Offset(c.x - r * 0.52f, c.y - r * 0.52f), Size(r * 1.04f, r * 1.04f), style = Stroke(sw, cap = StrokeCap.Round))
        drawLine(color, Offset(c.x, c.y - r * 0.06f), Offset(c.x, c.y + r * 0.30f), sw, StrokeCap.Round)
    }
}

/**
 * Виртуальный датчик отпечатка: прижмите и подержите — по кругу идёт сканирование, затем открывается рабочий стол.
 * Это только картинка: настоящий отпечаток приложение не читает.
 */
@Composable
fun FingerprintButton(scanMs: Int, interactive: Boolean, size: Dp, onSuccess: () -> Unit) {
    val s = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val prog = remember { Animatable(0f) }
    var done by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    val glow = s.primary
    Box(
        Modifier.size(size)
            .graphicsLayer { val k = if (pressed) 1.07f else 1f; scaleX = k; scaleY = k }
            .then(
                if (interactive) Modifier.pointerInput(scanMs) {
                    detectTapGestures(onPress = {
                        if (!done) {
                            pressed = true
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            val job = scope.launch {
                                prog.animateTo(1f, tween(scanMs.coerceAtLeast(1), easing = LinearEasing))
                                if (!done) {
                                    done = true
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    delay(140)
                                    onSuccess()
                                }
                            }
                            tryAwaitRelease()
                            pressed = false
                            if (!done) { job.cancel(); scope.launch { prog.animateTo(0f, tween(180)) } }
                        }
                    })
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().clip(CircleShape).background(Color.Black.copy(alpha = if (pressed) .55f else .4f)))
        Canvas(Modifier.fillMaxSize()) {
            val st = 3.dp.toPx()
            drawCircle(Color.White.copy(alpha = .35f), radius = this.size.minDimension / 2f - st / 2f, style = Stroke(st))
            if (prog.value > 0f) {
                drawArc(glow, -90f, 360f * prog.value, false, Offset(st / 2f, st / 2f),
                    Size(this.size.width - st, this.size.height - st), style = Stroke(st, cap = StrokeCap.Round))
            }
        }
        val tint = androidx.compose.ui.graphics.lerp(Color.White, glow, prog.value.coerceIn(0f, 1f))
        FingerprintGlyph(tint, Modifier.size(size * 0.56f))
    }
}

/**
 * Содержимое экрана блокировки. Одно и то же рисуется на самом экране и в предпросмотре в настройках:
 * размеры считаются от ширины (360 dp = 1), поэтому положение и размер часов совпадают.
 */
@Composable
fun LockContent(
    modifier: Modifier = Modifier,
    interactive: Boolean,
    onUnlock: () -> Unit = {}
) {
    BoxWithConstraints(modifier) {
        val unit = maxWidth / 360f
        val x = prefs.lockClockX / 1000f
        val y = prefs.lockClockY / 1000f
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(.32f), Color.Transparent, Color.Black.copy(.45f))))
        )
        Box(
            Modifier
                .layout { m, c ->
                    val p = m.measure(Constraints())
                    layout(c.maxWidth, c.maxHeight) {
                        p.place((c.maxWidth * x - p.width / 2f).roundToInt(), (c.maxHeight * y - p.height / 2f).roundToInt())
                    }
                }
        ) {
            LockClock(unit, prefs.lockClockScale / 100f, prefs.lockClockStyle == "stack", prefs.lockDate)
        }
        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = unit * 56f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Коснитесь датчика или проведите вверх", color = Color.White.copy(alpha = .9f), style = lockShadow,
                fontSize = with(LocalDensity.current) { (unit * 13f).toSp() }
            )
            Spacer(Modifier.height(unit * 14f))
            FingerprintButton(prefs.lockScanMs, interactive, unit * 76f, onUnlock)
        }
    }
}

/** Экран поверх рабочего стола; закрывается по «отпечатку» или свайпом вверх. Анимация разблокировки играет только после этого. */
@Composable
fun LockScreen(onUnlock: () -> Unit) {
    BackHandler(true) {}   // «назад» экран блокировки не закрывает
    val scope = rememberCoroutineScope()
    val off = remember { Animatable(0f) }
    var unlocked by remember { mutableStateOf(false) }
    val thr = with(LocalDensity.current) { 120.dp.toPx() }
    val fire = { if (!unlocked) { unlocked = true; onUnlock() } }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(thr) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (off.value < -thr) fire() else scope.launch { off.animateTo(0f, tween(220)) }
                    },
                    onDragCancel = { scope.launch { off.animateTo(0f, tween(220)) } }
                ) { change, delta ->
                    change.consume()
                    scope.launch { off.snapTo((off.value + delta).coerceAtMost(0f)) }
                }
            }
    ) {
        LockContent(
            Modifier.fillMaxSize().graphicsLayer {
                translationY = off.value
                alpha = (1f + off.value / (size.height * 0.6f)).coerceIn(0.35f, 1f)
            },
            interactive = true, onUnlock = { fire() }
        )
    }
}

/**
 * Предпросмотр для настроек: часы можно тащить пальцем и растягивать щипком, всё сохраняется сразу.
 */
@Composable
fun LockPreview(modifier: Modifier = Modifier) {
    var w by remember { mutableFloatStateOf(1f) }
    var h by remember { mutableFloatStateOf(1f) }
    val s = MaterialTheme.colorScheme
    Box(
        modifier.clip(rc(28))
            .background(Brush.linearGradient(listOf(androidx.compose.ui.graphics.lerp(s.primary, Color.Black, .55f), s.tertiary)))
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f); h = it.height.toFloat().coerceAtLeast(1f) }
            // тянем пальцем — часы едут, щипок — размер
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    prefs.lockClockX = (prefs.lockClockX + pan.x / w * 1000f).roundToInt().coerceIn(0, 1000)
                    prefs.lockClockY = (prefs.lockClockY + pan.y / h * 1000f).roundToInt().coerceIn(0, 1000)
                    prefs.lockClockScale = (prefs.lockClockScale * zoom).roundToInt().coerceIn(30, 300)
                }
            }
    ) {
        LockContent(Modifier.fillMaxSize(), interactive = false)
    }
}

/** Размытая копия обоев под плашкой дока (если обои удалось прочитать). */
@Composable
fun DockBlurBackdrop(modifier: Modifier, boundsLeft: Float, boundsTop: Float, radiusPct: Int, version: Int) {
    if (radiusPct <= 0 || Build.VERSION.SDK_INT < 31) return
    val ctx = LocalContext.current
    val dm = ctx.resources.displayMetrics
    val bmp = remember(version) { WallSnap.get(ctx, version) } ?: return
    val d = LocalDensity.current
    val r = 40f * d.density * radiusPct / 100f
    Image(
        bmp.asImageBitmap(), null,
        modifier = modifier
            .wrapContentSize(unbounded = true, align = Alignment.TopStart)
            .requiredSize(with(d) { dm.widthPixels.toDp() }, with(d) { dm.heightPixels.toDp() })
            .offset { IntOffset(-boundsLeft.roundToInt(), -boundsTop.roundToInt()) }
            .graphicsLayer { renderEffect = BlurEffect(r, r, TileMode.Clamp) },
        contentScale = ContentScale.Crop
    )
}
