package com.kyy.launcher

import android.app.AlarmManager
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ───────────────────────── снимок обоев (для размытия под доком) ─────────────────────────

/**
 * Копия системных обоев для размытия под доком. Обычное приложение может не иметь права читать обои
 * (зависит от версии Android и от того, живые ли обои), тогда вернётся null и размытие просто не рисуется.
 */
object WallSnap {
    private var cached: Bitmap? = null
    private var stamp = -1

    fun get(ctx: android.content.Context, version: Int): Bitmap? {
        if (stamp == version) return cached
        stamp = version
        cached = try {
            val wm = WallpaperManager.getInstance(ctx)
            val d = (wm.peekDrawable() ?: wm.drawable) as? BitmapDrawable
            val b = d?.bitmap
            if (b == null) null else {
                // для размытия хватает маленькой копии
                val k = minOf(1f, 540f / maxOf(b.width, b.height))
                if (k < 1f) Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true) else b
            }
        } catch (_: Throwable) { null }
        return cached
    }
}

// ───────────────────────── экран блокировки ─────────────────────────

private val lockShadow = TextStyle(shadow = Shadow(Color.Black.copy(.35f), blurRadius = 10f))

private val DOT_GLYPHS = mapOf(
    '0' to "01110 10001 10011 10101 11001 10001 01110",
    '1' to "00100 01100 00100 00100 00100 00100 01110",
    '2' to "01110 10001 00001 00010 00100 01000 11111",
    '3' to "11110 00001 00001 01110 00001 00001 11110",
    '4' to "00010 00110 01010 10010 11111 00010 00010",
    '5' to "11111 10000 11110 00001 00001 10001 01110",
    '6' to "00110 01000 10000 11110 10001 10001 01110",
    '7' to "11111 00001 00010 00100 01000 01000 01000",
    '8' to "01110 10001 10001 01110 10001 10001 01110",
    '9' to "01110 10001 10001 01111 00001 00010 01100",
    ':' to "0 0 1 0 1 0 0"
)

/** Цифры из точек (матрица 5×7). size — как размер шрифта: высота цифры 0,72 от него, высота блока 1,17, как у строки текста. */
@Composable
fun DotText(text: String, size: Dp, color: Color, shadow: Boolean, modifier: Modifier = Modifier) {
    val cols: Int = text.map { if (it == ':') 1 else 5 }.sum() + (text.length - 1).coerceAtLeast(0)
    val digitH = size * 0.72f
    val cell = digitH / 7f
    Canvas(modifier.size(cell * cols.toFloat(), size * 1.17f)) {
        val c = cell.toPx()
        val r = c * 0.40f
        var x0 = 0f
        val top = (this.size.height - c * 7f) / 2f
        text.forEach { ch ->
            val rows = (DOT_GLYPHS[ch] ?: "").split(" ")
            val w = if (ch == ':') 1 else 5
            rows.forEachIndexed { ry, row ->
                row.forEachIndexed { cx, bit ->
                    if (bit == '1') {
                        val o = Offset(x0 + (cx + .5f) * c, top + (ry + .5f) * c)
                        if (shadow) drawCircle(Color.Black.copy(.3f), r, o + Offset(0f, c * .12f))
                        drawCircle(color, r, o)
                    }
                }
            }
            x0 += (w + 1) * c
        }
    }
}

/** Текст часов в выбранном стиле: обычный шрифт, контур или точки. */
/** Контур одной цифры для растяжимых часов. Толщина линии задаётся при рисовании, поэтому при росте высоты h линия не тоньшает и не толстеет. */
private fun digitPath(ch: Char, x: Float, y: Float, w: Float, h: Float): androidx.compose.ui.graphics.Path? {
    val p = androidx.compose.ui.graphics.Path()
    fun r(l: Float, t: Float, rr: Float, b: Float) = androidx.compose.ui.geometry.Rect(x + l, y + t, x + rr, y + b)
    fun m(px: Float, py: Float) = p.moveTo(x + px, y + py)
    fun l(px: Float, py: Float) = p.lineTo(x + px, y + py)
    when (ch) {
        '0' -> p.addRoundRect(androidx.compose.ui.geometry.RoundRect(r(0f, 0f, w, h), CornerRadius(w / 2f)))
        '1' -> { m(0.08f * w, 0.4f * w); l(0.5f * w, 0f); l(0.5f * w, h) }
        '2' -> {
            m(0f, 0.5f * w)
            p.arcTo(r(0f, 0f, w, w), 180f, 180f, false)
            l(0f, h); l(w, h)
        }
        '3' -> {
            p.arcTo(r(0f, 0f, w, h * 0.5f), -160f, 250f, true)
            p.arcTo(r(0f, h * 0.5f, w, h), -90f, 250f, false)
        }
        '4' -> { m(0.72f * w, h); l(0.72f * w, 0f); l(0f, h - 0.45f * w); l(w, h - 0.45f * w) }
        '5' -> {
            m(0.92f * w, 0f); l(0.12f * w, 0f); l(0.08f * w, 0.44f * h)
            p.arcTo(r(0f, 0.36f * h, w, h), -145f, 290f, false)
        }
        '6' -> {
            m(0.82f * w, 0.02f * h)
            p.cubicTo(x + 0.15f * w, y + 0.1f * h, x, y + 0.35f * h, x, y + 0.71f * h)
            p.addOval(r(0f, 0.42f * h, w, h))
        }
        '7' -> { m(0f, 0f); l(w, 0f); l(0.3f * w, h) }
        '8' -> {
            p.addOval(r(0.08f * w, 0f, 0.92f * w, 0.52f * h))
            p.addOval(r(0f, 0.48f * h, w, h))
        }
        '9' -> {
            m(0.18f * w, 0.98f * h)
            p.cubicTo(x + 0.85f * w, y + 0.9f * h, x + w, y + 0.65f * h, x + w, y + 0.29f * h)
            p.addOval(r(0f, 0f, w, 0.58f * h))
        }
        else -> return null
    }
    return p
}

/**
 * Растяжимые часы как на iOS 26: цифры нарисованы линией одной толщины с круглыми концами, поэтому при растяжении
 * растёт только высота, а толщина линий остаётся прежней. Обычный шрифт так растянуть нельзя: его штрихи расплываются.
 */
@Composable
fun StretchText(text: String, size: Dp, stretch: Float, color: Color, shadow: Boolean, gap: Float, modifier: Modifier = Modifier) {
    val h0 = size * 0.72f
    val w = h0 * 0.62f
    val sw = w * 0.2f
    val gapX = w * 0.28f
    val colonW = sw * 1.6f
    val totalW = text.fold(0.dp) { acc, c -> acc + (if (c == ':') colonW else w) } + gapX * (text.length - 1).coerceAtLeast(0) + sw
    val hh = h0 * stretch
    val totalH = hh + sw + size * 0.45f * gap
    Canvas(modifier.size(totalW, totalH)) {
        val swp = sw.toPx()
        val wp = w.toPx()
        val gp = gapX.toPx()
        val hp = hh.toPx()
        val top = (this.size.height - hp) / 2f
        val st = Stroke(swp, cap = StrokeCap.Round, join = StrokeJoin.Round)
        var x = swp / 2f
        text.forEach { ch ->
            if (ch == ':') {
                val cx = x + colonW.toPx() / 2f
                for (f in floatArrayOf(0.33f, 0.67f)) {
                    val o = Offset(cx, top + hp * f)
                    if (shadow) drawCircle(Color.Black.copy(.3f), swp * 0.65f, o + Offset(0f, swp * .15f))
                    drawCircle(color, swp * 0.65f, o)
                }
                x += colonW.toPx() + gp
            } else {
                if (shadow) digitPath(ch, x, top + swp * .15f, wp, hp)?.let { drawPath(it, Color.Black.copy(.3f), style = st) }
                digitPath(ch, x, top, wp, hp)?.let { drawPath(it, color, style = st) }
                x += wp + gp
            }
        }
    }
}

@Composable
fun ClockText(
    cf: ClockFont, text: String, size: Dp, weight: FontWeight, color: Color, shadow: Boolean, modifier: Modifier = Modifier,
    stretch: Float = 1f, gap: Float = 0.7f
) {
    if (cf.kind == "stretch") { StretchText(text, size, stretch, color, shadow, gap, modifier); return }
    if (cf.kind == "dots") { DotText(text, size, color, shadow, modifier); return }
    val d = LocalDensity.current
    val base = if (shadow) lockShadow else TextStyle.Default
    val st = if (cf.kind == "outline") base.copy(
        drawStyle = Stroke(with(d) { (size.value * 0.03f).dp.toPx() }.coerceAtLeast(1f), join = StrokeJoin.Round)
    ) else base
    Text(
        text, fontSize = with(d) { size.toSp() }, fontWeight = weight, fontFamily = cf.family,
        color = color, style = st, textAlign = TextAlign.Center, modifier = modifier
    )
}

/** Часы как на Google Pixel: цифры столбиком (или в строку), под ними дата. */
@Composable
fun LockClock(
    unit: Dp, scale: Float, stacked: Boolean, showDate: Boolean, gap: Float = 0.7f, fontId: String = "theme",
    stretch: Float = 1f,
    /** не null — под цифрами рисуется полоска, которую тянут вниз, чтобы растянуть часы по высоте (только в предпросмотре) */
    onStretchDrag: ((Float) -> Unit)? = null
) {
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - value % 60_000L + 30L)
        }
    }
    val is24 = DateFormat.is24HourFormat(ctx)
    val hh = SimpleDateFormat(if (is24) "HH" else "h", Locale.getDefault()).format(Date(now))
    val mm = SimpleDateFormat("mm", Locale.getDefault()).format(Date(now))
    val date = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date(now)).replaceFirstChar { it.uppercase() }
    val big = unit * (if (stacked) 124f else 84f) * scale
    val small = with(LocalDensity.current) { (unit * 18f * scale).toSp() }
    val cf = LockClockFonts.resolve(fontId)
    // у системных гарнитур жирность зашита в сам шрифт, поэтому вес задаём только для шрифта приложения
    val w = if (cf.family != null) FontWeight.Normal else if (stacked) FontWeight.Black else FontWeight.ExtraBold
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // растягивается только шрифт «Растяжимый» (kind = stretch): высота его цифр растёт, дата и виджеты уезжают ниже
        val stretchy = cf.kind == "stretch"
        val st = if (stretchy) stretch else 1f
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (stacked) {
                // высота каждой строки урезается до доли gap, а цифры остаются по центру: так можно сжать расстояние между ними
                val tight = if (stretchy) Modifier else Modifier.layout { m, c ->
                    val p = m.measure(c)
                    val hh2 = (p.height * gap).roundToInt()
                    layout(p.width, hh2) { p.place(0, (hh2 - p.height) / 2) }
                }
                ClockText(cf, hh, big, w, Color.White, true, tight, st, gap)
                ClockText(cf, mm, big, w, Color.White, true, tight, st, gap)
            } else {
                ClockText(cf, "$hh:$mm", big, w, Color.White, true, Modifier, st, gap)
            }
        }
        if (onStretchDrag != null && stretchy) {
            Box(
                Modifier.padding(top = (4f * scale).dp).size(width = unit * 64f, height = unit * 24f)
                    .pointerInput(Unit) {
                        detectVerticalDragGestures { change, dy -> change.consume(); onStretchDrag(dy) }
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(width = unit * 44f, height = unit * 6f).clip(CircleShape).background(Color.White.copy(alpha = .85f)))
            }
        }
        if (showDate) {
            Text(date, fontSize = small, fontWeight = FontWeight.Medium, color = Color.White.copy(alpha = .92f), style = lockShadow,
                modifier = Modifier.padding(top = (4f * scale).dp))
        }
        LockWidgets(unit, scale)
    }
}

// ───────────────────────── виджеты и ярлыки ─────────────────────────

private fun readBattery(i: Intent?): Pair<Int, Boolean> {
    if (i == null) return 0 to false
    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
    val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    return (if (level < 0) 0 else level * 100 / scale) to charging
}

@Composable
private fun rememberBattery(): State<Pair<Int, Boolean>> {
    val ctx = LocalContext.current
    val st = remember { mutableStateOf(readBattery(ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))) }
    DisposableEffect(ctx) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { st.value = readBattery(i) }
        }
        ContextCompat.registerReceiver(ctx, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { try { ctx.unregisterReceiver(r) } catch (_: Throwable) {} }
    }
    return st
}

@Composable
private fun rememberNextAlarm(): State<String?> {
    val ctx = LocalContext.current
    return produceState<String?>(null) {
        while (true) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            val t = try { am?.nextAlarmClock?.triggerTime } catch (_: Throwable) { null }
            value = if (t == null) null else {
                val pattern = if (DateFormat.is24HourFormat(ctx)) "EEE HH:mm" else "EEE h:mm a"
                SimpleDateFormat(pattern, Locale.getDefault()).format(Date(t)).replaceFirstChar { it.uppercase() }
            }
            delay(30_000L)
        }
    }
}

/** Иконки виджетов в одном стиле (линия 1,9 на сетке 24): батарея, будильник, фонарик, камера. */
@Composable
private fun LockGlyph(
    kind: String, color: Color, modifier: Modifier = Modifier,
    level: Int = 100, charging: Boolean = false, cut: Color = Color.Transparent
) {
    Canvas(modifier) {
        val k = size.minDimension / 24f
        fun p(x: Float, y: Float) = Offset(x * k, y * k)
        val st = Stroke(1.9f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            "battery" -> {
                drawRoundRect(color, p(2f, 7f), Size(18f * k, 10f * k), CornerRadius(2.6f * k), style = st)
                drawRoundRect(color, p(21f, 10.4f), Size(1.8f * k, 3.2f * k), CornerRadius(0.9f * k))
                val w = (12.8f * k * level.coerceIn(0, 100) / 100f).coerceAtLeast(1.6f * k)
                drawRoundRect(color, p(4.6f, 9.6f), Size(w, 4.8f * k), CornerRadius(1f * k))
                if (charging) {
                    val bolt = androidx.compose.ui.graphics.Path().apply {
                        moveTo(11.8f * k, 8.2f * k); lineTo(8.4f * k, 12.4f * k); lineTo(11f * k, 12.4f * k)
                        lineTo(10.2f * k, 15.9f * k); lineTo(13.8f * k, 11.4f * k); lineTo(11.2f * k, 11.4f * k); close()
                    }
                    drawPath(bolt, cut, style = Stroke(2.6f * k, join = StrokeJoin.Round))
                    drawPath(bolt, color)
                }
            }
            "alarm" -> {
                drawCircle(color, 7f * k, p(12f, 13.2f), style = st)
                val hands = androidx.compose.ui.graphics.Path().apply {
                    moveTo(12f * k, 9.6f * k); lineTo(12f * k, 13.2f * k); lineTo(14.6f * k, 14.8f * k)
                }
                drawPath(hands, color, style = st)
                drawLine(color, p(3.6f, 7.2f), p(6.8f, 3.8f), 1.9f * k, StrokeCap.Round)
                drawLine(color, p(20.4f, 7.2f), p(17.2f, 3.8f), 1.9f * k, StrokeCap.Round)
            }
            "torch" -> {
                val body = androidx.compose.ui.graphics.Path().apply {
                    moveTo(8f * k, 2.6f * k); lineTo(16f * k, 2.6f * k); lineTo(16f * k, 6.6f * k); lineTo(14f * k, 9f * k)
                    lineTo(14f * k, 21.2f * k); lineTo(10f * k, 21.2f * k); lineTo(10f * k, 9f * k); lineTo(8f * k, 6.6f * k); close()
                }
                drawPath(body, color, style = st)
                drawLine(color, p(12f, 12.4f), p(12f, 15.4f), 1.9f * k, StrokeCap.Round)
            }
            "camera" -> {
                drawRoundRect(color, p(2.6f, 6.8f), Size(18.8f * k, 13f * k), CornerRadius(3.2f * k), style = st)
                val hump = androidx.compose.ui.graphics.Path().apply {
                    moveTo(8.2f * k, 6.8f * k); lineTo(9.4f * k, 4.2f * k); lineTo(14.6f * k, 4.2f * k); lineTo(15.8f * k, 6.8f * k)
                }
                drawPath(hump, color, style = st)
                drawCircle(color, 3.6f * k, p(12f, 13.3f), style = st)
            }
        }
    }
}

/** Плашка виджета в стиле Material You: тональный контейнер темы, значок и текст цвета «на контейнере». */
@Composable
private fun LockPill(kind: String, text: String, unit: Dp, scale: Float, level: Int = 100, charging: Boolean = false) {
    val s = MaterialTheme.colorScheme
    Row(
        Modifier.clip(CircleShape).background(s.secondaryContainer)
            .padding(start = unit * 10f * scale, end = unit * 13f * scale, top = unit * 6f * scale, bottom = unit * 6f * scale),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LockGlyph(kind, s.onSecondaryContainer, Modifier.size(unit * 18f * scale), level, charging, s.secondaryContainer)
        Spacer(Modifier.width(unit * 6f * scale))
        Text(
            text, color = s.onSecondaryContainer, fontWeight = FontWeight.Medium, maxLines = 1,
            fontSize = with(LocalDensity.current) { (unit * 13f * scale).toSp() }
        )
    }
}

/** Строка виджетов под датой: заряд батареи и ближайший будильник (включаются в настройках). */
@Composable
fun LockWidgets(unit: Dp, scale: Float) {
    val showB = prefs.lockWBattery
    val showA = prefs.lockWAlarm
    if (!showB && !showA) return
    val bat by rememberBattery()
    val alarm by rememberNextAlarm()
    Row(
        Modifier.padding(top = unit * 10f * scale),
        horizontalArrangement = Arrangement.spacedBy(unit * 8f * scale),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (showB) LockPill("battery", "${bat.first}%", unit, scale, bat.first, bat.second)
        if (showA) LockPill("alarm", alarm ?: "Нет будильника", unit, scale)
    }
}

/** Фонарик: включается без разрешений, состояние берём у системы. */
object Torch {
    var on by mutableStateOf(false)
    private var registered = false

    private fun cm(ctx: Context) = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private fun cameraId(ctx: Context): String? = try {
        val m = cm(ctx)
        m.cameraIdList.firstOrNull {
            val ch = m.getCameraCharacteristics(it)
            ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    } catch (_: Throwable) { null }

    fun ensure(ctx: Context) {
        if (registered) return
        try {
            cm(ctx).registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { on = enabled }
            }, null)
            registered = true
        } catch (_: Throwable) {}
    }

    fun toggle(ctx: Context) {
        val id = cameraId(ctx) ?: return
        ensure(ctx)
        try { cm(ctx).setTorchMode(id, !on) } catch (_: Throwable) {}
    }
}

fun openCamera(ctx: Context) {
    try { ctx.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
}

/** Кнопка в углу в стиле Material You: скруглённый квадрат; у включённого фонарика цвет акцента. */
@Composable
private fun LockShortcut(kind: String, active: Boolean, unit: Dp, interactive: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val s = MaterialTheme.colorScheme
    val bg = if (active) s.primary else s.secondaryContainer
    val fg = if (active) s.onPrimary else s.onSecondaryContainer
    Box(
        modifier.size(unit * 56f).clip(RoundedCornerShape(unit * 20f * (prefs.corner / 100f).coerceAtLeast(0.3f)))
            .background(bg)
            .then(if (interactive) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        LockGlyph(kind, fg, Modifier.size(unit * 26f))
    }
}

/**
 * Значок отпечатка в духе Google Pixel: вложенные дуги-«арки» с обрывами и ножками разной длины, внутри волнистая жилка.
 */
@Composable
fun FingerprintGlyph(color: Color, modifier: Modifier = Modifier, style: String = prefs.lockFpStyle) {
    Canvas(modifier) {
        val r = size.minDimension / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        val sw = r * 0.075f
        val st = Stroke(sw, cap = StrokeCap.Round)
        if (style == "rings") {
            // концентрические дуги с разрывами в разных местах и точка в центре
            val ring = Stroke(sw * 1.15f, cap = StrokeCap.Round)
            val ks = floatArrayOf(0.22f, 0.42f, 0.62f, 0.82f)
            val starts = floatArrayOf(-60f, 20f, -130f, 100f)
            val sweeps = floatArrayOf(320f, 290f, 300f, 270f)
            ks.forEachIndexed { i, k ->
                val rr = r * k
                drawArc(color, starts[i], sweeps[i], false, Offset(c.x - rr, c.y - rr), Size(rr * 2f, rr * 2f), style = ring)
            }
            drawCircle(color, r * 0.07f, c)
            return@Canvas
        }
        if (style == "spiral") {
            // завиток: спираль, чуть вытянутая по вертикали, как подушечка пальца
            val path = androidx.compose.ui.graphics.Path()
            val steps = 400
            for (i in 0..steps) {
                val t = i / steps.toFloat()
                val ang = t * 4.2f * 2f * Math.PI.toFloat()
                val rad = r * (0.06f + 0.78f * t)
                val x = c.x + rad * kotlin.math.cos(ang)
                val y = c.y + rad * 1.14f * kotlin.math.sin(ang)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color, style = Stroke(sw * 1.1f, cap = StrokeCap.Round))
            return@Canvas
        }
        val dash = Stroke(sw, cap = StrokeCap.Round, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(r * 0.20f, r * 0.09f)))
        fun arch(k: Float, leg: Float, style: Stroke) {
            val rr = r * k
            val p = androidx.compose.ui.graphics.Path().apply {
                moveTo(c.x - rr, c.y + r * leg)
                lineTo(c.x - rr, c.y)
                arcTo(androidx.compose.ui.geometry.Rect(c.x - rr, c.y - rr, c.x + rr, c.y + rr), 180f, 180f, false)
                lineTo(c.x + rr, c.y + r * leg)
            }
            drawPath(p, color, style = style)
        }
        // от внутренней к внешней: радиус, длина ножек вниз
        arch(0.17f, 0.10f, st)
        arch(0.34f, 0.40f, st)
        arch(0.51f, 0.62f, dash)
        arch(0.68f, 0.52f, st)
        arch(0.85f, 0.30f, dash)
        // центральная жилка
        val v = androidx.compose.ui.graphics.Path().apply {
            moveTo(c.x, c.y - r * 0.02f)
            cubicTo(c.x + r * 0.10f, c.y + r * 0.18f, c.x - r * 0.10f, c.y + r * 0.40f, c.x, c.y + r * 0.62f)
        }
        drawPath(v, color, style = st)
    }
}

/** Загрузка своей картинки для отпечатка: уменьшаем, учитываем поворот из EXIF, сохраняем в приложении. */
fun saveFingerprintImage(ctx: android.content.Context, uri: android.net.Uri): Boolean = try {
    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
    var sample = 1
    while (o.outWidth / (sample * 2) >= 512 && o.outHeight / (sample * 2) >= 512) sample *= 2
    val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
    var bmp = ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) }
        ?: throw IllegalStateException("decode")
    val k = minOf(1f, 512f / maxOf(bmp.width, bmp.height))
    if (k < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
    val deg = try {
        ctx.contentResolver.openInputStream(uri)?.use {
            when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
            }
        } ?: 0f
    } catch (_: Throwable) { 0f }
    if (deg != 0f) {
        val m = android.graphics.Matrix().apply { postRotate(deg) }
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
    java.io.File(ctx.filesDir, "lock_fp.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    prefs.lockFpImage = System.currentTimeMillis().toString()
    true
} catch (_: Throwable) { false }

fun removeFingerprintImage(ctx: android.content.Context) {
    java.io.File(ctx.filesDir, "lock_fp.png").delete()
    prefs.lockFpImage = ""
}

/**
 * Виртуальный датчик отпечатка: прижмите и подержите — по кругу идёт сканирование, затем открывается рабочий стол.
 * Это только картинка: настоящий отпечаток приложение не читает.
 */
@Composable
fun FingerprintButton(scanMs: Int, interactive: Boolean, size: Dp, onSuccess: () -> Unit) {
    val s = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val prog = remember { Animatable(0f) }
    var done by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    val glow = s.primary
    val ctx = LocalContext.current
    val stamp = prefs.lockFpImage
    val img = remember(stamp) {
        if (stamp.isEmpty()) null
        else try { android.graphics.BitmapFactory.decodeFile(java.io.File(ctx.filesDir, "lock_fp.png").path)?.asImageBitmap() } catch (_: Throwable) { null }
    }
    val fill = prefs.lockFpFit != "fit"
    Box(
        Modifier.size(size)
            .graphicsLayer { val k = if (pressed) 1.07f else 1f; scaleX = k; scaleY = k }
            .then(
                if (interactive) Modifier.pointerInput(scanMs) {
                    detectTapGestures(onPress = {
                        if (!done) {
                            pressed = true
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            val job = scope.launch {
                                prog.animateTo(1f, tween(scanMs.coerceAtLeast(1), easing = LinearEasing))
                                if (!done) {
                                    done = true
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    delay(140)
                                    onSuccess()
                                }
                            }
                            tryAwaitRelease()
                            pressed = false
                            if (!done) { job.cancel(); scope.launch { prog.animateTo(0f, tween(180)) } }
                        }
                    })
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        if (img == null || !fill) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(Color.Black.copy(alpha = if (pressed) .55f else .4f)))
        }
        if (img != null) {
            // своя картинка: «заполнить» обрезает по кругу, «вписать» сжимает целиком внутрь
            if (fill) {
                Image(img, null, Modifier.fillMaxSize().padding(4.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            } else {
                Image(img, null, Modifier.fillMaxSize(0.74f), contentScale = ContentScale.Fit)
            }
        }
        Canvas(Modifier.fillMaxSize()) {
            val st = 3.dp.toPx()
            drawCircle(Color.White.copy(alpha = .35f), radius = this.size.minDimension / 2f - st / 2f, style = Stroke(st))
            if (prog.value > 0f) {
                drawArc(glow, -90f, 360f * prog.value, false, Offset(st / 2f, st / 2f),
                    Size(this.size.width - st, this.size.height - st), style = Stroke(st, cap = StrokeCap.Round))
            }
        }
        if (img == null) {
            val tint = androidx.compose.ui.graphics.lerp(Color.White, glow, prog.value.coerceIn(0f, 1f))
            FingerprintGlyph(tint, Modifier.size(size * 0.56f))
        }
    }
}

/**
 * Содержимое экрана блокировки. Одно и то же рисуется на самом экране и в предпросмотре в настройках:
 * размеры считаются от ширины (360 dp = 1), поэтому положение и размер часов совпадают.
 */
@Composable
fun LockContent(
    modifier: Modifier = Modifier,
    interactive: Boolean,
    onUnlock: () -> Unit = {},
    /** в предпросмотре часов: показывает полоску для растяжения по высоте */
    editClock: Boolean = false
) {
    BoxWithConstraints(modifier) {
        val unit = maxWidth / 360f
        val unitPx = with(LocalDensity.current) { unit.toPx() }.coerceAtLeast(0.1f)
        var stretchAcc by remember { mutableFloatStateOf(0f) }
        // накапливаем дробную часть, иначе медленное движение пальца терялось бы при округлении до процентов
        val onStretch: (Float) -> Unit = { dy ->
            stretchAcc += dy / unitPx * 0.8f
            val whole = stretchAcc.toInt()
            if (whole != 0) {
                prefs.lockClockStretch = (prefs.lockClockStretch + whole).coerceIn(100, 300)
                stretchAcc -= whole
            }
        }
        val x = prefs.lockClockX / 1000f
        val y = prefs.lockClockY / 1000f
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(.32f), Color.Transparent, Color.Black.copy(.45f))))
        )
        Box(
            Modifier
                .layout { m, c ->
                    val p = m.measure(Constraints())
                    layout(c.maxWidth, c.maxHeight) {
                        p.place((c.maxWidth * x - p.width / 2f).roundToInt(), (c.maxHeight * y - p.height / 2f).roundToInt())
                    }
                }
        ) {
            LockClock(
                unit, prefs.lockClockScale / 100f, prefs.lockClockStyle == "stack", prefs.lockDate, prefs.lockClockGap / 100f, prefs.lockClockFont,
                stretch = prefs.lockClockStretch / 100f,
                onStretchDrag = if (editClock) onStretch else null
            )
        }
        // ярлыки в нижних углах
        val sctx = LocalContext.current
        if (prefs.lockTorch) {
            LaunchedEffect(Unit) { Torch.ensure(sctx) }
            LockShortcut("torch", Torch.on, unit, interactive, Modifier.align(Alignment.BottomStart).padding(start = unit * 36f, bottom = unit * 48f)) { Torch.toggle(sctx) }
        }
        if (prefs.lockCamera) {
            LockShortcut("camera", false, unit, interactive, Modifier.align(Alignment.BottomEnd).padding(end = unit * 36f, bottom = unit * 48f)) { openCamera(sctx) }
        }
        // отпечаток: центр значка стоит в точке (lockFpX, lockFpY); подпись, если включена, рисуется над ним
        val fx = prefs.lockFpX / 1000f
        val fy = prefs.lockFpY / 1000f
        val btnPx = with(LocalDensity.current) { (unit * 76f).toPx() }
        Box(
            Modifier.layout { m, c ->
                val p = m.measure(Constraints())
                layout(c.maxWidth, c.maxHeight) {
                    val px = (c.maxWidth * fx - p.width / 2f).roundToInt().coerceIn(0, (c.maxWidth - p.width).coerceAtLeast(0))
                    // значок всегда нижний в колонке, поэтому его центр — на btnPx/2 выше низа колонки
                    val py = (c.maxHeight * fy - (p.height - btnPx / 2f)).roundToInt()
                        .coerceIn(0, (c.maxHeight - p.height).coerceAtLeast(0))
                    p.place(px, py)
                }
            }
        ) {
            Column(Modifier.width(unit * 76f), horizontalAlignment = Alignment.CenterHorizontally) {
                if (prefs.lockHint) {
                    Text(
                        "Коснитесь датчика или проведите вверх", color = Color.White.copy(alpha = .9f), style = lockShadow,
                        fontSize = with(LocalDensity.current) { (unit * 13f).toSp() },
                        textAlign = TextAlign.Center, softWrap = false,
                        modifier = Modifier.wrapContentWidth(unbounded = true)
                    )
                    Spacer(Modifier.height(unit * 14f))
                }
                FingerprintButton(prefs.lockScanMs, interactive, unit * 76f, onUnlock)
            }
        }
    }
}

/** Экран поверх рабочего стола; закрывается по «отпечатку» или свайпом вверх. Анимация разблокировки играет только после этого. */
@Composable
fun LockScreen(onUnlock: () -> Unit) {
    BackHandler(true) {}   // «назад» экран блокировки не закрывает
    val scope = rememberCoroutineScope()
    val off = remember { Animatable(0f) }
    var unlocked by remember { mutableStateOf(false) }
    val thr = with(LocalDensity.current) { 120.dp.toPx() }
    val fire = { if (!unlocked) { unlocked = true; onUnlock() } }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(thr) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (off.value < -thr) fire() else scope.launch { off.animateTo(0f, tween(220)) }
                    },
                    onDragCancel = { scope.launch { off.animateTo(0f, tween(220)) } }
                ) { change, delta ->
                    change.consume()
                    scope.launch { off.snapTo((off.value + delta).coerceAtMost(0f)) }
                }
            }
    ) {
        LockContent(
            Modifier.fillMaxSize().graphicsLayer {
                translationY = off.value
                alpha = (1f + off.value / (size.height * 0.6f)).coerceIn(0.35f, 1f)
            },
            interactive = true, onUnlock = { fire() }
        )
    }
}

/**
 * Предпросмотр для настроек: target = "clock" — часы можно тащить пальцем и растягивать щипком,
 * target = "fp" — тащится отпечаток. Всё сохраняется сразу.
 */
@Composable
fun LockPreview(modifier: Modifier = Modifier, target: String = "clock") {
    var w by remember { mutableFloatStateOf(1f) }
    var h by remember { mutableFloatStateOf(1f) }
    val s = MaterialTheme.colorScheme
    Box(
        modifier.clip(rc(28))
            .background(Brush.linearGradient(listOf(androidx.compose.ui.graphics.lerp(s.primary, Color.Black, .55f), s.tertiary)))
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f); h = it.height.toFloat().coerceAtLeast(1f) }
            // тянем пальцем — часы едут, щипок — размер
            .pointerInput(target) {
                detectTransformGestures { _, pan, zoom, _ ->
                    if (target == "fp") {
                        prefs.lockFpX = (prefs.lockFpX + pan.x / w * 1000f).roundToInt().coerceIn(0, 1000)
                        prefs.lockFpY = (prefs.lockFpY + pan.y / h * 1000f).roundToInt().coerceIn(0, 1000)
                    } else {
                        prefs.lockClockX = (prefs.lockClockX + pan.x / w * 1000f).roundToInt().coerceIn(0, 1000)
                        prefs.lockClockY = (prefs.lockClockY + pan.y / h * 1000f).roundToInt().coerceIn(0, 1000)
                        prefs.lockClockScale = (prefs.lockClockScale * zoom).roundToInt().coerceIn(30, 300)
                    }
                }
            }
    ) {
        LockContent(Modifier.fillMaxSize(), interactive = false, editClock = target != "fp")
    }
}

/** Размытая копия обоев под плашкой дока (если обои удалось прочитать). */
@Composable
fun DockBlurBackdrop(modifier: Modifier, boundsLeft: Float, boundsTop: Float, radiusPct: Int, version: Int) {
    if (radiusPct <= 0 || Build.VERSION.SDK_INT < 31) return
    val ctx = LocalContext.current
    val dm = ctx.resources.displayMetrics
    val bmp = remember(version) { WallSnap.get(ctx, version) } ?: return
    val d = LocalDensity.current
    val r = 40f * d.density * radiusPct / 100f
    Image(
        bmp.asImageBitmap(), null,
        modifier = modifier
            .wrapContentSize(unbounded = true, align = Alignment.TopStart)
            .requiredSize(with(d) { dm.widthPixels.toDp() }, with(d) { dm.heightPixels.toDp() })
            .offset { IntOffset(-boundsLeft.roundToInt(), -boundsTop.roundToInt()) }
            .graphicsLayer { renderEffect = BlurEffect(r, r, TileMode.Clamp) },
        contentScale = ContentScale.Crop
    )
}
