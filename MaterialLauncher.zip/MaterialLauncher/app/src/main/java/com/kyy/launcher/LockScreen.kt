package com.kyy.launcher

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ───────────────────────── снимок обоев (для размытия под доком) ─────────────────────────

/**
 * Копия системных обоев для размытия под доком. Обычное приложение может не иметь права читать обои
 * (зависит от версии Android и от того, живые ли обои), тогда вернётся null и размытие просто не рисуется.
 */
object WallSnap {
    private var cached: Bitmap? = null
    private var stamp = -1

    fun get(ctx: android.content.Context, version: Int): Bitmap? {
        if (stamp == version) return cached
        stamp = version
        cached = try {
            val wm = WallpaperManager.getInstance(ctx)
            val d = (wm.peekDrawable() ?: wm.drawable) as? BitmapDrawable
            val b = d?.bitmap
            if (b == null) null else {
                // для размытия хватает маленькой копии
                val k = minOf(1f, 540f / maxOf(b.width, b.height))
                if (k < 1f) Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true) else b
            }
        } catch (_: Throwable) { null }
        return cached
    }
}

// ───────────────────────── экран блокировки ─────────────────────────

private val lockShadow = TextStyle(shadow = Shadow(Color.Black.copy(.35f), blurRadius = 10f))

private val DOT_GLYPHS = mapOf(
    '0' to "01110 10001 10011 10101 11001 10001 01110",
    '1' to "00100 01100 00100 00100 00100 00100 01110",
    '2' to "01110 10001 00001 00010 00100 01000 11111",
    '3' to "11110 00001 00001 01110 00001 00001 11110",
    '4' to "00010 00110 01010 10010 11111 00010 00010",
    '5' to "11111 10000 11110 00001 00001 10001 01110",
    '6' to "00110 01000 10000 11110 10001 10001 01110",
    '7' to "11111 00001 00010 00100 01000 01000 01000",
    '8' to "01110 10001 10001 01110 10001 10001 01110",
    '9' to "01110 10001 10001 01111 00001 00010 01100",
    ':' to "0 0 1 0 1 0 0"
)

/** Цифры из точек (матрица 5×7). size — как размер шрифта: высота цифры 0,72 от него, высота блока 1,17, как у строки текста. */
@Composable
fun DotText(text: String, size: Dp, color: Color, shadow: Boolean, modifier: Modifier = Modifier) {
    val cols = text.sumOf { if (it == ':') 1 else 5 } + (text.length - 1).coerceAtLeast(0)
    val digitH = size * 0.72f
    val cell = digitH / 7f
    Canvas(modifier.size(cell * cols, size * 1.17f)) {
        val c = cell.toPx()
        val r = c * 0.40f
        var x0 = 0f
        val top = (this.size.height - c * 7f) / 2f
        text.forEach { ch ->
            val rows = (DOT_GLYPHS[ch] ?: "").split(" ")
            val w = if (ch == ':') 1 else 5
            rows.forEachIndexed { ry, row ->
                row.forEachIndexed { cx, bit ->
                    if (bit == '1') {
                        val o = Offset(x0 + (cx + .5f) * c, top + (ry + .5f) * c)
                        if (shadow) drawCircle(Color.Black.copy(.3f), r, o + Offset(0f, c * .12f))
                        drawCircle(color, r, o)
                    }
                }
            }
            x0 += (w + 1) * c
        }
    }
}

/** Текст часов в выбранном стиле: обычный шрифт, контур или точки. */
@Composable
fun ClockText(cf: ClockFont, text: String, size: Dp, weight: FontWeight, color: Color, shadow: Boolean, modifier: Modifier = Modifier) {
    if (cf.kind == "dots") { DotText(text, size, color, shadow, modifier); return }
    val d = LocalDensity.current
    val base = if (shadow) lockShadow else TextStyle.Default
    val st = if (cf.kind == "outline") base.copy(
        drawStyle = Stroke(with(d) { (size.value * 0.03f).dp.toPx() }.coerceAtLeast(1f), join = StrokeJoin.Round)
    ) else base
    Text(
        text, fontSize = with(d) { size.toSp() }, fontWeight = weight, fontFamily = cf.family,
        color = color, style = st, textAlign = TextAlign.Center, modifier = modifier
    )
}

/** Часы как на Google Pixel: цифры столбиком (или в строку), под ними дата. */
@Composable
fun LockClock(unit: Dp, scale: Float, stacked: Boolean, showDate: Boolean, gap: Float = 0.7f, fontId: String = "theme") {
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - value % 60_000L + 30L)
        }
    }
    val is24 = DateFormat.is24HourFormat(ctx)
    val hh = SimpleDateFormat(if (is24) "HH" else "h", Locale.getDefault()).format(Date(now))
    val mm = SimpleDateFormat("mm", Locale.getDefault()).format(Date(now))
    val date = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date(now)).replaceFirstChar { it.uppercase() }
    val big = unit * (if (stacked) 124f else 84f) * scale
    val small = with(LocalDensity.current) { (unit * 18f * scale).toSp() }
    val cf = LockClockFonts.resolve(fontId)
    // у системных гарнитур жирность зашита в сам шрифт, поэтому вес задаём только для шрифта приложения
    val w = if (cf.family != null) FontWeight.Normal else if (stacked) FontWeight.Black else FontWeight.ExtraBold
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (stacked) {
            // высота каждой строки урезается до доли gap, а цифры остаются по центру: так можно сжать расстояние между ними
            val tight = Modifier.layout { m, c ->
                val p = m.measure(c)
                val hh2 = (p.height * gap).roundToInt()
                layout(p.width, hh2) { p.place(0, (hh2 - p.height) / 2) }
            }
            ClockText(cf, hh, big, w, Color.White, true, tight)
            ClockText(cf, mm, big, w, Color.White, true, tight)
        } else {
            ClockText(cf, "$hh:$mm", big, w, Color.White, true)
        }
        if (showDate) {
            Text(date, fontSize = small, fontWeight = FontWeight.Medium, color = Color.White.copy(alpha = .92f), style = lockShadow,
                modifier = Modifier.padding(top = (4f * scale).dp))
        }
    }
}

/**
 * Значок отпечатка в духе Google Pixel: вложенные дуги-«арки» с обрывами и ножками разной длины, внутри волнистая жилка.
 */
@Composable
fun FingerprintGlyph(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val r = size.minDimension / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        val sw = r * 0.075f
        val st = Stroke(sw, cap = StrokeCap.Round)
        val dash = Stroke(sw, cap = StrokeCap.Round, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(r * 0.20f, r * 0.09f)))
        fun arch(k: Float, leg: Float, style: Stroke) {
            val rr = r * k
            val p = androidx.compose.ui.graphics.Path().apply {
                moveTo(c.x - rr, c.y + r * leg)
                lineTo(c.x - rr, c.y)
                arcTo(androidx.compose.ui.geometry.Rect(c.x - rr, c.y - rr, c.x + rr, c.y + rr), 180f, 180f, false)
                lineTo(c.x + rr, c.y + r * leg)
            }
            drawPath(p, color, style = style)
        }
        // от внутренней к внешней: радиус, длина ножек вниз
        arch(0.17f, 0.10f, st)
        arch(0.34f, 0.40f, st)
        arch(0.51f, 0.62f, dash)
        arch(0.68f, 0.52f, st)
        arch(0.85f, 0.30f, dash)
        // центральная жилка
        val v = androidx.compose.ui.graphics.Path().apply {
            moveTo(c.x, c.y - r * 0.02f)
            cubicTo(c.x + r * 0.10f, c.y + r * 0.18f, c.x - r * 0.10f, c.y + r * 0.40f, c.x, c.y + r * 0.62f)
        }
        drawPath(v, color, style = st)
    }
}

/** Загрузка своей картинки для отпечатка: уменьшаем, учитываем поворот из EXIF, сохраняем в приложении. */
fun saveFingerprintImage(ctx: android.content.Context, uri: android.net.Uri): Boolean = try {
    val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
    var sample = 1
    while (o.outWidth / (sample * 2) >= 512 && o.outHeight / (sample * 2) >= 512) sample *= 2
    val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
    var bmp = ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) }
        ?: throw IllegalStateException("decode")
    val k = minOf(1f, 512f / maxOf(bmp.width, bmp.height))
    if (k < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
    val deg = try {
        ctx.contentResolver.openInputStream(uri)?.use {
            when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
            }
        } ?: 0f
    } catch (_: Throwable) { 0f }
    if (deg != 0f) {
        val m = android.graphics.Matrix().apply { postRotate(deg) }
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
    java.io.File(ctx.filesDir, "lock_fp.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    prefs.lockFpImage = System.currentTimeMillis().toString()
    true
} catch (_: Throwable) { false }

fun removeFingerprintImage(ctx: android.content.Context) {
    java.io.File(ctx.filesDir, "lock_fp.png").delete()
    prefs.lockFpImage = ""
}

/**
 * Виртуальный датчик отпечатка: прижмите и подержите — по кругу идёт сканирование, затем открывается рабочий стол.
 * Это только картинка: настоящий отпечаток приложение не читает.
 */
@Composable
fun FingerprintButton(scanMs: Int, interactive: Boolean, size: Dp, onSuccess: () -> Unit) {
    val s = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val prog = remember { Animatable(0f) }
    var done by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }
    val glow = s.primary
    val ctx = LocalContext.current
    val stamp = prefs.lockFpImage
    val img = remember(stamp) {
        if (stamp.isEmpty()) null
        else try { android.graphics.BitmapFactory.decodeFile(java.io.File(ctx.filesDir, "lock_fp.png").path)?.asImageBitmap() } catch (_: Throwable) { null }
    }
    val fill = prefs.lockFpFit != "fit"
    Box(
        Modifier.size(size)
            .graphicsLayer { val k = if (pressed) 1.07f else 1f; scaleX = k; scaleY = k }
            .then(
                if (interactive) Modifier.pointerInput(scanMs) {
                    detectTapGestures(onPress = {
                        if (!done) {
                            pressed = true
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            val job = scope.launch {
                                prog.animateTo(1f, tween(scanMs.coerceAtLeast(1), easing = LinearEasing))
                                if (!done) {
                                    done = true
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    delay(140)
                                    onSuccess()
                                }
                            }
                            tryAwaitRelease()
                            pressed = false
                            if (!done) { job.cancel(); scope.launch { prog.animateTo(0f, tween(180)) } }
                        }
                    })
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        if (img == null || !fill) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(Color.Black.copy(alpha = if (pressed) .55f else .4f)))
        }
        if (img != null) {
            // своя картинка: «заполнить» обрезает по кругу, «вписать» сжимает целиком внутрь
            if (fill) {
                Image(img, null, Modifier.fillMaxSize().padding(4.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            } else {
                Image(img, null, Modifier.fillMaxSize(0.74f), contentScale = ContentScale.Fit)
            }
        }
        Canvas(Modifier.fillMaxSize()) {
            val st = 3.dp.toPx()
            drawCircle(Color.White.copy(alpha = .35f), radius = this.size.minDimension / 2f - st / 2f, style = Stroke(st))
            if (prog.value > 0f) {
                drawArc(glow, -90f, 360f * prog.value, false, Offset(st / 2f, st / 2f),
                    Size(this.size.width - st, this.size.height - st), style = Stroke(st, cap = StrokeCap.Round))
            }
        }
        if (img == null) {
            val tint = androidx.compose.ui.graphics.lerp(Color.White, glow, prog.value.coerceIn(0f, 1f))
            FingerprintGlyph(tint, Modifier.size(size * 0.56f))
        }
    }
}

/**
 * Содержимое экрана блокировки. Одно и то же рисуется на самом экране и в предпросмотре в настройках:
 * размеры считаются от ширины (360 dp = 1), поэтому положение и размер часов совпадают.
 */
@Composable
fun LockContent(
    modifier: Modifier = Modifier,
    interactive: Boolean,
    onUnlock: () -> Unit = {}
) {
    BoxWithConstraints(modifier) {
        val unit = maxWidth / 360f
        val x = prefs.lockClockX / 1000f
        val y = prefs.lockClockY / 1000f
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(.32f), Color.Transparent, Color.Black.copy(.45f))))
        )
        Box(
            Modifier
                .layout { m, c ->
                    val p = m.measure(Constraints())
                    layout(c.maxWidth, c.maxHeight) {
                        p.place((c.maxWidth * x - p.width / 2f).roundToInt(), (c.maxHeight * y - p.height / 2f).roundToInt())
                    }
                }
        ) {
            LockClock(unit, prefs.lockClockScale / 100f, prefs.lockClockStyle == "stack", prefs.lockDate, prefs.lockClockGap / 100f, prefs.lockClockFont)
        }
        // отпечаток: центр значка стоит в точке (lockFpX, lockFpY); подпись, если включена, рисуется над ним
        val fx = prefs.lockFpX / 1000f
        val fy = prefs.lockFpY / 1000f
        val btnPx = with(LocalDensity.current) { (unit * 76f).toPx() }
        Box(
            Modifier.layout { m, c ->
                val p = m.measure(Constraints())
                layout(c.maxWidth, c.maxHeight) {
                    val px = (c.maxWidth * fx - p.width / 2f).roundToInt().coerceIn(0, (c.maxWidth - p.width).coerceAtLeast(0))
                    // значок всегда нижний в колонке, поэтому его центр — на btnPx/2 выше низа колонки
                    val py = (c.maxHeight * fy - (p.height - btnPx / 2f)).roundToInt()
                        .coerceIn(0, (c.maxHeight - p.height).coerceAtLeast(0))
                    p.place(px, py)
                }
            }
        ) {
            Column(Modifier.width(unit * 76f), horizontalAlignment = Alignment.CenterHorizontally) {
                if (prefs.lockHint) {
                    Text(
                        "Коснитесь датчика или проведите вверх", color = Color.White.copy(alpha = .9f), style = lockShadow,
                        fontSize = with(LocalDensity.current) { (unit * 13f).toSp() },
                        textAlign = TextAlign.Center, softWrap = false,
                        modifier = Modifier.wrapContentWidth(unbounded = true)
                    )
                    Spacer(Modifier.height(unit * 14f))
                }
                FingerprintButton(prefs.lockScanMs, interactive, unit * 76f, onUnlock)
            }
        }
    }
}

/** Экран поверх рабочего стола; закрывается по «отпечатку» или свайпом вверх. Анимация разблокировки играет только после этого. */
@Composable
fun LockScreen(onUnlock: () -> Unit) {
    BackHandler(true) {}   // «назад» экран блокировки не закрывает
    val scope = rememberCoroutineScope()
    val off = remember { Animatable(0f) }
    var unlocked by remember { mutableStateOf(false) }
    val thr = with(LocalDensity.current) { 120.dp.toPx() }
    val fire = { if (!unlocked) { unlocked = true; onUnlock() } }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(thr) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (off.value < -thr) fire() else scope.launch { off.animateTo(0f, tween(220)) }
                    },
                    onDragCancel = { scope.launch { off.animateTo(0f, tween(220)) } }
                ) { change, delta ->
                    change.consume()
                    scope.launch { off.snapTo((off.value + delta).coerceAtMost(0f)) }
                }
            }
    ) {
        LockContent(
            Modifier.fillMaxSize().graphicsLayer {
                translationY = off.value
                alpha = (1f + off.value / (size.height * 0.6f)).coerceIn(0.35f, 1f)
            },
            interactive = true, onUnlock = { fire() }
        )
    }
}

/**
 * Предпросмотр для настроек: target = "clock" — часы можно тащить пальцем и растягивать щипком,
 * target = "fp" — тащится отпечаток. Всё сохраняется сразу.
 */
@Composable
fun LockPreview(modifier: Modifier = Modifier, target: String = "clock") {
    var w by remember { mutableFloatStateOf(1f) }
    var h by remember { mutableFloatStateOf(1f) }
    val s = MaterialTheme.colorScheme
    Box(
        modifier.clip(rc(28))
            .background(Brush.linearGradient(listOf(androidx.compose.ui.graphics.lerp(s.primary, Color.Black, .55f), s.tertiary)))
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f); h = it.height.toFloat().coerceAtLeast(1f) }
            // тянем пальцем — часы едут, щипок — размер
            .pointerInput(target) {
                detectTransformGestures { _, pan, zoom, _ ->
                    if (target == "fp") {
                        prefs.lockFpX = (prefs.lockFpX + pan.x / w * 1000f).roundToInt().coerceIn(0, 1000)
                        prefs.lockFpY = (prefs.lockFpY + pan.y / h * 1000f).roundToInt().coerceIn(0, 1000)
                    } else {
                        prefs.lockClockX = (prefs.lockClockX + pan.x / w * 1000f).roundToInt().coerceIn(0, 1000)
                        prefs.lockClockY = (prefs.lockClockY + pan.y / h * 1000f).roundToInt().coerceIn(0, 1000)
                        prefs.lockClockScale = (prefs.lockClockScale * zoom).roundToInt().coerceIn(30, 300)
                    }
                }
            }
    ) {
        LockContent(Modifier.fillMaxSize(), interactive = false)
    }
}

/** Размытая копия обоев под плашкой дока (если обои удалось прочитать). */
@Composable
fun DockBlurBackdrop(modifier: Modifier, boundsLeft: Float, boundsTop: Float, radiusPct: Int, version: Int) {
    if (radiusPct <= 0 || Build.VERSION.SDK_INT < 31) return
    val ctx = LocalContext.current
    val dm = ctx.resources.displayMetrics
    val bmp = remember(version) { WallSnap.get(ctx, version) } ?: return
    val d = LocalDensity.current
    val r = 40f * d.density * radiusPct / 100f
    Image(
        bmp.asImageBitmap(), null,
        modifier = modifier
            .wrapContentSize(unbounded = true, align = Alignment.TopStart)
            .requiredSize(with(d) { dm.widthPixels.toDp() }, with(d) { dm.heightPixels.toDp() })
            .offset { IntOffset(-boundsLeft.roundToInt(), -boundsTop.roundToInt()) }
            .graphicsLayer { renderEffect = BlurEffect(r, r, TileMode.Clamp) },
        contentScale = ContentScale.Crop
    )
}
